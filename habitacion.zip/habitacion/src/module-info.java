/**
 * 
 */
/**
 * @author parjrui
 *
 */
module habitacion {
	requires transitive cama;
}