package ess;

public class HueleTodo {
	public static void meHueleTodo() {
		System.out.println("me huele todo");
	}
}
