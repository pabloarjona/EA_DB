/**
 * 
 */
/**
 * @author parjrui
 *
 */
module habitacion {
	requires transitive cama;
	exports ess;
}