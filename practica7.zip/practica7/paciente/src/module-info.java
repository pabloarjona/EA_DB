/**
 * 
 */
/**
 * @author parjrui
 *
 */
module paciente {
	//requires transitivo
	exports es;
	exports ex;
	//permitir hacer reflexion
	opens es;
	provides ex.ServiceSintomas with es.ServiceSintomasImpl;
}