package ex;

public interface ServiceSintomas {
	boolean meDuele();
}
