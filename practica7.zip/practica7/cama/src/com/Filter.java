package com;

import java.util.ServiceLoader;

import ex.ServiceSintomas;

public class Filter {
	public static void main(String[] args) {
		boolean n = ServiceLoader.load(ServiceSintomas.class).findFirst().get().meDuele();
		meSuenaTodo();
	}
	public static void meSuenaTodo() {
		System.out.println("Me suena todo");
	}

}
