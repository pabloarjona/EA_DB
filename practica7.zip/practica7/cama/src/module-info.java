/**
 * @author parjrui
 *
 */
module cama {
	requires transitive paciente;
	uses ex.ServiceSintomas;
	
	//requires transitivo
	exports com;
	//permitir hacer reflexion
	opens com;
}