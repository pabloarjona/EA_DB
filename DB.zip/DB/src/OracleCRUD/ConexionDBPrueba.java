package OracleCRUD;

public class ConexionDBPrueba {

	public ConexionDBPrueba() {
		
		
	}
}
