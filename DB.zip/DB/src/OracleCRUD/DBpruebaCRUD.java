package OracleCRUD;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DBpruebaCRUD {
	public static void main(String[] args) {
		//readPrueba();
		createPrueba2();
	}
	
	private static void readPrueba() {
		try {
            Connection conexion = DriverManager.getConnection("jdbc:oracle:thin:@srvacgabdw04:1521:OPENWEAP","OCMSPABLO","OCMSPABLO01");
            PreparedStatement statement = conexion.prepareStatement("SELECT * FROM PRUEBA");
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
            	System.out.println("Columna1: "+ resultSet.getString("COLUMN1"));
            }
            resultSet.close();
            statement.close();
            conexion.close();
        } catch ( SQLException e) {
        	e.printStackTrace();
        	System.out.println(e);
		}
	}
	
	private static void createPrueba() {
		try(var conn = DriverManager.getConnection("jdbc:oracle:thin:@srvacgabdw04:1521:OPENWEAP","OCMSPABLO","OCMSPABLO01");
				var statement= conn.prepareStatement("INSERT INTO (COLUMN1) VALUES (?)")){      //S1
			statement.setString(1, "Feathers");
			try (var resultSet = statement.executeQuery()){
				while(resultSet.next()) {
	            	System.out.println("Columna1: "+ resultSet.getString("COLUMN1"));
					System.out.println(resultSet.next());
				}
			}
		}catch ( SQLException e) {
			e.printStackTrace();
			System.out.println("Error SQL: "+e.toString());
		}
	}
	
	private static void createPrueba2() {
		try(var conn = DriverManager.getConnection("jdbc:oracle:thin:@srvacgabdw04:1521:OPENWEAP","OCMSPABLO","OCMSPABLO01");
				var statement= conn.prepareStatement("INSERT INTO PRUEBA2(COLUMN1) VALUES (?)")){      //S1
			statement.setString(1, "Feathers");
			try (var resultSet = statement.executeQuery()){
				while(resultSet.next()) {
	            	System.out.println("Columna1: "+ resultSet.getString("COLUMN1"));
				}
			}
		}catch ( SQLException e) {
			e.printStackTrace();
			System.out.println("Error SQL: "+e.toString());
		}
	}
}
