package ax;

import java.util.ServiceLoader;

import com.Filter;

import ess.HueleTodo;
import ex.ServiceSintomas;

public class Hospital {
	public static void main(String[] args) {
		HueleTodo.meHueleTodo();
		Filter.meSuenaTodo();
		boolean n = ServiceLoader.load(ServiceSintomas.class).findFirst().get().meDuele();
	}
}
