/**
 * 
 */
/**
 * @author parjrui
 *
 */
module hospital {
	requires habitacion;
	uses ex.ServiceSintomas;
}