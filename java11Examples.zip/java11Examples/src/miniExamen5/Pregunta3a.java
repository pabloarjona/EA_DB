package miniExamen5;


public class Pregunta3a extends Pregunta3{
	
	public Pregunta3a(String name) {
		super();
		setName(name);
	}
	
	public static void main(String[] args) {
		Pregunta3a p3a= new Pregunta3a("HH");
		System.out.println(p3a);
	}
}
