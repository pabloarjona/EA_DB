package miniExamen5;
//CONSULTAR DANIIII
/* Pregunta 5
 * Q: Given...
 *    What is the result?
 * A: D. Good Night, Potter
 */
public class Pregunta5 {
	public static void main(String[] args) {
		Super s = new Sub(); //los métodos estáticos no se sobreescriben en Java
		System.out.println(s.greeting() + ", "+ s.name());  //por eso llama a la referencia de Super y s.name() a la de Sub, por que no es estático
	}
}

class Super{
	static String greeting() { return "Good Night";}
	String name() { return "Harry"; }
}

class Sub extends Super{
	static String greeting() { return "Good Morning";}
	String name() {return "Potter";}
}