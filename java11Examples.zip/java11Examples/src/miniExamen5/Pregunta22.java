package miniExamen5;

import miniExamen5.ExternalClasses.APIInterface;
import miniExamen5.ExternalClasses.AbstractAPI;

public class Pregunta22 extends AbstractAPI implements APIInterface{

	//************COMENTAR DANI
	/* Pregunta22
	 * Q: Given...
	 * 	  What is the result?
	 * A: A. The program prints Process()called 2.
	 */
	public static void main(String[] args) {
		var impl = new Pregunta22();
		impl.process();
	}
	
	public void process() {
		System.out.println("Process()called 2.");
	}
	
}
