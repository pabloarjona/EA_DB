package miniExamen5;

import miniExamen5.ExternalClasses.Ellipse;
import miniExamen5.ExternalClasses.Rectangle;

public class Pregunta2 implements Rectangle, Ellipse{

	/* Pregunta 2
	 * Q: Given...
	 *    
	 *    What prevents this code from compiling?
	 * A: B. Cylinder is not properly calling the Rectangle and Ellipse interfaces' calculateSurfaceArea methods.
	 */
	public double calculateSurfaceArea(double l, double w, double majorR, double minorR) {
		double rectArea = Rectangle.super.calculateSurfaceArea(l, w);
		double ellipseArea = Ellipse.super.calculateSurfaceArea(majorR, minorR);
		return rectArea + ellipseArea * 2;
	}
	
}
