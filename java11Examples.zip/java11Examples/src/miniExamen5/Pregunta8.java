package miniExamen5;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/* Pregunta 8
 * Q: Given...
 * 	  What is the output?
 * A: C. Hello world!
		 Bonjour le monde!
 */
public class Pregunta8 extends Pregunta8a{
	public void foo(List arg) {
		System.out.println("Hello world!");
	}
	
	public static void main(String... args) {
		List<String> li = new ArrayList<>();
		Collection<String> co = li;
		Pregunta8 b = new Pregunta8();
		b.foo(li);
		b.foo(co);
	}
}
