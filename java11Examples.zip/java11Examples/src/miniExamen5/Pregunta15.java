package miniExamen5;

/* Pregunta 15
 * Q: Given...
 *    Which line of code results in a compilation error?
 * A: D. line n4
 */
class Pregunta15 {

	final int num; 	//line n1
	public Pregunta15(int num) {
		this.num = num;
	}
	
	final void method() {
		System.out.println("Output from super");
	}
	
}

class Pregunta15a extends Pregunta15 {
	int num;   //line n2
	Pregunta15a(short num){   //line n3
		super(num);
	}
	
	protected void method() {   //line n4
		System.out.println("Output from Pregunta15a");
	}
}

