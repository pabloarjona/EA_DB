package miniExamen5;
//COMENTAR DANI*********************
/* Pregunta 17
 * Q: Given...
 *    Which two interfaces can be used in lambda expressions? (Choose two.)
 * A: C. MyInterface1
 *    D. MyInterface3
 */
interface Pregunta17 {

}

interface MyInterface1{
	public int method() throws Exception;
	private void pMethod() { /* an implementation of pMethod*/ }
}

interface MyInterface2{
	public static void sMethod() { /* an implementation of sMethod*/} 
	private boolean equals();
}

interface MyInterface3{
	public void method();
	public void method(String str);
}

interface MyInterface4{
	public void dMethod() { /*an implementation of dMethod */}
	public void method();
}

interface MyInterface5{
	public static void sMethod();
	private void method(String str);
}