package miniExamen5;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import miniExamen5.ExternalClasses.Item;

public class Parte1 {

	public static void main(String[] args) {
		//pregunta1();
		//pregunta4();
		pregunta6();
		//pregunta7(1);
		//pregunta7Pruebas(1);
		//pregunta9();
		//pregunta12();
		//pregunta13();
		//pregunta14Prueba();
	}

	//MENCIONAR DANI
	/* Pregunta 1
	 * Q: Given the code fragment...
	 * 	  What is the result?
	 * A: C. java.lang.UnsupportedOperationException is thrown
	 */
	private static void pregunta1() {
		List<String> list1 = new ArrayList<>(List.of("Earth", "Wind", "Fire"));
		List<String> list2 = List.copyOf(list1);  //las listas inmutables generadas por List.copyOf() no permiten la modificación de su contenido
		list1.sort((String item1, String item2) -> item1.compareTo(item2));
		list2.sort((String item1, String item2)  -> item1.compareTo(item2));  //incluido la ordenación
		System.out.println(list2.equals(list1));
	}
	
	//MENCIONAR DANI
	/* Pregunta 4
	 * Q: Given the code fragment: ...
	 * 	  Which two compile? (Choose two.)
	 * A: A. foo(n -> Integer.toHexString(n));
	 *    F. foo(Integer::toHexString);
	 */
	private static void pregunta4() {
		foo(n -> Integer.toHexString(n));   //esto 
		foo(Integer::toHexString);			//es lo mismo que esto
	}
	
	public static void foo(Function<Integer, String> fun) {
		System.out.println(fun.apply(21));  //ejemplo
	}
	//REPASAR DANI
	/* Pregunta 6
	 * Q: Given the code fragment: ...
	 *    You must make the count variable thread safe.
	 * 	  Which two modifications meet your requirement? (Choose two.)
	 * A: C. replace line 3 with 
	 *    synchronized(test){
	 *    		test.count++;
	 *    }
	 *    D. replace line 1 with private AtomicInteger count = new AtomicInteger(0); and replace line 3 with test.count.incremenentAndGet();
	 *    
	 */
	//private int count=0;								   //line 1 solucion1 y enunciado
	private AtomicInteger count = new AtomicInteger(0);  // line 1 SOLUCION 2 
	private static void pregunta6() { 					   //line 2
		Parte1 test = new Parte1();
		ExecutorService service = Executors.newFixedThreadPool(10);  //para hacer tareas c
		for(int i = 0; i<10; i++) {
			service.submit(() -> {                 //se envia una tarea al servicio de ejecución
				for(int j = 0; j<100; j++) {     
					//test.count++;					//line 3
					/*synchronized (test) {
						test.count++;
					}*/
					test.count.incrementAndGet();   //line 3 SOLUCION 2
					System.out.println(test.count);   //PRUEBA
				}
			});
		}
		service.shutdown();						///se cierra el servicio de ejecución 
	}
	
	/* Pregunta 7
	 * Q: Given...
	 *    What is the result?
	 * A: D. The compilations fails.
	 */
	private static int pregunta7(int x) {
		int y = 4;
		class Computer{
			int reduce(int x) {
				//return x-y--;  FALLO
				return 1;      //ponemos esto para que no de error 
			}
		}
		Computer a = new Computer();
		return a.reduce(1);
	}
	
	private static int pregunta7Pruebas(int x) {
		int y = 4;
		class Computer{
			int reduce(int x) {
				return x-y;
			}
		}
		Computer a = new Computer();
		int reduce = a.reduce(1);
		System.out.println(reduce);
		return reduce;
	}
	
	/* Pregunta 9
	 * Q: Given...
	 *    What is the output?
	 * A: D. -----
			 -----	
			 banana orange apple lemon apple banana lemon orange 
	 */
	private static void pregunta9() {
		List<String> fruits = List.of("banana", "orange", "apple", "lemon");
		Stream<String> s1 = fruits.stream();
		Stream<String> s2 =s1.peek(i -> System.out.print(i+ " "));
		System.out.println("-----");
		Stream<String> s3 = s2.sorted();
		Stream<String> s4 = s3.peek(i -> System.out.print(i + " "));
		System.out.println("-----");
		String strFruits = s4.collect(Collectors.joining(","));   //sirve para conectar poniendo la coma
		System.out.println(strFruits);  //Prueba 
	}
	
	/* Pregunta 12
	 * Q: Given...
	 *    What is the result?
	 * A: A. 357
	 */
	private static int i;
	private static int[] primes= {2,3,5,7};
	private static String result="";
	private static void pregunta12() {
		while(i<primes.length) {
			if(i==3) {
				break;
			}
			i++;
			result += primes[i];
		}
		System.out.println(result);
	}
	
	/* Pregunta 13
	 * Q: Given...
	 * 	  What is true?
	 * A: D. This may not print the same result each time the programs runs.
	 */
	private static void pregunta13() {
		var items = List.of(new Item("A", 10), new Item("B", 2),
							new Item("C", 12), new Item("D", 5),
							new Item("E", 6));
		double avg = items.stream().mapToInt(i -> i.amount).average().orElse(0.0);
		Optional<Item> item = items.parallelStream().filter(i->i.amount <avg).findAny();
		System.out.println(item.orElseThrow());
	}
		
	/* Pregunta 14
	 * Q: Given the code fragment... (clases below)
	 * 	  Which fields are serialized in a Student object?
	 * A: A. studentNo and classes
	 */
	private static void pregunta14Prueba() {
		Student student = new Student();
		student.name = "John";
		student.address = "12/2/2020";
		student.studentNo = "12033";
		student.classes.id = "123";
		
		try {
	         // Serializar el objeto Student
            ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("student.ser"));
            out.writeObject(student);
            out.close();
            
            //Deserializar el objeto student
            ObjectInputStream in = new ObjectInputStream(new FileInputStream("student.ser"));
            Student deserializedStudent = (Student) in.readObject();
            in.close();
            
            //Imprimir los atributos del objecto deserializado
            System.out.print("Name: "+deserializedStudent.name + " Addres: "+deserializedStudent.address+" Student No: "+deserializedStudent.studentNo+ " Classes ID: "+deserializedStudent.classes.id);
		}catch(IOException | ClassNotFoundException e){
			e.printStackTrace();
		}
	}
}
/*
 * Pregunta 22
 * Q. Given...
 * A. A. sutdentNo and Classes
 */
class Classes implements Serializable{
	String id;
}

class Person { //no se serializa ninguno pq no implementa la interfaz Serializable
	String name;   
	transient String address;    //debe excluirse de la serialización
}

class Student extends Person implements Serializable{
	String studentNo;
	Classes classes = new Classes();
}
