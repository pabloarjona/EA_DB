package miniExamen5;

import java.util.Collection;

public class Pregunta8a {

	public void foo(Collection arg) {
		System.out.println("Bonjour le monde!");
	}
}
