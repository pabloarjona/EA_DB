package miniExamen5;
//CONSULTAR DANIII***********************
/* Pregunta 19
 *  Q: Which two interface are considered to be functional interfaces? (Choose two.)
 *  A: B. InterfaceD
 *     E. InterfaceB
 *  Teoría: las interfaces funcionales son aquellas que tienen un único método abstracto
 */
interface Pregunta19 {}

@FunctionalInterface
interface InterfaceC {
	public boolean equals(Object o);
	int bread(int x);
	int calculate(int x, int y);
}

@FunctionalInterface
interface InterfaceD{
	int breed(int x);
}

@FunctionalInterface
interface InterfaceE{
	public boolean equals(int i);
	int breed(int x);
}

interface InterfaceA{
	int GERM = 13;
	public default int getGERM() {
		return GERM;
	}
}

interface InterfaceB{
	int GERM = 13;
	public default int getGERM() { return get();}
	private int get() { return GERM; }
	public boolean equals(Object o);
	int breed(int x);
}

