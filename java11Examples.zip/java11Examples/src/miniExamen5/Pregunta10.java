package miniExamen5;

import java.util.Collection;
import java.util.List;
/* Pregunta 10
 * Q: Given the code fragment...
 *    Which action enables Computator class to compile? 
 * A: D. Change line 2 to public Double sum (C collection){
 */
//line1
public class Pregunta10 <N extends Number,  C extends Collection<N>>{
	//public N sum (C collection) {   	//line 2 ERROR
	public Double sum (C collection) {				//line 2
		double sum = 0.0;						//line 3
		for(N n : collection) {  				//line 4
			sum += n.doubleValue();
		}
		return sum;
	}
	public static void main(String[] args) {
		var numbers = List.of(5,4,6,3,7,2,8,1,9);   //line 5
		Pregunta10<Integer, List<Integer>> c = new Pregunta10<>();
		System.out.println(c.sum(numbers));
	}
	
}
