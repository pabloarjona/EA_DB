package miniExamen5;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.CyclicBarrier;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.IntStream;

import miniExamen5.ExternalClasses.Member;

public class Parte2 {
		
	public static void main(String[] args) {
		//pregunta16();
		pregunta18();
		//pregunta24();
		//pregunta25();
	}
	
	/* Pregunta 16
	 * Q: Given...
	 * 	  What is the result?
	 * A: The compilation fails. 
	 */
	private static void pregunta16() {
		//String[] furnitures = ["Door", "Window", "Chair"];   //ERROR
		String[] furnitures = {"Door","Window", "Chair"};     ///PRUEBAS
		var sb = new StringBuilder();
		for (var i = 0; i < furnitures.length; i++) {
			var index = i +1;
			sb.append(i)
			.append("). ")
			.append(furnitures[i].charAt(i))
			.append(", ");
			if(index < furnitures.length) {
				sb.append(" | ");
			}
		}
		sb.delete(sb.length()-2, sb.length()-1);
		sb.insert(0, '[').insert(sb.length()-1, ']');
		System.out.println(sb);
	}
	//DUDAAAA
	/* Pregunta 18
	 * Q: Given the code fragment:
	 *    Which statement is true?
	 * A: A. It never finishes
	 */
	private static void pregunta18() {
		List<Integer> list = new CopyOnWriteArrayList<>();    //concurrencia con operaciones de lectura y escritura de listas
		ExecutorService executorService = Executors.newFixedThreadPool(5);
		CyclicBarrier barrier = new CyclicBarrier(2, () -> System.out.print(list));  //barrera que permite en grupos de hilos esperar hasta que todos hayan
																					 //llegado a un punto específico (se ejecuta el Runnable cuando llega a 2 hilos)
		IntStream.range(0, 5).forEach( n -> executorService.execute(() ->{ 
			try {
				list.add(n);
				barrier.await();
			 }catch(InterruptedException | BrokenBarrierException e) {
				 System.out.println("Exception");
			}
		}));
		
		executorService.shutdown();
	}
	
	//REPASAR DANI
	/* Pregunta 20
	 * Q: Given a Member class with fields for name and yearsMembership, including getters and setters and a prin method, and a list of 
	 *    clubMembers members:
	 * 	  Which two Stream methods can be changed to use method references? (Choose two.)
	 * A: 
	 */
	private static void pregunta20() {
		Member member = new Member();
		String testName = "smith";
		int testMembershipLength = 5;
		/*long matches = member.clubMembers.stream()
				.peek(Member::print)
				.filter(m -> m.getYearsMemberShip() >= testMembershipLength)
				.map(m -> testName.compareToIgnoreCase(m))
				.filter(a -> a == 0)
				.count();*/
	}
	
	/* Pregunta21
	 * Q: Given the code fragment:
	 *    What is the result?
	 * A: E. the compilations fails due to an error in line 3.
	 */
	private static void pregunta21() {
		char d = 100, e ='e';      //line 1
		int x = d; 				   //line 2
		//int = y = (int) e;		   //line 3 ERROR
		//System.out.println((char) x + (char) y); ERROR
	}

	//COMENTAR DANI*********************************
	/* Pregunta 24
	 * Q: Which code fragment represents a valid Comparator implementation?
	 * A: C. new Comparator<String>() {
			@Override
			public int compare(String str1, String str2) {
				// TODO Auto-generated method stub
				return str1.compareTo(str2);
			}
		};
	 */
	private static void pregunta24() {
		Comparator e =new Comparator<String>() {  //PROBANDO Comparator e..
			@Override
			public int compare(String str1, String str2) {
				// TODO Auto-generated method stub
				return str1.compareTo(str2);
			}
		};
		//PROBANDO
		int result = e.compare("OLA", "OLA");
		System.out.println(result);
	}
	
	//COMENTAR DANI
	/* Pregunta 25
	 * Q: Given...
	 *    Which two statements print ..\..\..\answers\topsecret? (Choose two.)
	 * A: B.System.out.println(p2.relativize(p3));
		  C. System.out.println(p1.relativize(p3)); 
	 */
	private static void pregunta25() {
		Path p1 = Paths.get("/scratch/exam/topsecret/answers");
		Path p2 = Paths.get("/scratch/exam/answers/temp.txt");
		Path p3 = Paths.get("/scratch/answers/topsecret");
		//Solucion
		System.out.println(p2.relativize(p3));
		System.out.println(p1.relativize(p3));
		//Probando
		System.out.println(p3.relativize(p1));
		System.out.println(p3.relativize(p2));
		System.out.println(p1.relativize(p2));
		System.out.println(p2.relativize(p1));
	}
}
