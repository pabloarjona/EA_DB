package miniExamen5;

public class Pregunta11a {
	static final int A = 0;
	public static final int B =0;
	private static final int C = 0;
	int d = 0;
	protected int e = 0;
	public int f = 0;
	private int g = 0;
	public void foo(int h) {
		int i = 0;
	}
}
