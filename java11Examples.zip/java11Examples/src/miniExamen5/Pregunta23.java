package miniExamen5;

import java.io.FileNotFoundException;

import miniExamen5.ExternalClasses.ExSuper;
//REPASAR DANI
/* Pregunta 23
 * Q: Given... and the code fragment...
 *    What is the result?
 * A: C. 9001: APPLICATION ERROR-9001-MyFile.txt
 */
public class Pregunta23 extends ExSuper{

	public Pregunta23(int eCode, String msg, Throwable cause) {
		super(eCode, msg, cause);
	}
	
	public static void main(String[] args) {
		try {
			String param1 = "Oracle";
			if(param1.equalsIgnoreCase("oracle")) {
				throw new Pregunta23(9001, "APPLICATION ERROR-9001", new FileNotFoundException("MyFile.txt"));
			}
			throw new ExSuper(9001, new FileNotFoundException("MyFile.txt"));   //Line 1
		}catch(ExSuper ex){
			System.out.println(ex.getMessage());
		}
	}
}
