package miniExamen5;

/* Pregunta 3
 * Q: Given...
 *    What is the result?
 * A: D. The compilation fails.
 */
public final class Pregunta3 {

	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String toString() {
		return getName();
	}
}
