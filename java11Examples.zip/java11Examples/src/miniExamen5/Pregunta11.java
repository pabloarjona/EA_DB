package miniExamen5;
//REPASAR DANI
/* Pregunta 11
 * Q: Given...
 *    Which four identifiers from the Foo and Bar classes are visible at line 1? (Choose four.)
 * A: A. e
 *    B. f
 * 	  C. A
 *    H. B
 *    E. d
 */
public class Pregunta11 extends miniExamen5.Pregunta11a {
	public void foo(int j) {
		//line 1
		System.out.println(A);  
		System.out.println(B);  
		System.out.println(d);  
		System.out.println(e); 
		System.out.println(f); 
	}
	public static void main(String[] args) {
		//foo(1);
	}
}
