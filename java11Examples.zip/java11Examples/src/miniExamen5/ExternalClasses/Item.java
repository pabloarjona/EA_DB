package miniExamen5.ExternalClasses;

public class Item {
	public String name;
	public int amount;
	public Item(String name, int amount) {
		this.name = name;
		this.amount = amount;
	}
	public String toString() { return "Name: "+name+", Amount: "+amount;}
}
