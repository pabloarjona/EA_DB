package miniExamen5.ExternalClasses;

public interface APIInterface {

	public default void process() {
		System.out.println("Process() called 1.");
	}
}
