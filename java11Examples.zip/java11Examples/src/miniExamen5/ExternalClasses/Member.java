package miniExamen5.ExternalClasses;

import java.util.ArrayList;
import java.util.List;

public class Member {
	String name;
	int yearsMemberShip;
	List<Member> clubMembers = new ArrayList<>();
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	public int getYearsMemberShip() {
		return yearsMemberShip;
	}
	public void setYearsMemberShip(int yearsMemberShip) {
		this.yearsMemberShip = yearsMemberShip;
	}
	@Override
	public String toString() {
		return "Member [name=" + name + ", yearsMemberShip=" + yearsMemberShip + ", clubMembers=" + clubMembers + "]";
	}
	public void print() {
		System.out.println(toString());
		
	}
	
	
}
