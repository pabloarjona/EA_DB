package miniExamen5.ExternalClasses;

public interface Rectangle {

	default double calculateSurfaceArea(double l, double w) {
		return l*w;
	}
}
