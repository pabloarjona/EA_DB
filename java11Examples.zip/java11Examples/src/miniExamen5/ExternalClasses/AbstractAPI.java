package miniExamen5.ExternalClasses;

public abstract class AbstractAPI {

	public abstract void process();
}


