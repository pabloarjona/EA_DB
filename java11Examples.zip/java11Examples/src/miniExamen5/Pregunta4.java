package miniExamen5;

public class Pregunta4 extends Exception{

	private final int eCode;
	public Pregunta4(int eCode, Throwable cause) {
		super(cause);
		
	}
	
}
