package MiniExamen1;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;

public class Pregunta_3_4 {
	
	public static void main(String[] args) {
		Pregunta3();
		//Pregunta4();
	}
	
	//Q: Given...
	//Which is true about line 1?
	//A: D. If the value is not present, nothing is done
	private static void Pregunta3() {
		var numbers = List.of(1,2,3,4,5,6,7,8,9,10);
		//Filter: 1+2+4+5+7+8+10: 37		reduce: contador, si no se queda vacío
		Optional<Integer> result = numbers.stream().filter(x -> x % 3 != 0).reduce((i, j) ->i + j);
		result.ifPresent(System.out::println);   //line 1
		//Código adicional
		Optional<Integer> resultPrueba = numbers.stream().filter(x -> x % 3 == 67).reduce((i,j) -> i+j);
		Runnable r = () -> System.out.println("La lista de salida está vacía");
		resultPrueba.ifPresentOrElse(System.out::print,r);
	}
	
	//Q: Given...
	//Which pattern formats the date as Friday 7th of February 1997?
	//A: "eeee d'th of? MMMM yyyy"
	private static void Pregunta4() {
		LocalDate d1 = LocalDate.of(1997, 2, 7);
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern(/*insert code here*/"eeee d'th of' MMMM yyyy");
		//Código adicional
		System.out.println(dtf.format(d1));
		DateTimeFormatter dtPrueba = DateTimeFormatter.ofPattern("dd MMM uuuu");
		System.out.println("Prueba: " +dtPrueba.format(d1));
	}
}
