package MiniExamen1;

import java.io.Serializable;

//Q: Which two are secure serialization of these objects?
//A: A. Define the serialPersistentFields array field
// 	 E. Implement only writeReplace to replace the instance with a serial proxy and not readResolve
public class Pregunta_5 {
	public class Confidential implements Serializable{
		private String data;
		
		public Confidential(String data) {
			this.data = data;
		}
	}

}
