package MiniExamen1;

public class Pregunta_2 {
	
	//Given...
	static class Student{						//line 1
		String classname;  				
		Student (String classname){		//line 2
			this.classname = classname; 
		}
	}
	
	public static void main(String[] args) {
		//Question 2
		//Given...
		//Which two independent changes will make the Main class compile? (Choose two)
		var student = new Student("Biology");    //line 3
		//A: Move the entire Student class declaration to a separate Java file, Student.java.
		//E: Change line 1 to static class Student{..
	}
	

}
