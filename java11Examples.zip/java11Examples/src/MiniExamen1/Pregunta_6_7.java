package MiniExamen1;

import java.nio.file.Files;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class Pregunta_6_7 {
	
	public static void main(String[] args) {
		Pregunta6();
	}
	/**
	 * Q: Given the code fragment
	 * var pool = Executors.newFixedThreadPool(5);
	 * Future outcome = pool.submit(()-> 1);
	 * A: java.util.concurrent.Callable
	 */
	private static void Pregunta6() {
		//5 subprocesos de trabajo, procesos a la vez
		//explicación https://www.digitalocean.com/community/tutorials/threadpoolexecutor-java-thread-pool-example-executorservice
		var pool = Executors.newFixedThreadPool(5);
		//Future representa un resultado futuro de una tarea asíncrona
		//Enviar una tarea a ejecutar en el hilo separado
		Future outCome = pool.submit(() -> 1);
		
		//Realiza otras operaciones mientras la tarea se esta ejecutando
		try {
			//Obtén el resultado de la tarea usando get()
			Integer result = (Integer) outCome.get();
			System.out.println("Resultado de la tarea: "+result);
		}catch(InterruptedException | ExecutionException e){
			e.printStackTrace();
		}
				
		//Finaliza el ejecutor service
		pool.shutdown();
		System.out.println(outCome);	 
	}
	
	
	/**Pregunta 7:
	 * Which two statements correctly describe capabilities of interfaces and abstract classes? (Choose two)
	 * A. Interfaces cannot have protected methods but abstract classes can.
	 * C. Interfaces cannot have instance fields but abstract classes can.
	 */
}
