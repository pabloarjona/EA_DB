package MiniExamen1;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class Pregunta12_13 {

	public static void main(String[] args) throws IOException  {
		Pregunta12();
	}
	
	private static void Pregunta12() throws IOException{
		Path source = Paths.get("C:/Ejemplo/a/a.text");
		Path destination = Paths.get("C:/Ejemplo/a");
		Files.move(source, destination);
		Files.delete(source);
	}
	
	/* 
	 * Q.13: Which two statements set the default locale used for formatting numbers, currency and percentages? (Choose two.)
	 * A: B. y C.
	 */
	private static void Pregunta13() {
		Locale.setDefault(Locale.Category.FORMAT, Locale.CANADA_FRENCH); //B.
		Locale.setDefault(Locale.SIMPLIFIED_CHINESE); //C.
	}
	
	/* Pregunta 14
	 * Q.14: Which three guidelines are used to protect confidential information? (Choose three.)
	 * A: A. Limit access to objects holding confidential information.
	 * 	  F. Validate input before storing confidential information.
	 * 	  G. Encapsulate confidential information. 
	 */
	
	/*
	 * Q.15: Which annotation should be used to remove warnings from complation?
	 * A: D. @SuppressWarnings("all") 
	 */
	//Solution @SuppressWarnings("all") 
	@SuppressWarnings("all")
	private static void Pregunta15() {
		List l = new ArrayList<>();
		l.add("hello");
		l.add("world");
		print(l);
	}
	//Solution @SuppressWarnings("all") 
	@SuppressWarnings("all")
	private static void print(List<String>... args) {
		for(List<String> str : args) {
			System.out.println(str);
		}
	}
	
	
}