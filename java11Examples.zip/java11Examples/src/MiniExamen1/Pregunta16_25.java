package MiniExamen1;

import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.function.ToDoubleFunction;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import com.sun.tools.javac.Main;

import MiniExamen1.ExternalClasses.Person;
import MiniExamen1.ExternalClasses.Sale;

public class Pregunta16_25 {
	
	public static void main(String[] args) {
		//Pregunta16();
		//Pregunta20();
		//EjemploPregunta21();
		//Pregunta22();
		//Pregunta24();
		Pregunta25();
	}
	
	/*
	 * Q. 16: Given:
	 * 	List<String> longList = List.of("Hello", "World", "Beat");
	 * 	List<String> shortlist = new ArrayList<>();
	 *  Which code fragment correctly forms a short list of words containing the letter "e"?
	 * A: shortlist = longList.stream().filter(w -> w.indexOf('e') != -1).parallel().collect(Collectors.toList());
	 */
	private static void Pregunta16() {
		List<String> longList = List.of("Hello", "World", "Beat");
		List<String> shortlist = new ArrayList<>();
		//Solution:
		shortlist = longList.stream().
				filter(w -> w.indexOf('e') != -1)
				.parallel().collect(Collectors.toList());
		//Me:
		for (String string : shortlist) {
			System.out.println(string);
		}
	}
	
	/*
	 * Q. 17: 
	 * A bookstore's sales are represented by a list of Sale objects populated with the name of the customer and the books 
	 * they purchased.
	 * public class Sale { ....
	 * }
	 * public class Book {....
	 * }
	 * Given a list of Sale objects, tList, which code fragment creates a list of total sales for each customer in ascending 
	 * order?
	 * A: C.
	 */
	private static void Pregunta17() {
		List<Sale> tList = new ArrayList<>();
		//Solution
		/*
		List<String> totalByUser = tList.stream()
				.collect(groupingBy(Sale::getCustomer,
						flatMapping(t-> t.getItems().stream(),
						summingDouble(Book::getPrice))))
				.entrySet().stream()
				.sorted(Comparator.comparing(Entry::getValue))
				.collect(mapping(e-> e.getKey() + ":" + e.getValue(), toList()));
		 */
	}
	
	/**
	 * Q. 18: Given the contents:
	 * 
		MessageBundle.properties file: message=Hello
		MessageBundle_en.properties file: message=Hello (en)
		MessageBundle_US.properties file: message=Hello (US)
		MessageBundle_en_US.properties file: message=Hello (en_US)
		MessageBundle_fr_FR.properties file: message=Bonjour and the code fragment:
		Locale.setDefault(Locale.FRANCE);
		Locale currentLocale = new Locale.Builder().setLanguage("en").build();
		ResourceBundle messages = ResourceBundle.getBundle("MessageBundle", currentLocale); 
		System.out. println(messages.getString("message"));
		Which file will display the content on executing the code fragment?
		
		A: B. MessageBundle_en.properties
		r
	 */
	
	/**
	 * Pregunta 19
	 * Q.19: Given:
	 * jdeps -jdkinternals C:\workspace\4SimpleSecurity\jar\classes.jar
	 * Which describes the expected output?
	 * A: D. The -jdkinternals option analyzes all class in the .jar for class-level dependencies on JDK internal APIs. If any 
	 * are found, the results with suggested replacements are output in the console.
	 */
	
	/*
	 * Pregunta 20 
	 * Q.20: Given:
	 * 	final List<String> fruits = List.of("Orange", "Apple", "Lemmon", "Raspberry");
		final List<String> types = List.of("Juice", "Pie", "Ice", "Tart");
		final var stream = IntStream.range(0, Math.min(fruits.size(), types.size()))
				.mapToObj((i) ->fruits.get(i) + " " +types.get(i));
		stream.forEach(System.out::println);
	 * A: C. Orange Juice
			 Apple Pie
		   	 Lemmon Ice
			 Raspberry Tart
	 */
	private static void Pregunta20() {
		final List<String> fruits = List.of("Orange", "Apple", "Lemmon", "Raspberry");
		final List<String> types = List.of("Juice", "Pie", "Ice", "Tart");
		final var stream = IntStream.range(0, Math.min(fruits.size(), types.size()))
				.mapToObj((i) ->fruits.get(i) + " " +types.get(i));
		stream.forEach(System.out::println);
	}
	
	/*
	 * Pregunta 21
	 * Q. 21: Which interface in the java.util.function package can return a primitive type?
	 * A: A. ToDoubleFunction
	 * Primitive type: byte, short, int long, float, double, char and boolean.
	 */
	private static void EjemploPregunta21() {
		ToDoubleFunction<Integer> ob = a-> a/2;
		
		//using applyAsDouble()
		System.out.println(ob.applyAsDouble(3));
	}
	
	/*
	 * Pregunta 22
	 * Q. 22: Given:
	 * try (Reader reader1 = new FileReader("File1.txt");
			 Reader reader2 = new FileReader("File2.txt");
			 Reader reader3 = new FileReader("File3.txt")){
		}catch (IOException ex){
			Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);			
		}
		//Line 1
		System.out.println("Done");
	 * A: B. All three readers have been closed
	 */
	private static void Pregunta22() {
		try (Reader reader1 = new FileReader("File1.txt");
			 Reader reader2 = new FileReader("File2.txt");
			 Reader reader3 = new FileReader("File3.txt")){
		}catch (IOException ex){
			Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);			
		}
		//Line 1
		System.out.println("Done");
	}
	
	/*
	 * Pregunta 23
	 * Q. 23: Which two safely validate inputs?(Choose two.)
	 * A: B. Accept only valid characters and input values
	 * 	  C. Use trusted domain-specific libraries to validate inputs.
	 */
	
	/*
	 * Pregunta 24
	 * Q. 24: Given the Person class with age and name along with getter and setter methods, and this code fragment:
	 * 	List<Person> persons = new ArrayList<>(List.of(new Person(44, "Toma"),
				new Person(40, "Aman"),
				new Person(40, "Peter")));
		persons.sort(Comparator.comparing((Person::getAge)).thenComparing(Person::getName).reversed());
		persons.forEach(p1 -> System.out.println(" "+p1.getName()));
		What will be the result?
	 * A: D. Tom Peter Aman
	 */
	private static void Pregunta24(){
		List<Person> persons = new ArrayList<>(List.of(new Person(44, "Toma"),
				new Person(40, "Aman"),
				new Person(40, "Peter")));
		persons.sort(Comparator.comparing((Person::getAge)).thenComparing(Person::getName).reversed());
		persons.forEach(p1 -> System.out.println(" "+p1.getName()));
	}
	
	/*
	 * Pregunta 25
	 * Q. 25: Given:
	 * List<String> list1 = new LinkedList<String>();
		Set<String> hs1 = new HashSet<String>();
		String[] v = {"a","b","c","b","a"};
		for (String s: v) {
			list1.add(s);
			hs1.add(s);
		}
		System.out.println(hs1.size() + " "+list1.size()+ " ");
		HashSet hs2 = new HashSet(list1);
		LinkedList list2 = new LinkedList(hs1);
		System.out.println(hs2.size() + " "+list2.size());
		
		What is the result?
		
		A: 3 5 3 3
	 */
	private static void Pregunta25() {
		List<String> list1 = new LinkedList<String>();
		Set<String> hs1 = new HashSet<String>();
		String[] v = {"a","b","c","b","a"};
		for (String s: v) {
			list1.add(s);
			hs1.add(s);
		}
		System.out.print(hs1.size() + " "+list1.size()+ " ");
		HashSet hs2 = new HashSet(list1);
		LinkedList list2 = new LinkedList(hs1);
		System.out.print(hs2.size() + " "+list2.size());
	}
}
