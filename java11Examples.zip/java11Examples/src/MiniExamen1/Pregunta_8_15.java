package MiniExamen1;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import MiniExamen1.ExternalClasses.Employee;


enum Letter{
	ALPHA(100), BETA(200),	GAMMA(300);
	int v; 
	Letter(int V) { this.v = v;}
	
	//Insert code here
	
	public String toString() { return String.valueOf(v);}
}
public class Pregunta_8_15 {
	public static void main(String[] args) {
		Pregunta11();
	}
	
	//Question 9. 
	//Q: Which two statements independently compile? (Choose two.)
	//A: A y C 
	private void Pregunta9() {
		//respuestas A y C
		List<? super Short> list = new ArrayList<Number>();
		List<? extends Number> list2 = new ArrayList<Byte>();
	}
	
	//Question 10
	//Q: Which two are correct? (Choose two.)
	//A: B. The program prints 1 4 2 3, but the order is unpredictable
	//   E. Replacing forEach() with forEachOrdered(), the program prints 2 1 3 4 5
	private static void Pregunta10() {
		Integer[] intArray = {2, 1, 3, 4, 5};
		List<Integer> list = new ArrayList<>(Arrays.asList(intArray));
		list.parallelStream().forEach(e -> System.out.print(e + ""));
		//list.parallelStream().forEachOrdered(e -> System.out.print(e + ""));
	}
	
	/**
	 * Question 11
	 * Q: Which code, when inserted on line 10, prints the number of unique localities from the roster list?
	 * A: A. .map(Employee:getLocality).distinct().count();
	 */
	private static void Pregunta11() {
		List<Employee> roster = new ArrayList<>();
		roster.add(new Employee());
									//insert code here
		long empCount = roster.stream().map(Employee::getLocality).distinct().count();
		System.out.println(empCount);
	}
}
