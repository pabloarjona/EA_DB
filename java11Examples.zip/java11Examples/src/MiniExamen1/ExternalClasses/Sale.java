package MiniExamen1.ExternalClasses;

import java.util.List;

public class Sale {
	private String customer;
	private List<Book> items;
	
	public Sale() {
		// TODO Auto-generated constructor stub
	}
	
	public String getCustomer() {
		return customer;
	}
	public void setCustomer(String customer) {
		this.customer = customer;
	}
	public List<Book> getItems() {
		return items;
	}
	public void setItems(List<Book> items) {
		this.items = items;
	}
	
	

}
