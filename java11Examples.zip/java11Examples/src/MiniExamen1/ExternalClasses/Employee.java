package MiniExamen1.ExternalClasses;

public class Employee{
	private String name;
	private String locality;
	private Double salary;
	public Employee() {
		
	}
	
	public Employee(String name, String locality) {
		this.name= name;
		this.locality = locality;
	}
	
	public Employee(String name, Double salary) {
		this.name= name;
		this.salary = salary;
	}
	
	public Double getSalary() {
		return this.salary;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLocality() {
		return locality;
	}
	public void setLocality(String locality) {
		this.locality = locality;
	}
	
	
}

