package MiniExamen1;

enum QUALITY{
	A(100), B(75), C(50);
	int percent;
	private QUALITY(int percent) {
		this.percent = percent;
	}
}

public class Pregunta_1 {
	
	public static void main(String[] args) {
		//Question 1
		checkQuality(QUALITY.A);
	}
	
	//Question 1
	//Q: Given enum QUALITY
	//and checkQuality(QUALITY.A);
	//and checkQuality..
	//A: A
	public static void checkQuality(QUALITY q) {
		switch(q) {
		case /*Insert code here*/ A:
			System.out.println("Best");
			break;
		default: 
			System.out.println("Not best");
			break;
		}
	}	
}
