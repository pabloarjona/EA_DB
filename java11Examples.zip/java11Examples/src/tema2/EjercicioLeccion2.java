package tema2;

public class EjercicioLeccion2 {
	
	enum Enumerator { VERDADERO, FALSO};
	
	public static void main(String... args) {
		
		switch (Enumerator.VERDADERO) {
		case VERDADERO: 
			System.out.println("Acertarás");
			break;
		case FALSO: 
			System.out.println("Fallarás");
		default: break;
		}
	}

}
