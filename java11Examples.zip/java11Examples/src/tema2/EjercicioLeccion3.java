package tema2;
 
public class EjercicioLeccion3 {
	Boolean __ = false;
	
	public static void main(String ...args) {
	
		megamalo:{
			System.out.println("Destuiré el mundo wuahahhahah");
			
			break megamalo;
		}
		
		//Código inalcanzable si no se cierra la etiqueta de megamalo
		megabueno:{
			System.out.println("Os salvare a todos");							
		}
			
		megaman: {
			System.out.println("mi mi mi mi mi");
		}
	}
}
