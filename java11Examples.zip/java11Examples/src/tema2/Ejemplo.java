package tema2;

public class Ejemplo {
	//malas prácticas
	{}
	
	public static void main(String...args) {
		//Malas prácticas pero te pueden preguntar por ello
		pablo:{
			{}{System.out.println("hola"); break pablo;}
		}
	}

}
