package tema2;

public class Examen {
	
	final static short s = 60;
	//quitar final en función del ejericio
	public final static void main(String... args) {
		/*Ejercicio 1
		int caso1 = 1;
		//si quitamos final no funciona, porque no sería una variable constante
		final short $_caso_2 = 2;
		switch(caso1) {
			default:
				System.out.println("cerca");
				break;
			case $_caso_2:
				System.out.println("lejos");
		}
		*/
		/*Ejercicio 2
		var v = 37;
		//el 97 es el caracter 'a'
		char c = 97;
		switch (c-v) {
		case s:
			amor: {
				System.out.println("salgo por consol"+c);
				break amor; 
				} 
			break;
		default: 
			System.out.println("No sale nada");
			break;
		}
		*/
		bucle1:
			for(int i = 1; i < 10 ; i++) {
				i++;
				for(i=1;  i>1; i--) {
					System.out.println("menudo lio");
					continue bucle1;
				}
				break bucle1;
			}		
	}
}
