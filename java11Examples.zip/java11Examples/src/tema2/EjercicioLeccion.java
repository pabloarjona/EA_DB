package tema2;

public class EjercicioLeccion {

	public static void main(String... args) {
		for(var x = "bucle"; x.length() > 0; queryPoppins(x)) {
			//substring-> coge una cadena nueva desde el parametro que le pasamos hasta el final (si no le pasamos dos parametros)
			x= x.substring(x.length());
		}
	}
	
	public static void queryPoppins(String mery) {
		System.out.println("Con un poco de azucar "+mery);
		
		if(true)if(true)if(true);
		System.out.println("yeah baby");
		if(true) {
			
		}else if(false) System.out.println("amigos");
	}
}
