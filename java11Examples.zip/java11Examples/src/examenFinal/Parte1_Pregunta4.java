package examenFinal;

/* Pregunta 4
 * Q: What is the result of the following?
 * A: E. The code throws an exception on line s2.
 */
public class Parte1_Pregunta4 {
	
	public static void seasons(String... names) {
		var v = names[1].length();    	//s1
		System.out.println(names[v]); 	//s2
	}
	
	public static void main(String[] args) {
		seasons("Summer","Fall", "Winter", "Spring");
	}
	
}
