package examenFinal;

import java.time.Clock;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;

/* Pregunta 21
 * Q: Assuming 10 seconds is enough time for all of the tasks to finish, what statements about the following program are correct?
 *    (Choose two.)
 * A: 
 */
public class Parte1_Pregunta21 {
	
	private AtomicLong bigHand = new AtomicLong(0);
	
	void incrementBy10() {
		bigHand.getAndSet(bigHand.get()+10);
	}
	
	public static void main(String[] args) throws Exception{
		//examMethod();
		testMethod();
	}
	
	private static void examMethod() throws Exception{
		List<String> ee = new ArrayList<>();
		var smartWatch = new Parte1_Pregunta21();
		ExecutorService s = Executors.newCachedThreadPool();  //se usa normalmente para tareas con vida corta y muchas como esta
		for(int i = 0; i < 100; i++) {
			s.submit(() -> smartWatch.incrementBy10()).get();
		}
		s.shutdown();    //no se aceptaran nuevas tareas y el executor no acabara hasta que hayan terminados todas las tareas
		s.awaitTermination(10, TimeUnit.SECONDS);   //bloquea la tarea principal hasta que todas las tareas completen la ejecución
		System.out.println(smartWatch.bigHand.get()); //después del shutdown, el tiempo o el hilo es interrumpid
	}
	
	private static void testMethod() {
		ExecutorService executorService = Executors.newCachedThreadPool();
		for(int i = 0; i<10; i++) {
			final int taskId = i;
			executorService.submit(() -> {
				System.out.println("Task "+taskId+" is running on thread "+ Thread.currentThread().getName());
			});
		}
		executorService.shutdown();
	}
}
