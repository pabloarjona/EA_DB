package examenFinal;

public class Mouse {

}
