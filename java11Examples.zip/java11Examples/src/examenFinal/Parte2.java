package examenFinal;

import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Locale.Builder;
import java.util.Properties;
import java.util.ResourceBundle;

public class Parte2 {

	public static void main(String[] args) {
		pregunta26();
	}
	
	/* Pregunta 26
	 * Q: Which annotations will trigger a compiler error if incorrectly applied to a method with no other annotations? (Choose three.)
	 * A: A. @Documented
	 *    D. @Override
	 *    F. @SafeVarargs 
	 */
	
	private static void pregunta26() {
		//Test SafeVarargs
		List<String> stringList = createList("one", "two", "three");
		System.out.println("String list"+stringList);
	}
	
	@SafeVarargs
	private static <T> List<T> createList(T... elements){
		List<T> list = new ArrayList<>();
		for(T element : elements) {
			list.add(element);
		}
		return list;
	}
	
	/* Pregunta 27
	 * Q: Which of the following cannot be instantiated directly by the caller using the constructor? (Choose two).
	 * A:  B. ResourceBundle
	 *     E. DateTimeFormatter
	 */
	private static void pregunta27() {
		ResourceBundle e = new ResourceBundle();
		Locale e2 = new Locale(null);
		Locale.Builder e3 = new Builder();
		Properties e4 = new  Properties();
		DateTimeFormatter e5 = new DateTimeFormatter(null, e2, null, null, null, null, null);
		HashMap e6 = new HashMap();
	}
	
	/* Pregunta 28
	 * Q: What is the output of the following? 
	 * A: 
	 */
}
