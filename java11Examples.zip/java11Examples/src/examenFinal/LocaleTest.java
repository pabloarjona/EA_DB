package examenFinal;

import java.util.Locale;
import java.util.MissingResourceException;

public class LocaleTest {

	public LocaleTest() {
		
	}
	
	public static void setResources(String locale) {
		  // validate locale
		  Locale lo = parseLocale(locale);
		  if (isValid(lo)) {
			  System.out.print(lo + ": ");
			  System.out.println(lo.getDisplayCountry());
		    //System.out.println(lo.getISO3Language());
		  } else {
		    System.out.println("invalid: " + locale);
		  }
	}

		private static Locale parseLocale(String locale) {
		  String[] parts = locale.split("_");
		  switch (parts.length) {
		    case 3: return new Locale(parts[0], parts[1], parts[2]);
		    case 2: return new Locale(parts[0], parts[1]);
		    case 1: return new Locale(parts[0]);
		    default: throw new IllegalArgumentException("Invalid locale: " + locale);
		  }
		}

		private static boolean isValid(Locale locale) {
		  try {
		    return locale.getISO3Language() != null && locale.getISO3Country() != null;
		  } catch (MissingResourceException e) {
		    return false;
		  }
		}
}
