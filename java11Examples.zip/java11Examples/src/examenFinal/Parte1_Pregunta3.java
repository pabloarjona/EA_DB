package examenFinal;

import java.lang.annotation.ElementType;
import java.lang.annotation.Target;
import java.util.List;
import java.util.Properties;

/* Pregunta 3:
 * Q: Which statement about the following declarations is correct? ...
 * A: B. Only the declaration of Friend contains a compiler error.
 */
public class Parte1_Pregunta3 {

	@Target(ElementType.TYPE_USE)
	public @interface Friend{
		String value();
		String lastName() default null; //ERROR
		int age = 10;
		
	}
	
	class MyFriends{
		void makeFriends() {
			var friends = List.of(new @Friend("Olivia") Object(), 
					new @Friend("Adeline") String(),
					new @Friend("Henry") MyFriends());
		}
	}
	
	
}