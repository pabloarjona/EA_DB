package examenFinal;

import java.sql.DriverManager;
import java.sql.SQLException;

/* Pregunta 10
 * Q: Suppose we have a peacoks table with two columns: name and rating. What does the following code output if the 
 *    table is empty?
 * A: E. The code does not compile due to another line.
 */
public class Parte1_Pregunta10_DB {

	public static void main(String[] args) throws ClassNotFoundException{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		var url ="jdbc:oracle:thin:@srvacgabdw04:1521:OPENWEAP";
		var sql = "SELECT * FROM PRUEBA2 WHERE COLUMN1 = ?";
		try(var conn = DriverManager.getConnection(url,"OCMSPABLO","OCMSPABLO01");
				var stmt= conn.prepareStatement(sql)){      //s2
			stmt.setString(1, "Feathers");
			try (var rs = stmt.executeQuery()){             //s2
				while(rs.next()) {       					//Error en el enunciado es rs.hasNext()
	            	//System.out.println("Columna1: "+ rs.getString("COLUMN1"));
					System.out.println(rs.next());
				}
			}
		}catch ( SQLException e) {
			e.printStackTrace();
			System.out.println("Error SQL: "+e.toString());
		}
		
	}
	
}
