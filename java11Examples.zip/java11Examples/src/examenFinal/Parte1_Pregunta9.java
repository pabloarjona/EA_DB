package examenFinal;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/* Pregunta 9
 * Q: Which method can fill in the blank that would cause the program to consistently print Tie! ten times?
 * A: E. None of the above.
 */
public class Parte1_Pregunta9 {

	private Lock shoes = new ReentrantLock();
	public static void pregunta9b() {
		try {
			//if(shoes) ERROR   
 		}catch(Exception e){
			
		}
	}
	
	public static void pregunta9a() {
		var gate = new Parte1_Pregunta9();
		for(int i = 0; i<10; i++) {
			new Thread(() -> gate.pregunta9a()).start();
		}
	}
}
