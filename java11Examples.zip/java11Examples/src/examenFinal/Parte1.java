package examenFinal;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Clock;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.IntUnaryOperator;
import java.util.stream.Stream;

public class Parte1 {
	
	public static void main(String[] args) {
		//pregunta2();
		//pregunta6();
		//pregunta7();
		//pregunta11();
		//pregunta13("Pablo");
		//pregunta14();
		//pregunta15();
		//pregunta20();
		//pregunta22();
		//pregunta24();
		pregunta25();
	}
	//Incorrecta
	/* Pregunta 1: 
	 * Q: Which of the following statements about InputStream and Reader are correct? (Choose two.)
	 * A: A: The are both abstract classes.
	 *    B. They can both be used to read character data.
	 */

	//Correcta
	/* Pregunta 2:
	 * Q: Which fills in the blank so the code is guaranteed to print 1?
	 *    var stream = Stream.of(1, 2, 3);
	 *    System.out.println(stream._____);
	 * A: E. None of the above.
	 */
	private static void pregunta2() {
		var stream = Stream.of(1,2,3);
		System.out.println(stream.findFirst().get()); //Sería la respuesta correcta  
	}

	/* Pregunta 5:
	 * Q: Fill in the blank with code to look up and call a service
	 * 	  String cheese = ServiceLoader.load(Mouse.class).map(____).map(Mouse::favoriteFooe).findFirst().orElse("");
	 * A: E. None of the above
	 */
	private static void pregunta5() {
		//DA ERROR
		//String cheese = ServiceLoader.load(Mouse.class).map(____).map(Mouse::favoriteFooe).findFirst().orElse("");
	}
	
	/* Pregunta 6:
	 * Q: Assuming the following class is concurrently accessed by numerous threads, which statement about the 
	 *    CountSheep (pregunta6) class is correct?
	 * A: E. The class is already thread-safe
	 */
	private static AtomicInteger counter = new AtomicInteger();
	private Object lock = new Object();
	private static void pregunta6() {
		Parte1 parte = new Parte1();
		
		System.out.println("increment1: "+parte.increment1());
		System.out.println("increment1: "+parte.increment1());
		
		System.out.println("increment2: "+parte.increment2());
		System.out.println("increment2: "+parte.increment2());
		
		System.out.println("increment3: "+parte.increment3());
		System.out.println("increment3: "+parte.increment3());
	}
	//synchronized: solo un hilo puede ejecutarlo a la vez para la misma instacia del objecto
	public synchronized int increment1() {
		return counter.incrementAndGet();  //incrementa y devuelve el nuevo valor
	}
	//static synchronized: solo un hilo puede ejecutarlo a la vez para la misma instacia de la clase
	public static synchronized int increment2() {
		return counter.getAndIncrement();
	}
	
	public int increment3() {
		//esto permite la sincronizacion en funcion de ese objecto
		synchronized (lock) {
			return counter.getAndIncrement();
		}
	}
	
	/* Pregunta 7
	 * Q: Which of the following lambda expressions can be used to a method that takes IntUnaryOperator as an argument? 
	 *    (Choose three.)
	 * A: A. v -> {System.out.print("Hello!"); return 2%1;}
	 *    C. (int j)-> (int) 30L
	 *    F. z -> z
	 */
	//PRUEBAS:
	private static void pregunta7() {
		int result1 = operate( v -> {System.out.print("Hello!"); return 2%1;});
		System.out.println("result1: "+result1);
		int result2 = operate((int j)-> (int) 30L);
		System.out.println("result2: "+result2);
		int result3 = operate( z -> z);
		System.out.println("result3: "+result3);
	}
	private static int operate(IntUnaryOperator operator) {
		int number = 1;
		return operator.applyAsInt(number);
	}
	
	/* Pregunta 8
	 * Q: Which of the following variable types can be used in a switch statement under some circunstances? (Choose three.)
	 * A: A. An enumerated type
	 *    C. Byte
	 *    E. var
	 */
	private static void pregunta8() {
		var prueba = "A";
		byte prueba2 =1;
		Prueba prueba3 = Prueba.Prueba;
		switch(prueba3) {
		case Prueba2:
			break;
		default:
			break;
		}
	}
	
	public enum Prueba{
		Prueba, 
		Prueba2,
		Prueba3
	}
	
	/* Pregunta 11
	 * Q: How many of the following lines contain a compiler error? 
	 * A: D: Three
	 */
	private static void pregunta11() {
		//long min1 = 123.0, max1 = 987L;
		final long min2 = 1_2_3, max2 = 9_8_7;
		//long min3 = 123, int max3 = 987;
		long min4 = 123L, max4 = 987;
		//long min5 = 123_, max5 = _987;
	}
	
	/* Pregunta 12
	 * Q: How many of these module declarations are valid? 
	 * A: module com.apple { exports com.apple;}
	 *    module com.apple$ { }
	 */
	
	/* Pregunta 13 ****DUDA***
	 * Q: What is this class an example of?
	 * A: B. Whitelist ?¿?¿?DUDa
	 * Theory: whitelist is usually a list of items that are permitted
	 *         blacklist is a list of items that are forbidden.
	 */
	private static List<String> approved = List.of("Pablo","Maria","Alvaro");
	private static List<String> rejected = List.of("Alberto","Rosa","Ruben");
	public static boolean pregunta13(String name) {
		var grantAccess = approved.contains(name) || rejected.contains(name);
		System.out.println(grantAccess);
		return grantAccess;
	}
	
	/* Pregunta 14
	 * Q: Which of the following can fill in the black so the code prints true?
	 * A: C. happy.substring(1, happy.length()-1)
	 */
	private static void pregunta14() {
		var happy = " :) - (: ";
		var really = happy.trim();     //quita espacios al principio y al final de la cadena
		var question = happy.substring(1, happy.length()-1);   //Solucion
		System.out.println(really.equals(question));
	}
	
	/* Pregunta 15.
	 * Q: Fill in the blanks: The name of the abstract method in the Function interface is ___________,
	 *    while the name of the abstract method in the Consumer interface is ____________________.
	 * A: C. apply(), accept()
	 */
	//EJEMPLOs
	private static void pregunta15() {
		Function<String, Integer> stringLengthFunction = String::length;
		System.out.println("Function: Length of 'Hello': "+stringLengthFunction.apply("Hello"));
		Consumer<String> printConsumer = System.out::println;
		printConsumer.accept("Consumer: Print this message");
		//Consumer example
	}
	
	/* Pregunta 16
	 * Q: How many lines of the magic() method contain compilation errors?
	 * A: C. Two
	 */
	private static void pregunta16() {  //magic()
		do {
			int trick = 0;
			LOOP: do {
				trick++;
			}while(trick < 2--);  //first error
			continue LOOP;
		}while( 1 > 2);
		System.out.println(trick); //second error
	}
	
	/* Pregunta 17
	 * Q: Fill in the blanks: Because of ______, it is possible to _____________ a method, which allows Java
	 *    to support ____________.
	 * A: virtual methods, override, polymorphism
	 * Theory: Virtual methods: all non-static methods are, by default, virtual. This means that they can be overriden
	 *         in subclasses. 
	 *         Polymorphism: allows objects of different types to be treated as objects of a common type. In this case
	    	   of overriding enables the invocation of overriden methos through a reference to the superclass.
	 */
	
	/* Pregunta 18
	 * Q: Fill in the blanks. Using the _____ and _______modifiers together allows a variable to be accessed from 
	 *    any class, without requiring an instance variable. 
	 * A: E. public, static
	 */
	
	/* Pregunta 19.    //REPASARRRR
	 * Q: Which is part of the module service and has a requires directive?
	 * A: B. Service locator
	 */
	
	/* Pregunta 20.
	 * Q: Which of the following are valid lambda expressions? (Choose three.)
	 * A: A. () -> {}
	 *    B. (Double adder) -> {int y; System.out.print(adder); return adder;};
	 *    E. dog -> dog
	 */
	//Prueba
	private static void pregunta20() {
		List<String> ejemplo = List.of("Pablo","Maria","Alvaro");
		Adder adderLambda = (Double adder) -> {int y; System.out.print(adder); return adder;};
		adderLambda.add(5.0);
	}
	
	interface Adder{
		Double add(Double value);
	}
	
	/* Pregunta 21
	 * Q: Assuming 10 seconds is enough time for all of the tasks to finish, what statements about the following program are correct?
	 *    (Choose two.)
	 * A: A. The code does not compile.
	 *    C. The incrmentBy10 method is not thread-safe
	 */
	private AtomicLong bigHand = new AtomicLong(0);
	//It is not thread safe because is not performed atomically
	void incrementBy10() {
		bigHand.getAndSet(bigHand.get() + 10);
	}
	private static void pregunta21() throws Exception{
		var smartWatch = new Clock();  //can not instantiate clock
	}
	
	/*
	 * Q: What is the output of the following code snippet?
	 * A: C.\dance\move.txt
			\dance\move.txt\.\song\..\note.txt
	 */
	private static void pregunta22() {
		Path x = Paths.get(".", "song", "..", "/note");
		Path y = Paths.get("/dance/move.txt");
		x.normalize(); //es para simplificar pero no se está asignando a ninguna variable.
		Path o = x.normalize();
		System.out.println(x.resolve(y));
		System.out.println(y.resolve(x));
		System.out.println(o);
	}
	
	/* Pregunta 23
	 * Q: What is the minimun number of lines that need to be removed to make this code compile and be able to implemented as a lambda expression?
	 * A: B. 2
	 * Interface Play.java
	 */
	
	/* Pregunta 24
	 * Q: Which of the following shows a valid Locale format? (Choose two.)
	 * A: A. iw
	 *    E. th_TH
	 */
	private static void pregunta24() {
		//TESTS
		LocaleTest.setResources("iw");
		LocaleTest.setResources("UA");
		LocaleTest.setResources("it_ch");
		LocaleTest.setResources("JA_JP");
		LocaleTest.setResources("th_TH");
		LocaleTest.setResources("ES_HN");
	}
	
	/* Pregunta 25
	 * Q: Which statements when inserted independently will throw an exception at runtime? (Choose two.) 
	 * A: C. x.pop; x.pop();
	 *    D: x.remove(); x.remove();
	 */
	private static void pregunta25() {
		var x = new LinkedList<>();
		x.offer(18);   //añade valor a la cola
		//INSERT CODE HERE
				
		//x.peek();     //recoge el valor sin eliminar
		//x.poll();     recupera el valor y elimina, si no hay devuelve null
		//x.pop();   //elimina y devuelve el primer valor
		//x.remove();  elimina y devuelve el primer valor
	}
}
