package tema12;

import java.text.DecimalFormat;
import java.text.MessageFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.Locale;
import java.util.ResourceBundle;

public class Theory {
	public static void main(String[] args) throws ParseException {
		Prueba1();
		Prueba2();
		Prueba3();
		Prueba4();
		Prueba5();
	}
	
	private static void Prueba1() {
		System.out.println("......Prueba 1......");
		//Locale.setDefault(new Locale("es_Es"));   	//da error
		Locale.getDefault(); 						//va al fichero de mensaje_es.properties
		System.out.println(ResourceBundle.getBundle("mensajes").getString("wellcome"));
	}
	
	//MESSAGES
	private static void Prueba2() {
		System.out.println(".........Prueba 2.......");
		Locale.getDefault(); 						
		ResourceBundle rb = ResourceBundle.getBundle("Coche");
		String baseString = rb.getString("descripcion");
		System.out.println(MessageFormat.format(baseString, "puedo asegurar que", "palabrita de mentiroso"));
		MessageFormat mf = new MessageFormat(baseString, Locale.ITALIAN);
		System.out.println(mf.format(new Object[] {299999 , 333333333.333}));
		//Prueba1();
	}
	//NUMBERS
	private static void Prueba3() throws ParseException {
		System.out.println("........Prueba 3........");
		NumberFormat nf = NumberFormat.getInstance(Locale.getDefault());
		System.out.println(nf.format(1000000));
		
		NumberFormat moneda = NumberFormat.getCurrencyInstance();
		System.out.println(moneda.format(99999999.99));
		
		Locale locale = Locale.US;
		System.out.println(NumberFormat.getCurrencyInstance(locale).parse("$999.99"));
		
		NumberFormat propio = new DecimalFormat("$###,###,###%");
		System.out.println(propio.format(123));
	}
	
	//DATES
	private static void Prueba4() {
		System.out.println(".......Prueba 4.........");
		Locale.setDefault(new Locale("en", "US"));
		Locale espana = new Locale("es", "ES");
		var dt = LocalDateTime.now();
		print(DateTimeFormatter.ofLocalizedDate(FormatStyle.SHORT), dt, espana);
		print(DateTimeFormatter.ofLocalizedTime(FormatStyle.SHORT), dt, espana);
		print(DateTimeFormatter.ofLocalizedDateTime(FormatStyle.SHORT, FormatStyle.SHORT), dt, espana);
	}
	
	public static void print(DateTimeFormatter dtf, LocalDateTime dateTime, Locale locale) {
		System.out.println(dtf.format(dateTime) + "," + dtf.withLocale(locale).format(dateTime));
	}
	
	private static void Prueba5(){
		System.out.println(".........Prueba 5........");
		Locale l = Locale.getDefault();
		System.out.println(l + " " + l.getDisplayLanguage()+ " "+ l.getDisplayCountry()+" "+ l.getDisplayName());		
		Locale l2 = new Locale.Builder().setLanguage("it").setRegion("IT").build();
		System.out.println(l2 + " "+ l2.getDisplayLanguage() + " "+ l2.getDisplayCountry() + " "+ l2.getDisplayName());
	}
}
