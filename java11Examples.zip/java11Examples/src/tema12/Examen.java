package tema12;

import java.text.DecimalFormat;
import java.text.MessageFormat;
import java.text.NumberFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.Locale;
import java.util.ResourceBundle;

public class Examen {
	
	public static void main(String[] args) {
		Ejercicio1();
		Ejercicio2();
		Ejercicio3();
		Ejercicio4();
		Ejercicio5();
		Ejercicio6();
		Ejercicio7();
		Ejercicio8();
		Ejercicio9();
		Ejercicio10();
	}
	
	//P: ¿Qué sale por consola
	//R: 1, 2, 3, 4	
	private static void Ejercicio1() {
		System.out.println(".....Ejercicio 1.....");
		int N1 = 0_______0;
		var m = MessageFormat.format("{"+N1+"}, {"+ ++N1+"}, {"+ ++N1+"}, {"+ ++N1+"}", take2me("1","2","3","4","5","6"));
		System.out.println(m);
	}
	
	private static String[] take2me(String...args) {
		return args;
	}
	
	//P: Output
	//R: 1.000.000.000
	//	 1,000,000,000
	private static void Ejercicio2() {
		System.out.println(".....Ejercicio 2.....");
		var localAcademial = new Locale("en_UK");
		NumberFormat nf = NumberFormat.getInstance();
		Locale.setDefault(localAcademial);
		NumberFormat nf2 = NumberFormat.getInstance(Locale.getDefault());
		
		System.out.println(nf.format(1000000000));
		System.out.println(nf2.format(1000000000));
	}
	
	//P: ¿Cuáles son inválidos
	//R: uk_ua y CR, la primera por tener ua miniscula y la segunda por ser entero mayuscula
	private static void Ejercicio3() {

	}
	
	//P: Output
	//R: 2022-01-21
	private static void Ejercicio4() {
		System.out.println(".....Ejercicio 4......");
		var d = LocalDateTime.parse("2022-01-21T12:00:00", DateTimeFormatter.ISO_LOCAL_DATE_TIME);
		System.out.println(d.format(DateTimeFormatter.ISO_LOCAL_DATE));
	}

	//P: ¿Qué sale por consola?
	//R: ￥123,456,789
	private static void Ejercicio5() {
		System.out.println(".....Ejercicio 5.....");
		Locale.setDefault(Locale.ITALY);
		var j = NumberFormat.getCurrencyInstance(Locale.JAPAN).format(123456789);
		System.out.println(j);
	}
	
	//P: ¿Qué veremos al ejecutar este código?
	//R: F100000000123PolePosition
	private static void Ejercicio6() {
		System.out.println("......Ejercicio 6.......");
		NumberFormat propio = new DecimalFormat("F100000000123PolePosition");
		System.out.println(propio.format(123));
	}
	
	//P: ¿Qué sale por consola?
	//R: A, B, A, B, B
	private static void Ejercicio7() {
		System.out.println(".......Ejercicio 7.......");
		String baseString = "{0}, {1}, {0}, {1}, {00000001}";
		System.out.println(MessageFormat.format(baseString, "A", "B"));
	}
	
	//P: ¿Cuáles son correctos?
	//R: suegras.properties y Suegras_es.properties
	private static void Ejercicio8() {
		System.out.println("......Ejercicio 8.....");
		Locale.setDefault(new Locale("es", "AR"));
		var b = ResourceBundle.getBundle("Suegras");
		System.out.println(b.getString("suegra_name"));
	}
	
	//P: Output:
	//R: Una fecha en formato FULL
	private static void Ejercicio9() {
		System.out.println("......Ejercicio 9.....");
		Locale l = new Locale("es_ES#CAT@Barca");
		var buf = DateTimeFormatter.ISO_LOCAL_DATE.ISO_DATE_TIME.ofLocalizedDateTime(FormatStyle.FULL);
		var buff = LocalDateTime.now().atZone(ZoneId.of(ZoneId.getAvailableZoneIds().iterator().next()));
		System.out.println(buf.format(buff));
	}
	
	//P:¿Qué es necesario para que una fecha pueda ser formateada en FormatStyle.FULL?
	//R: Que tenga establecido el ZoneId
	private static void Ejercicio10() {
		System.out.println(".......Ejercicio 10......");
	}
}
