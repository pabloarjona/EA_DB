package tema12;

import java.text.MessageFormat;
import java.text.NumberFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.Locale;
import java.util.ResourceBundle;

public class Leccion {
	public static void main(String[] args) {
		Ejercicio1();
		Ejercicio2();
		Ejercicio3();
	}
	
	//P: Responda la respuesta correcta
	//R: Compilan todos
	private static void Ejercicio1() {
		System.out.println("......Ejercicio 1......");
		Locale.setDefault(new Locale.Builder().build());
		Locale.setDefault(Locale.CANADA_FRENCH);
		Locale.setDefault(new Locale("es_ES"));
		Locale.setDefault(new Locale("", "", ""));
	}
	
	//P: ¿Qué sale por consola?
	//R: true apaga y vamonos
	private static void Ejercicio2() {
		System.out.println("......Ejercicio 2......");
		System.out.println(ResourceBundle.getBundle("Leccion").containsKey("id"));
		System.out.println(ResourceBundle.getBundle("Leccion").getString("id")); 
	}
	
	//P: ¿Que sale por consola?
	//R: Felicidades Toño su saldo actual es ¤ 455.19 	
	private static void Ejercicio3() {
		System.out.println("......Ejercicio 3.......");
		var cf = NumberFormat.getCurrencyInstance();
		var mf = new MessageFormat("Felicidades {0} su saldo actual es {1} ", Locale.CHINA);
		System.out.println(mf.format(new Object[] {"Toño", cf.format(455.192)}));
	}
	
	//P: ¿De que tipo es la variable m?
	//R: String
	private static void Ejercicio4() {
		System.out.println(".......Ejercicio 4......");
		var cuqueision = DateTimeFormatter.ofLocalizedDate(FormatStyle.MEDIUM);
		//LocalDate.EPOCH = '1970-01-01'
		var m = cuqueision.format(LocalDate.EPOCH);
	}

}
