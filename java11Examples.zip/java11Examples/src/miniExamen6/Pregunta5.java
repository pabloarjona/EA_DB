package miniExamen6;

/* Pregunta 5 
 * Q: What is the minimum number of lines that need to be removed to male this code compile and be able to implemented as a lambda expressions?
 * A: 3. C
 */
@FunctionalInterface
public interface Pregunta5 {
	public static void baseball() {}
	private static void soccer() {}
	//default void play() {};
	//void fun();
	//void game();
	void toy();
}
