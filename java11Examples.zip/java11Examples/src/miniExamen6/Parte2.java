package miniExamen6;

import java.lang.Thread.State;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.locks.ReentrantLock;
import java.util.function.Consumer;

public class Parte2 {
	
	public static void main(String[] args) {
		//pregunta19();
		pregunta25();
	}
	
	/* Pregunta 15
	 * Q: ¿Cuantos válidos hay?
	 * A: c. 1
	 * module mi.modulo{
	 * 		exports paloma.es.coja;
	 * 		opens paloma.es.coja to palomo.cojo;
	 * }	
	 */
	
	/* Pregunta 17
	 * Q: Which describes a characteristic of setting up the Java development enviroment?
	 * A: C. You set up the Java development environment for a specific operating system when you install the JDK. 
	 */
	
	/* Pregunta 18
	 * Q: Given...
	 *    What is required to make the Foo class thread safe? 
	 * A: No change is required.
	 */
	private final ReentrantLock lock = new ReentrantLock();
	private State state;
	public void pregunta18() throws Exception{
		try {
			lock.lock();
			//state.mutate();
		}
		finally{
			lock.unlock();
		}
	}
	
	/* Pregunta 19
	 * Q: Given...
	 * A: E.apple:APPLE
			orange:ORANGE
			banana:BANANA
	 */
	private static void pregunta19() {
		List fruits = Arrays.asList("apple","orange", "banana");
		Consumer<String> c = System.out::print;
		Consumer<String> output = c.andThen(x -> System.out.println(":"+x.toUpperCase()));
		fruits.forEach(output);
	}
	
	/* Pregunta 20
	 * Q: ¿Qué salida por consola tenemos?  
	 * A: b. ninguna el código no compila
	 */
	private static void pregunta20() {
		var acction = "sumar";
		switch(acction) {
		case "restar":
			System.out.println("resto");
			break;
		default: 
			System.out.println("2 + 2 = "+3);
		/*ERROR DE COMPILACIÓN
			switched:
				while(true) {
					System.out.println("saludar");
				}
			break switched;*/
		}
	}
	
	/* Pregunta 21
	 * Q: Suponiendo que todo lo referente a las rutas y al operador ^ para poner comandos en múltiples líneas. 
	 *   ¿Esto es correcto?
	 *   javac D:\Eclipse\eclipse\worskpace\reader\src\module-info.java ^
	 *   D:\Eclipse\eclipse\worskpace\reader\src\reader\privado\ReaderPrivado.java
	 *   D:\Eclipse\eclipse\workspace\reader\src\reader\publico\ReaderPublic.java
	 * A: c. Correcto  
	 */
	
	/* Pregunta 24
	 * A: Which two safely validate inputs? (Choose two.)
	 * Q: B. Accept only valid characters and input values
	 *    C. Use trusted domain-specific libraries to validate inputs
	 */
	
	/* Pregunta 25
	 * A: Given: var fruits = List.of("apple","orange","banana", "lemon");
	 *    You want to examine the first element that contains the character n.
	 *    Which statement will accomplish this?
	 * Q: C. Optional<String> result = fruits.stream().filter(f -> f.contains("n")).findFirst();
	 */
	private static void pregunta25() {
		var fruits = List.of("apple", "orange", "banana", "lemon");
		Optional<String> result = fruits.stream().filter(f -> f.contains("n")).findFirst();
		//PRUEBAS
		String found = result.orElse("Not found");
		System.out.println(found);
	}
}

