package miniExamen6;

/* Pregunta 12
 * Q: ¿Es correcto este código?
 * A: No. Línea 6.
 */
class Pregunta12 implements Comparable{	
	
	public int id; 
	
	@Override
	public int compare(Object o) {
		Pregunta12 e = (Pregunta12) o;
		return e.id = this.id;
	}
}

