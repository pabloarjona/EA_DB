package miniExamen6;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.stream.Stream;

/** Pregunta 7
 * Q: Por consola sale un número. ¿Cuál es? 
 * A: a. Otro número
 */
public class Pregunta7 {

	public static Stream<String> readLines(Path p){
		try {
			return Files.lines(p);
		}catch(Exception e){
			throw new RuntimeException(e);
		}
	}
	
	public static long count(Path p) throws Exception{
		return Files.list(p).filter(w -> Files.isRegularFile(w)).
				map(s -> readLines(p)).count();
	}
	public static void main(String[] args) throws Exception{
		//Assumiendo que C:\Temp tiene 4 archivos de texto con 20 líneas entre los 4
		System.out.print(count(Paths.get("C:\\Java Exam\\PruebasCodigo")));
		//PRUEBAS:
		//System.out.print(count2(Paths.get("C:\\Java Exam\\PruebasCodigo")));
	}
	public static long count2(Path p) throws Exception {
	    return Files.list(p)
	            .filter(Files::isRegularFile)
	            .mapToLong(file -> {
	                try {
	                    return readLines(file).count();
	                } catch (Exception e) {
	                    throw new RuntimeException(e);
	                }
	            })
	            .sum();
	}

}
