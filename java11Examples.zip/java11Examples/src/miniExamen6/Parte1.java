package miniExamen6;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Stream;

public class Parte1 {
	
	public static void main(String[] args) throws Exception {
		//Pregunta4();
		//Pregunta5();
		//pregunta8();
		//pregunta9();
		//pregunta10();
		pregunta13();
	}
	
	public static void veleta(Future<?> f) {
		try {
			System.out.println(f.get(1, TimeUnit.DAYS));
		}catch(Exception e){
			System.out.println("omitir responsabilidad");
		}
	}
	
	/* Pregunta 3
	 * Q: ¿Esto es thread-safe?
	 * A:
	 */
	private static void Pregunta3() throws Exception{
		ExecutorService s = null;
		final var r = new ArrayList<Future<?>>();
		try {
			s = Executors.newSingleThreadExecutor();
			for(int i = 0; i<10; i++) {
				final int arrimadas = i;
				r.add(s.submit(() -> arrimadas +1));
			}
			r.forEach(Parte1::veleta);
		}finally {
			if(s != null) {
				s.shutdown();
			}
		}
	}
	
	/* Pregunta4
	 * Q: ¿Qué sale por consola?
	 * A: d.20
	 */
	private static void Pregunta4() {
		List<Integer> nums = Arrays.asList(1,2,3,4,6,7,8,9);
		Predicate<Integer> pi = nums::contains;     // para ver si tiene el número proporcionado
		Optional<Integer> oi = Stream.of(1,3,5,7,9).filter(pi).reduce((x,y) -> x+y);   //reduce para sumar los números
		System.out.println(oi.get());     //obtiene el valor si esta presente
		//Prueba
		Consumer<Integer> consumer = System.out::println;
		nums.forEach(consumer);
	}
	/* Pregunta 6
	 * Q: Given the code fragment:
	 *    ....
	 *    What is the result?
	 * A:  
	 *   
	 */
	private static void Pregunta5() {
		for(var i = 0; i<10; i++) {
			switch(i%5) {
			case 2:
				i*=2*i;
				break;
			case 3: 
				i++;
				break;
			case 1:
			case 4: 
				i++;
				continue;
			default: 
				break;	
			}
			System.out.println(i+" ");   //esto se ejecuta después de hacer break y sin hacerlo
			i++;
		}
	}
	
	/* Pregunta 8
	 * Q: What is the output of the following? (Choose three.)
	 * 		var chars = new ______<Character>();

	 * A: A. When inserting ArrayList into the blank, the code prints 1 false;
	 *    D. When inserting HashMap into the blank, the code does not compile
	 *    F. When inserting HashSet into the blank, the code does not compile
	 */
	private static void pregunta8() {
		var chars = new ArrayList<Character>();
		/* Codigo no compila
		var chars = new ArrayList<Character>();
		var chars = new ArrayList<Character>();*/
		chars.add('a');
		chars.add(Character.valueOf('b'));
		chars.set(1, 'c');
		chars.remove(0);
		System.out.print(chars.size()+ " "+chars.contains('b'));
	}
	
	/* Pregunta 10
	 * Q: Which fills in the blank so the code is guaranteed to print 1?
	 * 	 var stream = Stream.of(1,2,3);
	 * 	 System.out.println(stream.______);
	 * A: E. None of the above
	 */
	private static void pregunta9() {
		var stream = Stream.of(1,2,3);
		System.out.println(stream);
		
	}
	
	/* Pregunta 11
	 * Q: Which annotation should be used to remove warning from compilation?
	 * A: D. @SuppressWarnings("all")
	 */
	@SuppressWarnings("all")
	private static void pregunta10() {
		List l = new ArrayList<>();
		l.add("hello");
		l.add("world");
		print(l);
	}
	@SuppressWarnings("all")
	private static void print(List<String>... args) {
		for(List<String> str: args) {
			System.out.println(str);
		}
	}
	
	/* Pregunta 12
	 * Q: ¿Qué líneas fallan?
	 * A: a. 3, 7
	 */
	private static void pregunta11() {
		BiFunction<Double, Double, Double> paca;
	//	BinaryOperator<Double> puri = paca; ERROR
		Function<Double, Double> luci;
	//	DoubleFunction<Double> paqui = luci; ERROR
	}
	
	/* Pregunta 13
	 * Q: ¿Qué sale por consola?
	 * A: A, B, A, B, B
	 */
	private static void pregunta13() {
		String baseString = "{0}, {1}, {0}, {1}, {000001}";
		System.out.print(MessageFormat.format(baseString, "A", "B"));
	}
	
	/* Pregunta 14
	 * Q: Which two statements correctly describe capabilities of interfaces and abstract classes? (Choose two.)
	 * Teoría: 
	 * 	Interfaces: múltiples herencias, contratos que las clases deben cumplir, permiten abstracción, 
	 * 			   pueden contener métodos con implementaciones predeterminadas y métodos estáticos.
	 * 	Uso: Puede usar métodos con cuerpo (default) y métodos estáticos . No se pueden usar métodos protected 
	 *       ni final.
	 * 	
	 *  Abstractas: herencia única, métodos abstractos (sin implem..) y concretos (con implementación), puede 
	 * 			    tener constructores, puede tener variables de instalación.
	 *  Uso: Pueden tener cualquier modificar de acceso (incluido protected). Puede usar un final method y significará
	 *       que no puede ser sobreescrito.
	 *  
	 *  Casos de uso: se usa una clase abstracta cuando quieras proporcionar una implementación base y una 
	 *                interfaz cuando quieres definir una capacidad o permitir herencia múltiple
	 * A: A. Interfaces cannot have protected methods but abstract classes can.
	 *    C. Interfaces cannot have methods with bodies but abstract classes can.
	 */
}

