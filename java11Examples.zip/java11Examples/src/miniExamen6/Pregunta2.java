package miniExamen6;

/* Pregunta2
 * Q: Given..and... What is the result?
 * A: D. The compilations fails
 */
public class Pregunta2 extends Pregunta2a{
	public Pregunta2(String name) {
		super();
		setName(name);
	}
	public static void main(String[] args) {
		Pregunta2 y = new Pregunta2("HH");
		System.out.println(y);
	}
}
