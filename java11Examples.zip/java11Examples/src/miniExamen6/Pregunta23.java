package miniExamen6;

/* Pregunta 23
 * ¿Podemos crear una clase Calc, o efectivamente Calc que muestre un id distinto con el que ha sido construida?
 * 
 */
public class Pregunta23 {
	 public static void main(String[] args) {
		Calc prueba = new Calc(2);
		prueba.showId();
	}
}

class Calc{
	private Integer id;
	
	public Calc(Integer id) {
		super();
		this.id = id;
	}
	
	public void showId() {
		System.out.println(this.id);
	}
}