package miniExamen6;
//COMENTAR DANI
/* Pregunta 1.
 * Q: ¿Dónde falla este código?
 * A: d. Línea 19
 */
abstract class Nueve{
	
}

public class Pregunta1 {
	protected class Diez extends Nueve implements Ocho{
		
	}
	
	abstract static class Seis{
		
	}
	
	public void siete() {
		class Cuatro extends Cinco{
			
		}
	}

	private interface Ocho{
		
	}
	
	final class Cinco extends Diez{
		
	}
}
