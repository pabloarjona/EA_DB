package miniExamen6;

import java.util.HashMap;

/* Pregunta22
 * Q: ¿Qué sale por conola? (si es que sale algo...)
 * A: b. Hala Madrid
 */
public class Pregunta22 {
	public static void main(String[] args) {
		var bar = new OwnMap<Integer, String>();
		bar.put(1, "Hala Madrid");
		bar.put(2, "Leganes");
		bar.put(3, "Fuenlabrada");
		
		if(bar.containsValue("Fuenalabrada")) {
			bar.clear();
		}
		
		bar.halaMadrid();
	}
	
}

class OwnMap<K, V> extends HashMap<K, V>{
	void halaMadrid() {
		System.out.println("Hala Madrid");
	}
}
