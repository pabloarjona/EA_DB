package tema10;

import java.io.FilePermission;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.AccessController;
import java.security.PrivilegedAction;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;

public class Examen extends EntidadGenerica<String>{
	
	public static void main(String[] args) {
		System.out.println(Ejercicio1("AX"));
	}
	private static final List<String> permitidos = Arrays.asList("A","B","H","G", "P");
	private static final List<String> bloqueados = Arrays.asList("F","X","W", "Z","Y");
	
	//Ejercicio 3
	//P: ¿Qué tipo de input-validation posee este código?
	//R: Lista blanca y lista negra
	public static boolean Ejercicio1(String rol) {
		return permitidos.contains(rol) && !bloqueados.contains(rol);
	}
	
	//Ejercicio 4
	//P: ¿Cómo evitar que password sea visible desde fuera de su package?
	//R: sobreescribiendo el metodo toString() para que haga un throws OperationNotSupportedException
	private final String password;
	
	public Examen(String password) {
		super();
		this.password = password;
	}
	
	protected String getPassword() {
		return this.password;
	}
	
	@Override String getId() {
		return this.password;
	}
	
	/*	Ejercicio 5:
	 * P: Hay más de una correcta (por fin somos originales)
	 * De las siguientes: ¿Cuáles son las mejores opciones para prevenir SQL injection?
	 * R:
	 * C. Evitar la concatenación de String en las querys 
	 * E. Usar siempre PreparedStatement en vez de Statement 
	 */
	
	/*	Ejercicio 6
	 * P: Este código es vulnerable a:
	 * R: SQL injection
	 */
	public boolean isValid(Connection con, String dni) throws SQLException{
		var sql ="SELECT * FROM users WHERE dni = ?";
		try (PreparedStatement ps = con.prepareStatement(sql)){
			ps.setString(1, dni);
			try (ResultSet rs = ps.executeQuery(sql)){
				return rs.next();				
			}
		}finally {
			con.close();
		}
	}
	
	/*
	 * Ejercicio 7
	 * P: Tenemos que realizar una funcionalidad y para ello necesitamos leer este archivo. ¿Esto es correcto?
	 * R: No
	 * 
	 * grant{
	 * 		permission java.io.FilePermision
	 * 		"c:/Temp/ceuntas.txt",
	 * 		"read, write";
	 * };
	 */
	
	/**
	 * Ejercicio 8
	 * P: Este código esta hecho para prevenir ataques DoS. ¿Esto es así?
	 * R: NO
	 * Habría que meter el connection y los statement en un try catch para que lo fuera
	 * @param jdbc
	 * @param alarmed
	 * @return
	 * @throws SQLException
	 */
	public String Ejercicio8(String jdbc, boolean alarmed) throws SQLException {
		var query = "SELECT * FROM laliga WHERE pichici = " + alarmed;
		var con = DriverManager.getConnection(jdbc);
		var s = con.createStatement();
		try (var rs = s.executeQuery("nombre")){
			return rs.next() ? rs.getString("nombre") : null;
		}
	}
	/**
	 * Ejercicio 9
	 * P: ¿Este código es seguro? Supongamos que file siempre existe y se comprueba correctamente antes de llamar a este método
	 * R: No, puede hacer que nuestra aplicación de error
	 */
	private static final List<String> files = List.of("oneArhcivo.txt","twoArchivo.txt");
	
	public static void main(String file) {
		var perm = new FilePermission(file, "write");
		AccessController.checkPermission(perm);
		AccessController.doPrivileged(new PrivilegedAction<Void>() {
			@Override
			public Void run() {
				if(files.contains(file)) {
					try {
						Files.lines(Paths.get(file)).count();
					}catch (IOException e) {
						e.printStackTrace();
					}
				}
				return null;
			}
		});
	}
}
//Ejercicio 1
//P: ¿Podemos crear una clase Cal, o efectivamente Calc que muestre un id distinto con el que ha sido construida?
//R: Se puede mostrar un id distinto al que ha sido construida
//No se podría si la clase Ejercicio2 fuese final, ya que podríamos generar una clase que extienda de Ejercicio2 y
//sobreescribir métodos
class Ejercicio2{
	//COMO ES UN FINAL SOLO PUEDE SER MODIFICADO EN EL CONSTRUCTOR
	private final Integer id;
	
	public Ejercicio2(Integer id) {
		super();
		this.id = id;
	}
	
	public void showId() {
		System.out.println(this.id);
	}
}
//Ejercicio 2
//P: ¿Con qué principios de seguridad cumple esta clase?
//R: Restricción de herencia
class Ejercicio3{
	private int all;
	
	public Ejercicio3(int people) {
		this.all = people;
	}
	
	public int getLength() {
		return all;
	}
}

abstract class EntidadGenerica<E>{
	abstract E getId();
	
	public String toString() {
		return String.valueOf(getId());
	}
}
