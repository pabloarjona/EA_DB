package tema10;

public class TeoriaSecureCoding {
	
	/**
	 * Ataque de denegación de servicio (DoS) es cuando se realizan una o más peticiones con la intención de interrumpir las peticiones
	 * legítimas
	 * 
	 * Huge Resources o recursos enormes sucede cuando te pasan un recurso gigante que puede llegar a colapsar tu memoria. Como un 
	 * archivo o un HashMap, Array, etc.. Para escribir un buen código debes de controlar el tamaño de los recursos.
	 * 
	 * Overflow Numbers o desbordamiento numérico ocurre cuando superamos el máximo valor de un tipo int o long en java. Esto hará
	 * que el número se vuelva negativo. Por ello hay que comprobar los valores máximos que se pueden manejar
	 * 
	 * Leaking Resources o fuga de recursos sucede cuando no cierras un recurso, por ejemplo un fichero. De esta manera si se le hacen 
	 * muchas peticiones, terminarías destruyendo la aplicación. Para ello se recomienda usar try/catch/resources o cerrad los recursos.
	 * 
	 * Expandable Resources o recursos extensibles sucede cuando el recurso suministrado es en realidad trampa, como por ejemplo un 
	 * .zip de poco tamaño que esconde un archivo de varios GB  o un fichero XML. Por ello hay que controlar lo que sucede dentro de tu 
	 * lógica con los recursos.
	 * 
	 * CODE INJECTION & INPUT VALIDATION
	 * 
	 * Code Injection sucede cuando parte de tu ejecución llega en forma de parámetro. Por ejemplo, tienes una página muy bonita con un
	 * campo de texto que pone "Introduce ID de factura", ese campo será pasado como parámetro a un método que recibe un ID de factura
	 * y te la devuelve, que pasa si te ponen "IS NOT NULL". 
	 * 
	 * Input Validation consiste en comprobar y válidar esos parámetros de manera que tengamos la certeza de que solo ejecutamos lo que
	 * nos interesa. Por ejemplo, si tenemos un méotodo que borra archivos en un directorio, no debería poder recibir ..\ o la vamos a 
	 * a liar. Una solución reconocida de input validation es usar un sistema de listas blancas y negras con los valores a acpetar  o 
	 * los valores a omitir (o ambos).
	 * 
	 * DATA INTEGRITY
	 * ¿Qué ocurre si dos métodos se ejecutan a la vez?
	 * Con la integridad de los datos nos referimos a crear un código atómico que mantenga esa integridad como vimos en el apartado 
	 * Securing del tema 8.
	 * 
	 * Secure resource access including filesystems
	 * Dentro de lib/security tenemos un archivo defualt.policy
	 * En principio para el examen solo debemos saber interpretarlo, por suerte es auto-explicativo. En el siguiente ejemplo 
	 * restringiríamos a "solo lectura"
	 * 
	 * Ej:
	 * El acceso al archivo file.txt impidiendo su escritura etc...
	 * grant{
	 * 		permission java.io.FilePermission
	 * 			"C:\\Temp\\file.txt"
	 * 			"read";
	 * };
	 * 
	 * Podemos especificar la policía de acceso a cualquier recurso... la lista es interminable pero solo hay que enteder la sintaxis.
	 * 
	 * Executed privileged code
	 * Esto se hacía con AccessController.doPrivileged() que recibe una implementación de la interfaz PrivilegedAction<?> que tiene 
	 * un único método <?> run que devolvía el tipado.
	 * 
	 * Sin embargo, esta clase esta deprecada.. En principio sirve para Ejecutar código con el máximo nivel de permiso establecido
	 * aún si ha de saltarse lo especificado en el default.policy
	 * 
	 * DoS (Denegation attacks of servicies)
	 * 1. Usa siempre try/catch/resources o cerrar todos los recursos
	 * 2. Comprobar el tamaño de los recursos
	 * 
	 * Proteger la información confidencial 
	 * 1. Usar estructuras tipo char[] para passwords.
	 * 2. Evitar las referencias en memoria para que pase lo antes posible el garbage collector (administra de forma automática la 
	 * memoria, ya que es el encargado de liberar los objetos que ya no están en uso).
	 * 3. Evitar la posible salida por consola de datos confidenciasles, Logs, etc.
	 * 
	 * Evitar el code-injection 
	 * 1. Usando white y black Lists
	 * 2. Restringuiendo la entrada 
	 * 3. Palabras reservadas
	 * 
	 * Diseña objetos seguros
	 * 1. Evitando su extensión involuntaria (final)
	 * 2. Devolviendo copias de sus atributos
	 * 3. Haciendo sus atributos inmutables
	 * 4. Usando input validation 
	 * 5. Encapsulando sus métodos atributoos (private...)
	 * 
	 * Valida la serialización y la des-serialización de tus objetos 
	 * 1. Transient para propiedades críticas 
	 * 2. Sobre-escribiendo los métodos writeObject() y readObject()
	 * 
	 * Existe un método para hackear que es la modificación de los objetos serializados.
	 */
	

}
