package tema10;

abstract class ClaseAbstracta {
	public abstract void hacerSonido();
	
	public final void metodoFinal() {
		System.out.println("Este método no puede ser sobrescrito");
	}
	
	public void dormir() {
		System.out.println("Zzz");
	}
}

class Perro extends ClaseAbstracta{

	public void hacerSonido() {
		System.out.println("Guau");
	}	
	
}