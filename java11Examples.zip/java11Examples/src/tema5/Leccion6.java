package tema5;

import java.util.List;

public class Leccion6 {

	List<<String>> __;


	public static void main(String[] args) {
		String[] x = {};
	
		System.out.println(x.length());
	}
}
