package tema5;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedList;

class X3D<$$$>{
	
}

class X4D<X4D>{
	
}

class X5D<X4D>{
	
}

class X6D<? extends Serializaable>{
	
}
public class Examen {
	
	
	//erorr-> int[] ns = new int[2] {1,2};
	String[] ss = new String[] {};
	//String[] sse = new String[0] {};
	//String[] ssas = new String[] {parametros};
	Object array = new String[128];
	//String xq= array[66];
	public static void main(String[] args) {
		var x = Arrays.asList("soy", "inmodificable", "o constante");
		var l = new LinkedList<>(x);
		var a = new ArrayList<>(l);
		
		Iterator<?> aa = a.iterator();
		aa.next(); aa.remove();
		
		Iterator<?> xx = x.iterator();
		xx.next(); xx.remove();
				
	}

}
