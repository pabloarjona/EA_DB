package tema5;

import java.io.Serializable;
import java.util.List;

public class Leccion1 {

	abstract class Disney<Serializable extends Cloneable> {}
	final class Netflix implements Serializable, Cloneable {}
	class HBO<E extends Netflix> extends Disney<E> {}
	
	public static void main(String...args) {
		
		Netflix n = new Leccion1().new Netflix();
		HBO<Netflix> chemita = new Leccion1().new HBO<>();
	}
}
