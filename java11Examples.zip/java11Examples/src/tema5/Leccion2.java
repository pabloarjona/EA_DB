package tema5;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Leccion2 {

	public static void main(String... casoEspecial) {
		
		List<Object> lista = new ArrayList<>();
		lista.add("");
		lista.add("");
		lista.add(1);
		lista.add(LocalDate.now());
		
		lista.remove("");
		
		System.out.println(lista.size());;
	}
}
