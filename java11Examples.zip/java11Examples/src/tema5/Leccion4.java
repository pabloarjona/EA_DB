package tema5;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

class G implements Comparable<G>, Comparator<G> {
	
	public int pk;
	
	public G(int pk) {
		super();
		this.pk = pk;
	}
	public int compareTo(G o) {
		return  o.pk - this.pk;
	}
	public int compare(G o1, G o2) {
		return o1.pk - o2.pk;
	}
}
public class Leccion4 {
	
	public static void main(String... GasoEspeGial) {
		var gs = new ArrayList<G>();
		gs.add(new G(3));
		gs.add(new G(5));
		gs.add(new G(1));
		gs.add(new G(4));
		gs.add(new G(2));
		
		gs.sort(gs.get(0));
		
		Collections.sort(gs);
		
		for (G G : gs) {
			System.out.print(G.pk);
		}
		
	}
	
}

