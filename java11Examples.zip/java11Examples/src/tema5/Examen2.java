package tema5;

import java.util.ArrayDeque;

public class Examen2 {
	
	public static void main(String[] args) {
		var d = new ArrayDeque<Integer>();
		d.offer(11);
		d.offer(22);
		d.offer(33);
		
		//pop te devuelve el elmento que eliminas
		//poll igual
		//recuperar el último elemento de la lista pero no lo elimina
		System.out.println(d.pop() + " "+d.poll()+ " " + d.peek()+ " "+ d.size());
	}

}
