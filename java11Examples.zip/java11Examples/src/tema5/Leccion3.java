package tema5;

import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.Deque;

public class Leccion3 {

	boolean [][] y = {{true,false}};
	
	public static void main(String[] args) {
		Deque<Integer> d = new ArrayDeque<>(Arrays.asList(1,2,3,4,5,6,7,8,9));
		d.add(0); 			//añade al final de la cola (booleano)
		d.offer(0); 		//añade al final de la cola, (booleano) false si no puede insertarlo
		d.pop();    		//elimina elemento al principio de la cola 
		d.addLast(0);		//inserta elemento al final de la cola (void)
		d.addFirst(0);      //inserta elemento al prinicipio de la cola
		d.poll();			//elimina elemento al principio de la cola
		d.push(0);			//inserta elemento al principio de la cola
		d.removeFirst();	//elimina elemento al principio de la cola	
			
		System.out.println("Tamaño deque-> "+d.size());
		System.out.println("Valores deque...");
		//d.forEach(System.out::print);
		for (Integer i : d) {
			System.out.println(i);
		}
	}
	
}
