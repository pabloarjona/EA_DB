package tema5;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Leccion5 {

	
	public static void main(String[] args) {
		String[] x = {};
		
	//Error	System.out.println(x.length());
		Set<String> saco = new HashSet<>();
		saco.add("1");
		saco.add("2");
		saco.add("3");

		saco.remove(2);

		System.out.println(saco.size());
	}
}
