package miniExamen2;

import java.util.Arrays;
import java.util.Comparator;

/**
 * Pregunta 15
 * Q: Given:...
 * You wan the code to produce:
 * John joe
 * Jane 
 * Which code fragment should be inserted on line 1 and line 2 to produce the 
 * output?
 * A: A. Insert Comparator<Person> on line 1.
 * 	  	 Insert 
 * 		 public int compare(Person p1, Person p2){
 * 			return p1.name.compare(p2.name);
 * 		} on line 2
 */
public class Pregunta15 {
	static class Person implements /*line 1*/ Comparator<Person>{
		private String name;
		Person(String name){this.name=name;}
		/*line 2*/
		public int compare(Person p1, Person p2){
			return p1.name.compareTo(p2.name);
		}
	}
	
	public static void main(String[] args) {
		Person[] people = { new Person("Joe"),
							new Person("Jane"),
							new Person("John")};
		Arrays.sort(people);
		for(Person person: people) {
			System.out.println(person.name);
		}
	}

}
