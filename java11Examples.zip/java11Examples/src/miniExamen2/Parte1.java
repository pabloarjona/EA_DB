package miniExamen2;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;

public class Parte1 {
	public static void main(String[] args) {
		//Pregunta1();
		//Pregunta5();
		Pregunta8();
		//Pregunta12();
		//Pregunta13();	
	}
	/**Q. Given...
	 * Assume the file on the path does not exist
	 * What is the result?
	 * A: B./u1/work/filestore.txt is not deleted
	*/
	private static void Pregunta1() {
		try {
			Path path = Paths.get("/u01/work/filestore.txt");
			boolean result = Files.deleteIfExists(path);
			if(result) System.out.println(path+" is deleted");
			else System.out.println(path + " is not deleted");
		}catch(IOException e){
			System.out.println("Exception");
		}
	}
	
	/*
	 * Q. Given...
	 * What is the result?
	 * A: 
	 * D. 1
	 * 1
	 * 1
	 */
	private static void Pregunta3() {
		String[] words = {"banana", "orange", "apple", "lemon"};
		Integer[] numbers = {1,2,3,4,5};
		CustomType type = new CustomType();
		CustomType<String> stringType = new CustomType<>();
		System.out.println(stringType.count(words, "apple"));
		System.out.println(type.count(words, "apple"));
		System.out.println(type.count(numbers, 3));
	}
	
	/*
	 * Q. Given...
	 * And the command: java main Helloworld
	 * What is the result?
	 * A: Input:
	 * 	  Then block until any input comes from System.in.
	 */
	private static void Pregunta5() {
		try (BufferedReader in = new BufferedReader(new InputStreamReader(System.in))){
			System.out.println("Input: ");
			String input = in.readLine();
			System.out.println("Echo: "+input);
		}catch(IOException e){
			e.printStackTrace();
		}
	}
	
	/**
	 * Q. Which is proper JDBC URL?
	 * A: jdbc:myssql://localhost:3306/database
	 */
	
	/**
	 * Q. Given...
	 * What is the output?
	 * A: C.
	 * 	apple:APPLE
		orange:ORANGE
		banana:BANANA
	 */
	private static void Pregunta8() {
		List fruits = Arrays.asList("apple", "orange", "banana");
		Consumer<String> c = System.out::print;
		Consumer<String> output = c.andThen(x -> System.out.println(":"+x.toUpperCase()));
		fruits.forEach(output);
	}
	
	/**
	 * Q. Given...
	 * What will secure this code from a potential Denial of Service condition?
	 * A: D. On Line 1, use try with resources when opening each dataReader
	 */
	private static void Pregunta9() {
		List<Reader> dataFiles = new ArrayList<>();
		File indexFile = new File("MyIndex.idx");
		try (BufferedReader indexReader = new BufferedReader(new FileReader(indexFile))){
			for(String file = indexReader.readLine(); file!=null; file = indexReader.readLine()){
				BufferedReader dataReader = new BufferedReader(
						new FileReader(new File(file)));     //Line 1
				dataFiles.add(dataReader);
				processData(dataReader);
			}
		}catch(IOException ex){
			
		}finally {
			for(Reader r : dataFiles) {
				try {
					r.close();
				}catch(IOException ex){
					
				}//Line 4
			}
		}
	}
	private static void processData(BufferedReader dataReader) {
		// TODO Auto-generated method stub
		
	}
	
	/** Pregunta 10 
	 * Q. Which statement about a functional interface is true?	
	 * A: It is declared with a single abstract method.
	 */
	
	/* Pregunta 11
	 * Q: A company has an existing sales application using a Java 8 jar 
	 * file containing packages:
	 *  com.company.customer; com.company.customer.orders; 
		com.company.customer.info; com.company.sales; 
		com.company.sales.leads; com.company.sales.closed; 
		com.company.orders; com.company.orders.pending; 
		com.company.orders.shipped.
	 * A: B.
	 * module com.company.customer {
	 * 		exports com.company.customer;
	 * }
	 * 
	 * module com.company.sales {
	 * 		exports com.company.sales;
	 * }
	 *
	 * module com.company.orders {
	 * 		exports com.company.orders;
	 * }
	 * 
	 *  
	 */
	
	/** Pregunta 12
	 * Q: Given...
	 * A: data\another-project
	 */
	private static void Pregunta12() {
		String originalPath = "data\\projects\\a-project\\..\\..\\another-project";
		Path path = Paths.get(originalPath); 
		System.out.println(path.normalize());
	}
	
	/** Pregunta 13
	 * Q: Given...
	 * Which is true?
	 * A: System.out is an instance of java.io.OuputStream by default
	 */
	private static void Pregunta13() {
		try (BufferedReader br = new BufferedReader(new InputStreamReader(System.in))){
			String input = br.readLine();
			System.out.println("Input String was: "+ input);
		}catch(IOException e){
			e.printStackTrace();
		}
	}
	
	/** Pregunta 14
	 *  Q: Which interface in the java.util.function package will return a void
	 *  return type?
	 *  A: Consumer
	 */
	
}
