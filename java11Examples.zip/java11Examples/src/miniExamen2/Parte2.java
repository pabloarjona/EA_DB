package miniExamen2;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BinaryOperator;
import java.util.function.Consumer;
import java.util.stream.IntStream;
import java.util.stream.Stream;

import MiniExamen1.ExternalClasses.Employee;

public class Parte2 {
	public static void main(String[] args) {
		//Pregunta19();
		//Pregunta20();
		//Pregunta21();
		//Pregunta22();
		int[] arrayInt = {1,2,7,2,19,2,1,4,18};
		//Pregunta23(arrayInt);
		Pregunta24();
	}
	/**Pregunta 19
	 * Q: Given...
	 * A: B. double totalSalary = list.stream().mapToDouble(e -> e.getSalary() * ratio).sum();
	 */
	private static void Pregunta19() {
		List<Employee> list = List.of(new Employee("John", 80000.0), new Employee("Scott", 90000.0));
		double starts = 0.0;
		double ratio = 1.0;
		BinaryOperator<Double> bo = (a, b) -> a+b;
		double totalSalary = list.stream().map(e -> e.getSalary() * ratio).reduce(starts, bo); //line 1
		System.out.println("Total salary = " + totalSalary);
	}
	
	/*
	 * Q: Given...
	 * A: B. An exception is thrown at run time.
	 */
	private static void Pregunta20() {
		List<String> list1 = new ArrayList<>();
		list1.add("A");
		list1.add("B");
		List list2 = List.copyOf(list1);
		list2.add("C");
		List<List<String>> list3 = List.of(list1, list2);
		System.out.println(list3);
	}
	
	/*
	 * Pregunta 21
	 * Q: Given...
	 * This coide results in a compilation error.
	 * Which code should be inserted on line 1 for a successful compilation?
	 * A: D. Consumer consumer = System.out::print; //line 1 
	 */
	private static void Pregunta21() {
		//question
		//Consumer consumer = msg -> System.out::print; //line 1
		//correct answer
		Consumer consumer = System.out::print;
		consumer.accept("Hello Lambda! ");
	}
	
	/* Pregunta 22.
	 * Q: Given...
	 * 	  What is the result?
	 * A: 6104 3
	 */
	private static void Pregunta22() {
		int arr[][] = {{5, 10}, {8,12},{9,3}};
		long count = Stream.of(arr)
				.flatMapToInt(IntStream::of)  //convierte cada elemento en un flujo de enteros, útil para matrices, array de array...
				.map(n -> n + 1)              // suma 1 a cada número en el flujo
				.filter(n -> (n%2 == 0))      // filtra los número pares
				.peek(System.out::print)	  // imprime cada número par en la corriente
				.count();					  // cuenta la cantidad de números pares en el flujo
		System.out.println(" "+ count);
	}
	
	/*Pregunta 23
	 * Q: Given...
	 * After which line can we insert assert i<0 || values[i] <= values[i+1]; to verify that the values
	 * array is partially sorted?
	 * A: D: after line 10
	 */
	private static void Pregunta23(int values[]) {
		int n = values.length;
		for(int j = 1; j<n; j++) {
			int tmp = values[j];
			int i = j-1;
			while((i > -1) && (values[i] > tmp)) {
				values[i+1] = values[i];
				i--;
			}
			values[i+1] = tmp; //line 10
			if(i<0 || values[i] <= values[i+1]) {
				//esta ordenado
			}
		}
		//COMPROBACIÓN
		System.out.print("LISTA ORDENADA: ");
		for(int i=0; i <values.length; i++) {
			System.out.print(values[i]+ " ");
		}
	}
	
	/**Pregunta 24
	 * Q: Which code is correct?
	 * A: C: Runnable r = () => {System.out.println("Message");};
	 */
	private static void Pregunta24() {
		Runnable r = () -> {System.out.println("Message");};
		r.run();
	}	
	
	/** Pregunta 25
	 *  Q: Given...
	 *  You want to use the myResource class in a try-with-resources statement
	 *  Which change will accomplish this?
	 *  A: Implements AutoCloseable and override the autoClose method
	 * @throws Exception 
	 */
	private static void Pregunta25() throws Exception {
		try (MyResource resource = new MyResource()){
			resource.operacion();
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
}

