package miniExamen2;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.Serializable;
import java.time.LocalDateTime;

/*
 * Pregunta 16.
 * Q: Given...
 * 	  When is the readObject method called?
 * A: before the object is deserialized
 */
public class Preguna16 implements Serializable{
	String message;
	LocalDateTime createdTime;
	//transient: se exclute del proceso de serialización
	transient LocalDateTime updatedDateTime;
	Preguna16(String message){
		this.message = message;
		this.createdTime = LocalDateTime.now();
	}
	private void readObject(ObjectInputStream in) {
		try {
			in.defaultReadObject();
			this.updatedDateTime = LocalDateTime.now();
		}catch (IOException | ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
}
