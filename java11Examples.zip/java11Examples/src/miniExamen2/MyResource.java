package miniExamen2;

public class MyResource implements AutoCloseable{

	public MyResource() {
		
	}
	
	public void operacion() {
		System.out.println("Realizando una operación en mi recurso...");
	}
	
	@Override
	public void close() throws Exception {
		System.out.println("Cerrando mi recurso de manera personalizada...");
	}
	
}
