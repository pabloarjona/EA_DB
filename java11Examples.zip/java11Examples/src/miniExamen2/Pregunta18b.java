package miniExamen2;

public class Pregunta18b {
	@Pregunta18a (date="1-1-2020", comments="Hello")
	public void func1() {}
	
	@Pregunta18a(date="1-1-2020", author="Gandhi", comments= {"world"})
	public void func2() {}
	
	@Pregunta18a(date="1-1-2020")
	public void func3() {}
}