package miniExamen2;

import java.time.LocalDate;
import java.time.chrono.IsoChronology;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import java.util.function.Predicate;
import java.util.stream.Collectors;

/**
 * Pregunta 17
 * Q: Given...
 *    Which code fragment on line 1 makes the s1 set contain the names of all employees born before January 1, 1989?
 * A: A. 
 * 	    .collect(Collectors.partitioningBy(y))
		.get(true)
		.stream()
		.map(Employee::getName)
		.collect(Collectors.toCollection(TreeSet::new));
 */
public class Pregunta17 {
	public static class Employee{
		private String name;
		private LocalDate birthday;
		//the constructors, getters, and setters methods go here
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public LocalDate getBirthday() {
			return birthday;
		}
		public void setBirthday(LocalDate birthday) {
			this.birthday = birthday;
		}
		public Employee(String name, LocalDate bd) {
			this.name = name;
			this.birthday = bd;
		}
	}
	
	public static void main(String[] args) {
		List<Employee> roster = new ArrayList<>();
		//Prueba
		LocalDate fecha = LocalDate.of(1980, 1, 1);
		Employee e1 = new Employee("Pablo", fecha);
		roster.add(e1);
		//fin prueba
		Predicate<Employee> y = (Employee e) -> e.getBirthday()
				.isBefore(IsoChronology.INSTANCE.date(1989, 1, 1));
		Set<String> s1 = roster.stream() //line 1
				.collect(Collectors.partitioningBy(y))
				.get(true)
				.stream()
				.map(Employee::getName)
				.collect(Collectors.toCollection(TreeSet::new));
		
		//Prueba
		for(String e : s1) {
			System.out.println(e);
		}
		//
	}

}
