package miniExamen2;

public class Pregunta4 {
	
	public static void doThings() throws GeneralException{
		try {
			throw new RuntimeException("Something happened");
		}catch(Exception e){
			throw new SpecificException(e.getMessage());
		}
	}
	
	public static void main(String[] args) {
		try {
			Pregunta4.doThings();
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
	}
}
class GeneralException /*line 1*/ extends Exception{
	public GeneralException(String s) { super(s);} 
}
class SpecificException /*line 2*/ extends GeneralException{
	public SpecificException(String s) { super(s);}
}
