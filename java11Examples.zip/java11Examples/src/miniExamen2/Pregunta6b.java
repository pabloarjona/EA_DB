package miniExamen2;

public final class Pregunta6b extends Pregunta6a{

}
