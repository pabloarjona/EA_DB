package miniExamen2;
/*
 * Q. Given..
 * public class X{
 * } and
 * public final class Y extends X{
 * }
 * What is the result of compiling these two classes?
 * A: The compilation succeeds.
 */
public class Pregunta6a {
	
}


