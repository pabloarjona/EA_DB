package miniExamen2;

public class Pregunta2 {
	/*
	 * Q. Given...
	 * Which three actions implement Java SE security guidelines?(Choose three.)
	 * A:
	 * A. Change line 7 to return names.clone();
	 * B. Changes line 4 to this.names= names.clone();
	 * E. Change line 2 to private final String[] names;
	 */
	String[]names;   //line 2
	public Pregunta2(String[] names) {
		this.names = names;  //line 4
	}
	
	public String[] getNames() {
		return names;   //line 7
	}
}
