package tema1;

import java.util.ArrayList;
import java.util.List;
class A {
	String nameClaseA;
	public A(String nameClaseA) {
		this.nameClaseA = nameClaseA;
	}
}
class B extends A{
	String atributoClaseb;
	public B(String name, String atributoClaseB) {
		super(name);
		this.atributoClaseb = atributoClaseB;
	}
	
}
class C extends B{

	public C(String name, String atributoClaseB) {
		super(name, atributoClaseB);
		// TODO Auto-generated constructor stub
	}
	
	
}
public class PromotionAndCasting {
	
	public static void main(String...args) {
		List<B> l = new ArrayList<>();
		B b = new B("B","AtributoClaseB");
		l.add(b);
		System.out.println("Clase B tiene dos atributos: "+b.nameClaseA +" y "+b.atributoClaseb);
		A a = (A) l.get(0); //esto es casting, solo se permite cuando tiene sentido
		System.out.println("Casting la clase..."+a.nameClaseA);
		C c = new C("C", "atributoClaseC");
		System.out.println("La clase C contiene los atributos de la clase A y la clase B: " + c.nameClaseA +" y " +c.atributoClaseb);
		System.out.println("Promotion...");
		promotion();
	}
	
	private static void promotion() {
		int entero = 2;
		double decimal = 3.14;
		double suma = decimal + entero; //esto es promotion, ya que se pasa a double automaticamente
		System.out.println(suma);
	}
}
