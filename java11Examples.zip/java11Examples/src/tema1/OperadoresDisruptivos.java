package tema1;

public class OperadoresDisruptivos {
	
	public static void main(String...args) {
		//boolean b = verdadero() | falso(); //disruptivo, se ejecutan los dos métodos
		boolean b2 = verdadero() ^ falso(); //xor, uno tiene que ser verdadero y otro falso para que se cumpla
		System.out.println(b2);
		
	}
	
	private static boolean verdadero() {
		System.out.println("VERDADERO");
		return true;
	}
	
	private static boolean falso() {
		System.out.println("FALSO");
		return false;
	}

}
