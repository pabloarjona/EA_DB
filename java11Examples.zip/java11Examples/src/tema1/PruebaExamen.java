package tema1;

public class PruebaExamen {
	static int __ = 2;

	public static void main(String...args) {

		System.out.println(__ + __());

	}

	public static String __() {

		return "mieditos";

	}
}
