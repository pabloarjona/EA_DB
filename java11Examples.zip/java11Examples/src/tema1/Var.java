package tema1;

import java.util.ArrayList;

public class Var {
	
	public static void main(String...args) {
		
		var<Integer> x = new ArrayList<String>();
		x.add("prueba");
		System.out.println(x);
		
	}

}
