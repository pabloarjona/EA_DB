package tema1;

public class StringStringBuilder {
	public static void main(String...args) {
		//No mutable
		String x = "AAA";
		x.substring(2);
		System.out.println(x);
		//hay que hacer esto 
		x = x.substring(2);
		System.out.println(x);
		
		//Mutable
		StringBuilder y = new StringBuilder("BBB");
		y.append("B");
		System.out.println(y);
		
	}

}
