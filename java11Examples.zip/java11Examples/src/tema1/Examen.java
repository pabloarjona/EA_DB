package tema1;

public class Examen {
public static void main(String...args) {
		
		var secuencia = "12";
		
		secuencia +="3";
		secuencia = secuencia.replace("1","UNO");
		
		System.out.println(secuencia.toString());
	}


}
