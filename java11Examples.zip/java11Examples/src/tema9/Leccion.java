package tema9;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.Serializable;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;

public class Leccion {
	public static void main(String... args) throws Exception {
		//Leccion1();
		Leccion2();
		//Leccion3();
		//Leccion4();
		//Leccion5();
		//Leccion6A();
		//Leccion6B();
		//Leccion7();
		
	}
	// * no es un carácter válido para el método default boolean startsWith
	public static void Leccion1() throws IOException {
		Path path = Path.of(".." + File.separator);
		Files.walk(path).filter(f -> f.startsWith("*")).forEach(System.out::println);;
	}
	//R: Compila pero daría error de ejecución. Porque no tiene los métodos necesarios para su serialización y su des-serialización
	public static void Leccion2() throws Exception {
		Path path = Path.of("c:", "Temp", "serializado.data");
		try (OutputStream os = Files.newOutputStream(path); ObjectOutputStream out = new ObjectOutputStream(os)) {
			out.writeObject(new Persona());
		}
		try (InputStream os = Files.newInputStream(path); ObjectInputStream out = new ObjectInputStream(os)) {
			Persona p = (Persona) out.readObject();
			System.out.println(p.toString());
		}
	}
	//NO, Al final tenemos dos objetos distintos generados con new, por lo tanto, tienen hashcodes distintos y 
	//son distintos en definitiva.
	public static void Leccion3() throws Exception {
		Path path1 = Path.of("c:", "Temp", "persona1.data");
		Path path2 = Path.of("c:", "Temp", "persona2.data");
		setPer(new Persona2(), path1);
		setPer(new Persona2(), path2);
		Persona2 per1 = getPer(path1);
		Persona2 per2 = getPer(path2);
		boolean sonIguales = per1.equals(per2);
		System.out.println("¿Son iguales? ==> " + sonIguales);
	}
	private static final void setPer(Persona2 per, Path p) throws IOException {
		try (OutputStream os = Files.newOutputStream(p); ObjectOutputStream out = new ObjectOutputStream(os)) {
			out.writeObject(per);
		}
	}
	private static final Persona2 getPer(Path p) throws IOException, ClassNotFoundException {
		try (InputStream os = Files.newInputStream(p); ObjectInputStream out = new ObjectInputStream(os)) {
			Persona2 per = (Persona2) out.readObject();
			return per;
		}
	}
	// '.' nos referimos al directorio actual tanto en Linux como OSX o Windows. 
	public static void Leccion4() {
		File f = new File(".");
		if(f.isDirectory()) {
			System.out.println("Soy un directorio");
		} else {
			System.out.println("Soy un archivo");
		}
	}
	//R: No falla en ninguna línea pero no es correcto. Falta un close o un try/catch/resources. 
	public static void Leccion5() throws Exception {
		File f = new File("c:\\Temp\\hello.txt");
		var br = new BufferedReader(new FileReader(f));
		System.out.println(br.readLine());
	}
	
	public static void Leccion6A() {
		File f = new File(".");
		boolean is = f.isDirectory();
		f.delete();
		System.out.println(is);
	}
	
	public static void Leccion6B() throws IOException {
		Path p = Path.of("."); 
		boolean is = Files.isDirectory(p); 
		Files.delete(p);
		System.out.println(is);
	}

}

class Persona {
	transient int id;
	transient String nombre;
	transient LocalDate fecNac;
}

class Persona2 implements Serializable {
	private static final long serialVersionUID = 0;
	transient int id;
	transient String nombre;
	transient LocalDate fecNac;
}
