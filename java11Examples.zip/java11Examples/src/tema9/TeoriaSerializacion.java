package tema9;

import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.Serializable;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;

public class TeoriaSerializacion implements Serializable {
	private static final long serialVersionUID = -651653795812308724L; 
	
	class NoPuedo{
		String c = "oh yeaaaa";
	}
		
	private Integer id; 
	private String nombre;
	private transient LocalDateTime today;
	//Con transient intenta generarlo y si no puede no lo hace (lo deja todo a null)
	private transient NoPuedo np;
	
	public TeoriaSerializacion(Integer id, String nombre, LocalDateTime today) {
		super();
		this.id= id;
		this.nombre = nombre;
		this.today = today;
		this.np = new NoPuedo();

	}
	
	@Override
	public String toString() {
		return "Serializame [id=" + id + ", nombre="+ nombre + ", today=" +today+"]";
	}
	
	private void writeObject(ObjectOutputStream stream) throws IOException, ClassNotFoundException{
		System.out.println("me intentan serializar");
	}
	
	private void readObject(ObjectInputStream stream) throws IOException, ClassNotFoundException{
		System.out.println("me intentan deserializar");
	}
	
}
