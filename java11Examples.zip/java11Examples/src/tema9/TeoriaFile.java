package tema9;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.FileVisitOption;
import java.nio.file.Files;
import java.nio.file.Path;

public class TeoriaFile {
	public static void main(String[] args) throws IOException {
		//Ejemplo1();
		Ejemplo4();
	}
	
	public static void Ejemplo1() {
		//Generamos un archivo en la carpeta temp
		File f = new File("c:\\Temp\\");
		System.out.println(f.exists());
	}
	
	public static void Ejemplo2() throws IOException {
		File f = new File("c:\\Temp\\hello.txt");
		try (var br = new BufferedReader(new FileReader(f))){
			System.out.println(br.readLine());
		}
	}
	
	public static void Ejemplo3() throws IOException {
		Path f = Path.of("c:\\Temp\\hello.txt");
		//FOLLOW LINKS-> sigue a los enlaces directos
		Files.find(f, 5, (x, y) -> x.isAbsolute() && y.isOther(), FileVisitOption.FOLLOW_LINKS);
		Files.list(f).filter(x -> x.equals(""));
		
		//CARGA EN MEMORIA LENTAMENTE A MEDIDA QUE VA LEYENDO
		var lazyLines = Files.lines(f);
		lazyLines.forEach(System.out::println);
		
		//CARGA EN MEMORIA DE GOLPE
		var allLines = Files.readAllLines(f);
		allLines.forEach(System.out::println);
	}
	
	public static void Ejemplo4() throws IOException {
		//Otra forma de leer achivos más rapido
		try (var br = Files.newBufferedReader(
				Path.of("c:", "Temp", "hello.txt"))){
			System.out.println(br.readLine());			
		}
	}
	
}
