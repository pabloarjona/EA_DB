package tema9;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.stream.Stream;

public class Examen implements Serializable{
	public static void main(String[] args) throws Throwable {
		//Ejercicio1();
		//Ejercicio2();
		//Ejercicio3();
		//Ejercicio4();
		//Ejercicio5();
		Ejercicio6();
	}
	// .. .. .. .. 
	public static void Ejercicio1() {
		//asumiendo que estamos en un directorio con 6 niveles hacia atras
		Paths.get(".", "../", "../", "../", ".." +File.separator).normalize().forEach(
				x -> System.out.println(x.getFileName().toString()));
	}
	
	//R: Borra los archivos y carpetas recursivamente si tenemos permisos
	public static void Ejercicio2() {
		deleteTree(new File("c:\\Temp"));
	}
	
	public static void deleteTree(File file) {
		if(!file.isFile()) {
			for(File entry : file.listFiles()) {
				deleteTree(entry);
			}
		}else {
			file.delete();
		}
	}
	
	private Integer id= 1;
	private transient String nombre = "Paco";
	{
		id= 3;
		nombre= "Manolo";
	}
	//R: 3,null
	public static void Ejercicio3() throws Throwable {
		try (var o = new ObjectOutputStream(new FileOutputStream("pimpollo.txt"))){
			final var v = new Examen();
			o.writeObject(v);
		}
		
		try(var o = new ObjectInputStream(new FileInputStream("pimpollo.txt"))){
			var v = (Examen) o.readObject();
			System.out.println(v.id + "," + v.nombre);
		}
	}
	//R: Otro número
	public static void Ejercicio4() throws Exception {
		//Asumiendo que c:\Temp tiene 4 archivos de texto con 20 líneas entre los 4
		System.out.println(count(Paths.get("c:\\Temp")));
	}
	private static long count(Path p) throws Exception{
		return Files.list(p).filter(w -> Files.isRegularFile(w)).map(s -> readLines(s)).count();
	}
	
	private static Stream<String> readLines(Path p) {
		try {
			return Files.lines(p);
		}catch (Exception e){
			throw new RuntimeException(e);
		}
	}
	//R: temp padre  ...
	public static void Ejercicio5(){
		//asumiendo que no existe c:\\Temp\Padre
		Paths.get("c:\\Temp\\padre", "..\\").forEach(t -> System.out.println(t.getFileName().toString()));
	}
	//R: Obtendremos una excepcion
	public static void Ejercicio6() throws IOException {
		//Asummos que fruta.bkp existe. Esta en c:\Temp\fruta.bkp y tiene 20 líneas de texto
		Path path = Path.of("Temp").resolve(Paths.get("fruta.bkp"));
		
		if(path.isAbsolute()) {
			System.out.println("false");
		}else {
			System.out.println(Files.lines(path).count());
		}
	}
	
}
