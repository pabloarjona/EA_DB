package tema9;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

public class ExamenNoCompilan {
	
	//R: Absolutamente nada
	public static void Ejercicio1() {
		var fileA = Path.get("c:\\Temp\\a.file");
		var fileB = Path.get("c:\\Temp\\b.file");
		Files.move(fileA, fileB, StandardCopyOption.REPLACE_EXISTING);
	}
	//No compilar por la linea 7 (24 aquí)
	public static void Ejercicio2() {
		//la carpeta existe y esta vacia
		Path path = Path.of("c:", "vacio");
		try(var z = Files.walk(path)){
			boolean b = z.filter((p, a) -> a.isDirectory() && !path.equals(p).findFirst().isPresent();
			System.out.println(!b ? "Tiene algo" : "No tinen nada");
		}
	}
	//No será encontrado
	public static void Ejercicio3() {
		Files.find(Paths.get("."), Integer.MAX_VALUE,
				(w, a) -> w.toAbsolutePath().toString().endsWith(".java") && w.getFileName().contains("Examen") && 
				a.isRegularFile()).forEach(System.out::println);
	}
	//No compila
	public static void Ejercicio4() {
		//prueba.txt y prueba2.txt existen
		File f = new File("c:\\Temp\\prueba.txt");
		String line = "";
		try(var br = new BufferedReader(new FileReader(f))){
			line = br.readLine();
		}
		try(var bw = Files.newBufferedWriter(
				new File("c:\\Temp\\prueba2.txt"))){
			bw.write(line);
		}
	}
	
}
