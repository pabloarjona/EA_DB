package tema9;

import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;

public class TeoriaSerializacion2 {
	public static void main(String[] args) throws Exception{
		Path path = Path.of("c:", "Temp", "serializado.data");
		try (OutputStream os = Files.newOutputStream(path);
			ObjectOutputStream out = new ObjectOutputStream(os)) {
				out.writeObject(new TeoriaSerializacion(1, "aDormir", LocalDateTime.now()));
			
		}
		
		try(InputStream os = Files.newInputStream(path);
				ObjectInputStream out = new ObjectInputStream(os)) {
				
			TeoriaSerializacion s = (TeoriaSerializacion) out.readObject();
			System.out.println(s.toString());
		}
	}

}
