package miniExamen3;

/* Pregunta 8
 * Q: Given...
 * What code you must insert on Line 1 to enable the code to print Hello world?
 * A: B. Hello myH = new Hello(); Hello.Greeting myG = myH.new Greeting(); myG.sayHi(); 
 */
public class Pregunta8 {
	class Greeting{
		void sayHi() {
			System.out.println("Hello world");
		}
	}
	
	public static void main(String... args) {
		//Line 1
		Pregunta8 myH = new Pregunta8();
		Pregunta8.Greeting myG = myH.new Greeting(); 
		myG.sayHi();
	}
}
