package miniExamen3;

/*
 *Q: Given...
 *Examine these requirements:
 *Eliminate code duplication.
 *Keep constant the number of methods other classes may implement from this interface
 *Which method can be added to meet these requirements?
 *A: 
 *D. default void probeProcedure() {
		System.out.println("Launch Probe");
		System.out.println("Land on Asteroid");
	}
	
  Si un método lleva default se ejecutará si una clase que implementa la interfaz no proporciona su propia implementación del método.
  Si se escribe otro método con ese nombre se ejecutará dicho método (y no el default)
 */
public interface Pregunta21 {
	default void samplingProbeProcedure() {
		probeProcedure();
		System.out.println("Collect Sample");
		System.out.println("Leave Asteroid");
		System.out.println("Dock with Main Craft");
	}
	default void explosionProbeProcedure() {
		probeProcedure();
		System.out.println();
	}
	//Solucion
	default void probeProcedure() {
		System.out.println("Launch Probe");
		System.out.println("Land on Asteroid");
	}
	
}
