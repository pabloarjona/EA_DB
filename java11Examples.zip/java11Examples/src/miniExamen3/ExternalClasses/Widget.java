package miniExamen3.ExternalClasses;

public class Widget {

	Double price;
	String name;
	
	public Widget(String name, Double price) {
		this.price=price;
		this.name = name;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public void setPrice(Double price) {
		this.price=price;
	}
	
	public Double getPrice() {
		return price;
	}
	
	public String toString() {
		return "Widget [name=" +name+", price=" +price+"]";
	}
}
