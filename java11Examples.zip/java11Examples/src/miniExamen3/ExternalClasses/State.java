package miniExamen3.ExternalClasses;

public class State {
	public void mutate() {
		
	}
}
