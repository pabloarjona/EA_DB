package miniExamen3.ExternalClasses;

public class Worker {
	public synchronized void work(Resource... resources) {
		for(int i =0; i<10; i++) {
			while(!resources[0].claim(this)) {}
			while(!resources[1].claim(this)) {}
			//do work with resource 
			resources[1].release();
			resources[0].release();
		}
	}
}
