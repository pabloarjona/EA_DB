package miniExamen3.ExternalClasses;

public interface Print {

}
