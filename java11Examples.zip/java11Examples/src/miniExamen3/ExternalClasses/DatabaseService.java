package miniExamen3.ExternalClasses;

import java.util.ServiceLoader;

public class DatabaseService {

	public static void main(String[] args) {
		ServiceLoader<DatabaseDriver> loader = ServiceLoader.load(DatabaseDriver.class);
		for (DatabaseDriver driver : loader) {
            System.out.println("Conectando a " + driver.getClass().getName()+"...");
			driver.connect();
		}
	}
}
