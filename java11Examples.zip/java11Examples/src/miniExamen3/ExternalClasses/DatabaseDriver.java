package miniExamen3.ExternalClasses;

public interface DatabaseDriver {

	void connect();
}
