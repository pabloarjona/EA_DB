package miniExamen3.ExternalClasses;

public class MySQLDriver implements DatabaseDriver{

	@Override
	public void connect() {
		System.out.println("Conectado a la base de datos MySQL");		
	}
}
