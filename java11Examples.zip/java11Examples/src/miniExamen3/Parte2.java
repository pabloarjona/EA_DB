package miniExamen3;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.JDBCType;
import java.sql.PreparedStatement;
import java.util.List;
import java.util.Optional;
import java.util.ServiceLoader;
import java.util.function.Function;
import java.util.stream.Stream;
import javax.sql.DataSource;

import miniExamen3.ExternalClasses.Print;
import miniExamen3.ExternalClasses.Resource;
import miniExamen3.ExternalClasses.Widget;
import miniExamen3.ExternalClasses.Worker;
public class Parte2 {

	public static void main(String[] args) {
		//pregunta13();
		//pregunta14();
		//pregunta17();
		//pregunta20();
		//pregunta22();
		pregunta23();
	}
	
	/*
	 * Pregunta 13
	 * Q: Given...
	 * Which statement on line 1 enables this code to compile?
	 * A: A. Function<Integer, Integer> f = n -> n *2; 
	 */
	private static void pregunta13() {
		var numbers = List.of(1,2,3,4,5,6,7,8,9,10);
		//Function con dos valores uno para el resultado y otro para el parámetro
		Function<Integer, Integer> f = n -> n *2; //line 1
		StringBuilder sb = new StringBuilder();
		for(int a: numbers) {
			sb.append(f.apply(a));
			sb.append(" ");
		}
		System.out.println(sb.toString());
	}
	
	/**Pregunta 14
	 * Q: Assuming the Widget class has a getPrice Method, this code does not compile:
	 * A: A. widgetStream.filter(a ->((Widget)a).getPrice() > 20.00).forEach(System.out::println);
	 * 	  D. Stream<Widget> widgetStream2 = widgets.stream();   //solucion 1
	 */
	private static void pregunta14() {
		List widgets = List.of(new Widget("Basic Widget", 19.55),  //line 1
				new Widget("Enhanced Widget", 35.00),
				new Widget("Luxury Edition Widget", 55.45));
		Stream widgetStream = widgets.stream();    //line 4
		Stream<Widget> widgetStream2 = widgets.stream();   //solucion 1
		System.out.println("Ejemplo 1:");
		widgetStream2.filter(a ->a.getPrice() > 20.00).forEach(System.out::println);  //line 5
		System.out.println("Ejemplo 2: ");
		widgetStream.filter(a ->((Widget)a).getPrice() > 20.00).forEach(System.out::println);  //solucion 2
	}
	
	/**Pregunta 15
	 * Q: Assume ds is a DataSource and the EMP table is defined appropriately.
	 * ...
	 * A: B: inserts two rows(101, 'SMITH', 'HR') and (102, 'JONES', 'HR')
	 */
	private static void pregunta15() {
		try (Connection conn = ds.getConnection();
			PreparedStatement ps = conn.prepareStatement("INSERT INTO EMP VALUES(?, ?, ?)")){
			ps.setObject(1, 101, JDBCType.INTEGER);
			ps.setObject(2, "SMITH", JDBCType.VARCHAR);
			ps.setObject(3, "HR", JDBCType.VARCHAR);
			ps.executeUpdate();
			ps.setInt(1, 102);
			ps.setString(2, "JONES");
			ps.executeUpdate();
		}
	}
	
	/**Pregunta 17
	 * Q: Given...
	 * A:
	 */
	private static void pregunta17() {
		Optional<String> value = createValue();
		String str = value.orElse("Duke");
		System.out.println(str);
	}

	static Optional<String> createValue() {
		String s = null;
		return Optional.ofNullable(s);
	}
	//************REPASAR**********************//
	/**Pregunta 18
	 * Q: Examine these module declarations:
	 * module ServiceAPI{
	 * 		exports com.example.api;
	 * }
	 * 
	 * module ServiceProvider{
	 * 		requires ServiceAPI;
	 * 		provides com.example.api with com.myimpl.Impl;
	 * }
	 * 
	 * module Consumer{
	 * 		requires ServiceAPI;
	 * 		uses com.example.api;
	 * }
	 * A: B. The placement of the com.example.api API in a separate module, SeriviceAPI, makes it easy to install multiple provider modules.
	 *    E. The ServiceProvider module does not know the identity of a module (such as Consumer) that uses the com.example.api API. 
	 */
	
	/*Pregunta 19
	 * Q: Which code fragment does a service use to load the service provider with a Print interface?
	 * A: B. private java.util.ServiceLoader<Print> loader = ServiceLoader.load(Print.class);
	 */
	private static void pregunta19() {
		java.util.ServiceLoader<Print> loader = ServiceLoader.load(Print.class);
	}
	
	/*Pregunta 20
	 * Q: Given....
	 * A: A. An IlegalThreadStateException is thrown at run time
	 */
	private static void pregunta20() {
		Thread t1 = new Thread(new MyThread());
		Thread t2 = new Thread(new MyThread());
		Thread t3 = new Thread(new MyThread());
		
		t1.start();
		t2.run();
		t3.start();
		
		t1.start();
	}
	
	/*Pregunta 22
	 * Q: Given these two clases:
	 * ...
	 * And given this fragment...
	 * 
	 * A: It is Subject to livelock
	 *El livelock es una situación en la que los hilos se bloquean mutuamente y, aunque no están inactivos, 
	 *no pueden avanzar debido a sus acciones repetitivas.
	 */
	private static void pregunta22() {
		Worker w1 = new Worker();
		Worker w2 = new Worker();
		Resource r1 = new Resource();
		Resource r2 = new Resource();
		new Thread(() -> {
			w1.work(r1, r2);
		}).start();
		new Thread(() -> {
			w2.work(r2, r1);
		}).start();
	}
	
	/*Pregunta 23
	 * Q: Given this enum declaration
	 * ...
	 * Examine this code:
	 * A: C. static String getFirstLetter() { return A.toString(); }
	 */
	private static void pregunta23() {
		System.out.println(Alphabet.getFirstLetter());
	}
	
	//REPASAR 24
	
	/*Pregunta 25
	 * Given the code fragment:
	 * ....
	 * The /scratch/exam/temp.txt file exists. The /scratch/exam/new.txt and /scratch/new.txt files do not exist.
	 * What is the result?
	 * A: The program throws a FileAlreadyExistsException.
	 */
	private static void pregunta26() {
		Path currentFile = Paths.get("/scratch/exam/temp.txt");
		Path outputFile = Paths.get("/scratch/exam/new.txt");
		Path directory = Paths.get("/scratch");
		Files.copy(currentFile, outputFile);
		Files.copy(outputFile, directory);
		Files.delete(outputFile);
	}

	
}
/*
 * Pregunta 25
 * Q: Which two are functional interfaces?(Choose two)
 * A: A. @FunctionalInterface
		 interface MyRunnable{
			public void run();
		  }
	  D. interface MyRunnable{
	  		public default void run(){}
	  		public void run(String s);
	  }
 *    Las interfaces funcionales tienen un único método abstracto, que se llama "método funcional", y están diseñadas para ser utilizadas con
 *     expresiones lambda o referencias a métodos.  demás métodos en la interfaz (si los hay) se consideran métodos predeterminados o estáticos 
 *     y no afectan la funcionalidad de la interfaz funcional.
 */
@FunctionalInterface
interface MyRunnable{
	public void run();
}

@FunctionalInterface
interface MyRunnable2{
	public void run();
	public void call();
}

@interface Resource{
	String name;
	int priority default 0;
}

interface MyRunnable3{
	public default void run() {}
	public void run(String s);
}

@FunctionalInterface
interface MyRunnable4{
	
}


enum Alphabet{
	A,B,C;
	static String getFirstLetter() {
		return A.toString();
	}
}

class MyThread implements Runnable{
	public void run() {
		System.out.println("Running...");
	}
}
