package miniExamen3;

/*******REPASAR*******/
/*Pregunta 24
 * Q: Given...
 * Which two interfaces can be used in lambda expressions?
 * A: A. Myinterface1
 *    D. Myinterface2
 */
interface Pregunta24 {

}
interface MyInterface1{
	public int method() throws Exception;
	private void pMethod() {  /*an implementation of pMethod*/}
}
interface MyInterface2{
	public static void sMethod() { /* an implementation of sMethod*/ }
	public boolean equals();
}
interface MyInterface3{
	public void method();
	public void method(String str);
}
interface MyInterface4{
	public void dMethod() { /*an implementation of dMethod*/}
	public void method();
}

interface MyInterface5{
	public static void sMethod();
	public void method(String str);
}


