package miniExamen3;

import java.io.IOException;
import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.locks.ReentrantLock;
import java.util.function.Consumer;
import java.util.function.UnaryOperator;
import java.util.stream.Collectors;

import miniExamen3.ExternalClasses.State;

public class Parte1 {

	public static void main(String[] args) throws Exception {
		//pregunta1();
		//pregunta2();
		//pregunta3();
		pregunta10();
		//pregunta12();
	}
	/**
	 * Q: Given...
	 * You want to obtain the Stream object on reading the file.
	 * Which code inserted on line 1 will accomplish this?
	 * A: A. var lines = Files.lines(Paths.get(INPUT_FILE_NAME));
	 */
	private static void pregunta1() throws Exception {
		try {
			URI INPUT_FILE_NAME = new URI("example");
			var lines = Files.lines(Paths.get(INPUT_FILE_NAME));//line 1
			lines.map(l -> l.toUpperCase())
			.forEach(line -> {
				try {
					Files.write(Paths.get("outputFile_to_Path"), line.getBytes(), StandardOpenOption.CREATE);
				}catch(IOException e){
					e.printStackTrace();
				}
			});
		}catch(IOException e){
			e.printStackTrace();
		}
	}
	
	/**
	 * Q: Given...
	 * Which statement on line 1 enables this code fragment to compile?
	 * A: UnaryOperator<String> function = String::toUpperCase;
	 */
	private static void pregunta2() {
		UnaryOperator<String> function = String::toUpperCase; //line 1
		List<String> fruits = new ArrayList<>(List.of("apple","orange","banana"));
		fruits.replaceAll(function);
		//Comprobación
		for (String fruit : fruits) {
			System.out.println(fruit);
		}
	}
	
	/**
	 * Q: var numbers = List.of(0,1,2,3,4,5,6,7,8,9);
	 * 	  You want to calculate the average of numbers.
	 * 	  Which two codes will accomplish this? (Choose two.)
	 * A: double avg = numbers.stream().collect(Collectors.averagingDouble(n -> n));
	 */
	private static void pregunta3() {
		var numbers = List.of(0,1,2,3,4,5,6,7,8,9);
		double avg = numbers.stream().collect(Collectors.averagingDouble(n -> n));
		double avg2 = numbers.parallelStream().mapToInt(m->m).average().getAsDouble();    //son lo mismo
		double avg3 = numbers.stream().parallel().mapToInt(m->m).average().getAsDouble(); //probando... son lo mismo
		//PRUEBA
		System.out.println(avg);
		System.out.println(avg2);
		System.out.println(avg3);
	}
	
	/****** PREGUNTA 5 *****************************************
	 * Q: Given an application with a main module that has this module-info.java file:
	 *  
	 * 	  What action ensures succesful compilation?
	 * A: B. A module providing an implementation of country.CountryDetails must have a requires main; directive in its
	 *       module-info.java file
	 *    D. To compile without an error, the application must have at least one module in the module source path that provides an implementation
	 *       of country.CountryDetails.   
	 */
	
	/********* Pregunta 6************
	 * Q: You are working on a functional bug in a tool used by your development organization. In your investigation, you find that the tool
	 * is executed with a security policy file containing this grant.
	 * 	DoubleStream.generate(Random.nextDouble).limit(10).forEach(System.out.print);
	 * A: D. File a security bug against the tool referencing the excessive permission granted.
	 */
	
	/*********** Pregunta 7 *******
	 * Q: Which code prints 100 random numbers?
	 * A: D. DoubleStream.generate(Random::nextDouble).limit(100).forEach(System.out::print); 
	 */
	
	/* Pregunta 9
	 * Q: Which two are examples of autoboxing? (Choose two).
	 * A: B. Integer e = 5;
		  E. Long c = 23L
		 Autoboxing es un mecanismo que permite la conversión automática de tipos primitivos en sus respectivas clases de envoltura 
		 (wrapper clases)
	 */
	private static void pregunta9() {
		Integer e = 5;
		Long c =23L;  //L dice que el valor es tipo Long
	}
	
	/* Pregunta 10
	 * Q: Given...
	 * What is the output?
	 * A: An exception is thrown at run time.
	 */
	private static void pregunta10() {
		var data = new ArrayList<>();
		data.add("Peter");
		data.add(30);
		data.add("Market Road");
		data.set(1, 25);
		data.remove(2);
		data.set(3, 1000L);
		System.out.println(data);
	}
	
	/*
	 * Pregunta 11.
	 * G: Given...
	 * What is required to make the Foo class thread safe?
	 * A: No change is required
	 */
	private final ReentrantLock lock = new ReentrantLock();
	private State state;
	public void pregunta11() throws Exception{
		try {
			lock.lock();
			state.mutate();
		}
		finally {
			lock.unlock();
		}
	}
	
	/** Pregunta 12
	 * Q: Given...
	 * You want to examine the first element that contains the character n.
	 * Which statement will accomplish (logra) this?
	 * A: Optional<String> result = fruits.stream().filter(f -> f.contains("n")).findFirst(); 
	 */
	private static void pregunta12() {
		var fruits = List.of("apple" , "orange", "banana", "lemon");
		Optional<String> result = fruits.stream().filter(f -> f.contains("n")).findFirst();
		//Probando
		Consumer<String> consumer = (m) -> System.out.println("Encontrado");
		result.ifPresent(consumer);
	}
}
