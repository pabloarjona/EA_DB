package miniExamen3;

import java.io.Serializable;

/**Pregunta 4
 * Q: Given...
 *    What action ensures successfull compilation?
 * A: A. Replace public Color(int c) with private Color(int c).
 */
enum Color implements Serializable{
	R(1), G(2), B(3);
	int c;
	private Color(int c) {   //public Color ...
		this.c = c;
	}
}
