package miniExamen3;

/**Pregunta 16
 * Q: Given...
 * A: C. Hello World
 */
public class Pregunta16 {
	private static class Greet{
		private void print() {
			System.out.println("Hello World");
		}
	}
	public static void main(String[] args) {
		Pregunta16.Greet i = new Greet();
		i.print();
	}
	
}
