package tema4;

import java.util.ArrayList;
import java.util.List;

class ExcepcionPadre extends Throwable{
	
}

public class Leccion {
	
	static List<ExcepcionPadre> catalago = new ArrayList<>();
	
	public static void main(String[] args) throws ExcepcionPadre{
		catalago.add(new ExcepcionPadre());
		catalago.add(new ExcepcionPadre());
		catalago.add(new ExcepcionPadre());
		catalago.add(new ExcepcionPadre());
		catalago.add(new ExcepcionPadre());
		catalago.add(new ExcepcionPadre());
		catalago.add(new ExcepcionPadre());
		
		throw catalago.get(5);
	}
}
