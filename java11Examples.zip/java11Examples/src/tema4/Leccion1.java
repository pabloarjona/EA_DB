package tema4;

class ExceptionPadre extends Throwable{}

class ExceptionHija extends ExceptionPadre{}

public class Leccion1 {

	public static void main(String[] args) throws ExceptionHija{
		ExceptionPadre ep = new ExceptionHija();
		//da error porque debe devolver un ExceptionHija
		throw ep;
	}
	
}
