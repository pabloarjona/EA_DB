package tema4;

//Las excepciones Checked obligarán a ser capturadas o lanzadas mientras que la Unchecked no.
public class ExcepcionChecked {
	
	class MyEx extends Exception{}
	
	public void a() throws MyEx{
		throw new MyEx();
	}
	
	public void b() {
		class MyEx2 extends Error{}
		throw new MyEx2();
	}
	
	class MyThrow extends Throwable{}
	
	public void c() throws MyThrow{
		throw new MyThrow();
	}
	
	class MyRun extends RuntimeException{}
	
	public void d() {
		throw new MyRun();
	}
	
	class MyChecked extends Exception{}
	
	public void e() {
		try {
			throw new MyChecked();
		}catch (MyChecked e){
			System.out.println("O me capturas o me lanzas");
		}
		throw new Error();
	}
}

