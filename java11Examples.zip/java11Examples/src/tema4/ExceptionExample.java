package tema4;

public class ExceptionExample {
	
	public static void main(String...args) {
		try {
			System.out.println("Hacemos algo...");
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}finally {
			System.out.println("Esto siempre ocurre");
		}
	}
	

}
