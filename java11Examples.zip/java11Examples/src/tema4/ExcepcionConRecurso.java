package tema4;

import java.io.Closeable;
import java.io.IOException;

class Recurso implements Closeable{

	//Segundo
	@Override
	public void close() throws IOException {
		// TODO Auto-generated method stub
		System.out.println("Soy Recurso");
	}
	
}

class RecursoAutoClose implements AutoCloseable{

	//Va primero
	@Override
	public void close() throws IOException {
		// TODO Auto-generated method stub
		System.out.println("Soy RecursoAutoClose");
	}
	
}

public class ExcepcionConRecurso {
	
	public static void main(String[] args) {
		try (Recurso recurso = new Recurso();
			RecursoAutoClose recursoAutoClose = new RecursoAutoClose()) {
			System.out.println("Mucho código");
		}catch (IOException e){
			e.printStackTrace();
		}finally { //Tercero
			System.out.println("Finally..");
		}
	}
}
