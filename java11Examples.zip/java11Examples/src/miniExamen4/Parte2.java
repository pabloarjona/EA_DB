package miniExamen4;
//COMENTAR DANIII ESTA MAL

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.function.BiFunction;

/* Pregunta 19
 * Q: Which two are valid usages of the annotation? (Choose two.)
 * A: D. @Pregunta19(mainCourse = "pizza")
		 @Pregunta19(mainCourse = "salad")
	  E. @Pregunta19(mainCourse = "pizza", starter="snack", dessert = "pudding")
 */
@Pregunta19(mainCourse = "pizza")
@Pregunta19(mainCourse = "salad")
@Pregunta19(mainCourse = "pizza", starter="snack", dessert = "pudding")
public class Parte2<T> {
	public static void main(String[] args) {
		//pregunta20();
		//pregunta21();
		pregunta24();
		//pregunta25();
	}

	//PREGUNTAR DANI DUDAA
	/* Pregunta17
	 * Q: Which module-info.java is correct for a service provider for a print service defined in the PrintServiceAPI module?
	 * A: B. module PrintServiceProvider{
	 * 		requires PrintServiceAPI;
	 * 		provides org.printservice.spi.Print with
	 * 		com.provider.PrintService;
	 *	  }
	 */
	
	/** Pregunta 20
	 *  Q: Given the code fragment
	 *  A: D. 0 4 9
	 */
	private static void pregunta20() {
		for(var i = 0; i < 10; i++) {
			switch(i % 5) {
				case 2:
					i *= 2 *1;
					break;
				case 3:
					i++;
					break;
				case 1:
				case 4:
					i++;
					continue;
				default: 
					break;
			}
			System.out.print(i + " ");
			i++;
		}
	}
	
	/* Pregunta 21
	 * Q: Given...
	 * 	  What is the result?
	 * A: B. 4
	 */
	private static void pregunta21() {
		StringBuilder sb =  new StringBuilder(5);
		sb.append("HOWDY"); 	//HOWDY 
		sb.insert(0, ' '); 		// HOWDY
		sb.replace(3, 5, "LL"); // HOLLY
		sb.insert(6,"COW"); 	// HOLLYCOW
		sb.delete(2, 7);		// HOW
		System.out.println(sb.length());
	}
	
	/* Pregunta 24
	 * 
	 */
	private static void pregunta24() {
		// Definir un validador para comparar enteros
        BiFunction<Integer, Integer, Boolean> intValidator = (x, y) -> x > y;
        // Crear una instancia de Pregunta24 con el validador y valores iniciales
        Pregunta24<Integer> pregunta = new Pregunta24<>(intValidator, 5, 3);
        // Verificar si es válido
        System.out.println("¿Es válido? " + pregunta.isValid());
        // Intentar establecer un valor no válido
        try {
            pregunta.set(3, 5);
        } catch (IllegalArgumentException e) {
            System.out.println("Excepción: " + e.getMessage());
        }
        // Cambiar los valores a uno válido
        pregunta.set(7, 2);
        // Verificar nuevamente si es válido
        System.out.println("¿Es válido? " + pregunta.isValid());
	}
	
	//Decir a dani
	/* Pregunta 25
	 * Q: Given ...
	 * 
	 * A: abcdf
	 */
	private static void pregunta25() {
		try {
			doA();
			doB();
		}catch(IOException e){
			System.out.print("c");
		}finally {
			System.out.print("d");
		}
		System.out.println("f");
	}
	
	private static void doA() {
		System.out.print("a");
		if(false) {
			throw new IndexOutOfBoundsException();
		}
	}
	
	private static void doB() throws FileNotFoundException{
		System.out.print("b");
		if(true) {
			throw new FileNotFoundException();
		}
	}
}
