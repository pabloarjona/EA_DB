package miniExamen4;

import java.util.List;
import java.util.Set;

public class Foo{
	public List<Integer> foo(Set<CharSequence> m){
		return null;
	}
}
