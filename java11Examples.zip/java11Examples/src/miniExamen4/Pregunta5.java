package miniExamen4;

import java.sql.Timestamp;

public class Pregunta5 {

	/* Given...
	 * and  the commands 
	 * javac Test.java
	 * jdeps -summary Test.class
	 * What is the result on execution of these commands?
	 * A: C. Test.class -> java.base
			 Test.class -> java.sql
	 */
	public static void main(String[] args) {
		Timestamp st = new Timestamp(1);
		System.out.println(st);
	}
}
