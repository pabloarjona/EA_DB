package miniExamen4;

import java.lang.annotation.ElementType;
import java.lang.annotation.Repeatable;
import java.lang.annotation.Target;
//COMENTAR DANIII ESTA MAL
/* Pregunta 19
 * Q: Which two are valid usages of the annotation? (Choose two.)
 * A: D. @Pregunta19(mainCourse = "pizza")
		 @Pregunta19(mainCourse = "salad")
	  E. @Pregunta19(mainCourse = "pizza", starter="snack", dessert = "pudding")
 */
@Repeatable(Pregunta19s.class)
@Target(ElementType.TYPE)
@interface Pregunta19 {
	String starter() default "";
	String mainCourse();
	String dessert() default "";
}



