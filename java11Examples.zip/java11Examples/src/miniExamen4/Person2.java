package miniExamen4;

public class Person2 {
	private String name;
	public Person2(String name) {
		this.name = name;
	}
	public String toString() {
		return name;
	}
}
