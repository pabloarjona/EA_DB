package miniExamen4;

import java.io.FileReader;
import java.io.IOException;
import java.net.Socket;
import java.security.AccessController;
import java.security.PrivilegedExceptionAction;
import java.text.MessageFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.function.BiPredicate;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class Parte1 {
	
	public static void main(String[] args) {
		//pregunta1();
		pregunta3();
		//pregunta4();
		//pregunta6();
		//pregunta8();
		//pregunta9();
		//pregunta10();
		//pregunta13();
		//pregunta15();
		//pregunta15();
		//pregunta16();
		
	}
	
	/*Pregunta 1.
	 * Q: Given...
	 *"/proj/msg/messages.properties file:
	 * message=Hello {0}, regards {1}"
	 * and
	 * "/proj/msg/messages.properties file:
	 * message=こんにちは {0}, ご挨拶 {1}"
	 * and 
	 * "/proj/msg/Test.java class:"
	 * You want to print the message こんにちは Joe, ご挨拶 Jane.
	 * Which code inserted on line 1 will accomplish this?
	 * A: D. ResourceBundle msg = ResourceBundle.getBundle("messages", Locale.JAPAN);
			 String[] names = {"Joe","Jane"};
			 String message = MessageFormat.format(msg.getString("message"), names);
	 */
	private static void pregunta1() {
		//Solucion:
		ResourceBundle msg = ResourceBundle.getBundle("messages", Locale.JAPAN);
		String[] names = {"Joe","Jane"};
		String message = MessageFormat.format(msg.getString("message"), names);
		//
		System.out.println(message);
		//Probando
		Locale.setDefault(new Locale("es", "ES"));
		var b = ResourceBundle.getBundle("messages");
		String message2 = MessageFormat.format(b.getString("message"), names);
		System.out.println(message2);
	}
	
	/* Pregunta 2
	 * Q: Given...
	 *    What is the result?
	 * A: C. 1-5
	 */
	private static void pregunta2() {
		int x = 0, y = 6;
		for(; x < y; x++, y--) { //line 1
			if(x % 2 == 0) {
				continue;
			}
			System.out.println(x+"-"+y);
		}
	}
	
	/*Pregunta 3
	 * Q: Which two are valid statements? (Choose two.)
	 * A: B. BiPredicate<Integer, Integer> test1 = (var x, final var y) -> (x.equals(y));
	 *    E. BiPredicate<Integer, Integer> test2 = (Integer x, final Integer y) -> (x.equals(y));
	 */
	private static void pregunta3() {
		BiPredicate<Integer, Integer> test1 = (var x, final var y) -> (x.equals(y));
		BiPredicate<Integer, Integer> test2 = (Integer x, final Integer y) -> (x.equals(y));
		boolean answer1 = test1.test(4, 2);
		boolean answer2 = test2.test(234, 234);
		System.out.println(answer1);
		System.out.println(answer2);
	}
	
	/*Pregunta 4
	 * Q: Which three initialization statements are correct? (Choose three)
	 * A: B. short sh = (short)'A';
	 * 	  C. float x = 1f;
	 * 	  F. int a = 12_34;		 
	 */
	private static void pregunta4() {
		/*A
		int[][][] e = {{1,1,1},{2,2,2}}; 
		*/
		short sh = (short)'A'; 			 //B
		float x = 1f;					 //C
		/* B.
		byte b = 10;					 
		char c = b;
		C.	
		String contact# ="(+2) (999) (232)";
		*/
		int a = 12_34;  				//F
		/* G.
		 * boolean false = (4 != 4);  
		 */
		//PROBANDO
		System.out.println(sh);
		System.out.println(x);
		System.out.println(a);
	}
	//REPASARRRR
	/*Pregunta 6
	 * Q: Why would you choose to use a peek operation instead of a forEach operation on a Stream?
	 * A: C. to process the current item and return a stream
	 */
	private static void pregunta6() {
		//Ejemplo
		List<Integer> numeros = List.of(1,2,3,4,5);
		
		//Peek sirve para hacer una operación de cada elemento del Stream y devolver un nuevo Stream con los mismos elementos.
		Stream<Integer> nuevoStreamConPeek = numeros.stream()
				.peek(numero -> System.out.println("Duplicando: "+ numero))
				.map(numero -> numero*2);
		//forEach sirve para realizar una operación en cada elemento del 'Stream' sin devolver un nuevo 'Stream'
		System.out.println("Usando forEach");
		numeros.stream().forEach(numero -> System.out.println("Duplicado "+ numero ));
		
		System.out.println("Usando peek: ");
		List<Integer> numerosDuplicados = nuevoStreamConPeek.collect(Collectors.toList());
		System.out.println("Lista números duplicados: "+ numerosDuplicados);
	}
	
	/*DANI
	 * Pregunta 8
	 * Q: What is the result?
	 * A: Green
	 */
	private static void pregunta8() {
		Person p = new Person();
		p.setName("Blue");
		System.out.println(p);
	}
	//DANI
	/* Pregunta 9
	 * Q: Given the code fragment:
	 * A: D. NumberFormat formatter = NumberFormat.getCurrencyInstance(locale);     
	 */
	private static void pregunta9() {
		Locale locale = Locale.US;
		//SOLUCION
		NumberFormat formatter = NumberFormat.getCurrencyInstance(locale);    //line1
		double currency = 1_00.00;
		System.out.println(formatter.format(currency));
	}
	
	//DANI
	/*Pregunta 10
	 * Q: Given the code fragment:
	 * A: C. CNY -> 6,42
		  	 EUR -> 0,84
		  	 GBP -> 0,75
		  	 USD -> 1,00
	 */
	
	private static void pregunta10() {
		var symbols = List.of("USD", "GBP", "EUR", "CNY");
		var exchangeRate = List.of(1.0, 1.3255,1.1969,0.1558094);
		//IntStream.range genera índices desde 0 hasta el tamaño mínimo entre las listas symbols y exchangeRate. Esto garantiza que solo se consideren 
		//elementos para los cuales haya tanto un símbolo de moneda como una tasa de cambio correspondiente.
		var map1 = IntStream.range(0, Math.min(symbols.size(), exchangeRate.size()))
				.boxed() //para convertir el IntStream a Stream<Integer>
				.collect(Collectors.toMap( x -> symbols.get(x), x ->1.0 /exchangeRate.get(x)));  //crea el primer map donde las claves son symbols.get(i)
																								//y los valores son el resultado de la expresion..
		for (var symbol : map1.keySet()) {
			System.out.println("Key: " +symbol+ " value:"+ map1.get(symbol));
		}
		var map2 = map1.entrySet().stream()
				.sorted(Map.Entry.comparingByKey())   //se ordena alfabeticamente por las key, es decir, los simbolos de moneda
				.collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, 
						(oldValue, newValue) -> oldValue, LinkedHashMap::new));  //crea el segundo hashmap y lo pasa a un linkedhashmap, ordenado.
		System.out.println("Map 2: ");
		for (var symbol : map2.keySet()) {
			System.out.println("Key: " +symbol+ " value:"+ map2.get(symbol));
		}
		map2.forEach((var k, var v)-> System.out.printf("%s -> %.2f\n",k,v));   //printf para imprimir de forma formateada, s y f para los valores, 
																				//y .2 para mostrar dos decimales	
	}
	
	// SECURITY POLICY FILES
	/*Pregunta 11
	 * Q: Your organization makes mlib.jar available to your cloud customers. While working on a new feature for mlib.jar, you see that the customer visible
	 * 	  method public void enableService(String hostName, String portNumber) executes this code fragment
	 *    try ....
	 *    and you see this 
	 *    grant codebase "file:${mlib.home}/j2se/home/mlib.jar"{
	 *    	permission java.io.SocketPermisision "*", "connect";
	 *    }
	 *    What security vulnerability does this expose to your cloud customer's code?
	 * A: SQL injection against the specified host and port
	 */
	private static void pregunta11() {
		try {
			AccessController.doPrivileged((PrivilegedExceptionAction<Void>) () -> {
				Socket transportSocket = new Socket("hostname", 8080/*portNumber*/);
				return null;
			});
		}catch(Exception e){
			
		}
	}
	
	/*Pregunta 12
	 * Q: A company has an existing Java 8 jar file, sales-app-1.1.1.jar, that uses several Apache open source jar files that have not been modularized.
	 *    commons-beanutils-1.9.3.jar
	 *    commons-collections4-4.2.jar
	 *    	(Automatic-Module-Name: org.apache.commons.collections4)
	 *    commons-lang3-3.8.1.jar
	 *    	(Automatic-Module-Name: org.apache.commons.lang3)
	 *    commons-text-1.3.jar
	 *    	(Automatic-Module-Name: org.apache.commons.text)
	 *    Which module-info.java file should be used to convert sales-app.1.1.jar to a module?
	 * A: module com.company.sales_app{
	 * 		requires commons.beanutils;
	 * 		requires org.apache.commons.collections4;
	 * 		requires org.apache.commons.lang3;
	 * 		requires org.apache.commons.text;
	 */
	
	//REPASAR DECIR A DANI PQ ESTA MAL
	/* Pregunta 13
	 * Q: Given...
	 * 	  What is the result?
	 * A: D. 5 4 3 2 1 4 3 2 1 3 2 1 2 1 1 
	 */
	private static void pregunta13() {
		int i = 10;
		do {
			for(int j = i/2 ; j > 0; j--) {
				System.out.print(j + " ");
			}
			i-=2;
		}while(i>0);
	}
	
	/*Pregunta 14
	 * Q: Given...
	 *    What is the result?	  
	 * A: [A, B, C]
		  [A, B, C]
	 */
	private static void pregunta14() {
		List<String> list1 = new ArrayList<>();
		list1.add("A");
		list1.add("B");
		List<String> list2 = Collections.unmodifiableList(list1);
		list1.add("C");
		//list2.add("K"); devolvería una excepción
		System.out.println(list1);
		System.out.println(list2);
	}
	
	//DANI
	/* Pregunta 15
	 * Q: Given..
	 * 	  You want to read data through the reader object.
	 * 	  Which statement inserted on line 1 will accomplish this?
	 * A: D. reader.read(characters)
	 */
	private static void pregunta15() {
		char[] characters = new char[100];
		try (FileReader reader = new FileReader("C:\\Users\\parjrui\\Documents\\filePrueba.txt");){
			reader.read(characters); //line 1
			System.out.println(String.valueOf(characters));
		}catch(IOException e) {
			e.printStackTrace();
		}
	}
	
	//REPASAR DANI PORQUE ESTAN MAL
	/* Pregunta16
	 * Q: Given...
	 * 	  Which code fragments, at line n1, prints SPRING? (Choose three.)
	 * A: 	C. System.out.println(Season.SPRING); 
			D. System.out.println(Season.valueOf("SPRING")); 
			G. System.out.println(sA[1]);  
	 */
	private static void pregunta16() {
		Season[] sA = Season.values();
		System.out.println(Season.SPRING); //C
		System.out.println(Season.valueOf("SPRING")); //D
		System.out.println(sA[1]);  //G
	}
}

