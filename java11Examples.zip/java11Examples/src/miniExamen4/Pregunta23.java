package miniExamen4;

/* Pregunta 23
 * Q: Given the declaration...
 * 	  Which tow annotations may be applied at Loc1 in the code fragment? (Choose two.)
 * A: @Resource(name="Customer1", priority=100)
 *    @Resource(name="Customer1")
 */
@interface Pregunta23 {
	String name();
	int priority() default 0;
}


//@Pregunta23(name="Customer1")
@Pregunta23(name = "Customer1", priority = 100)
class Pregunta23a{
	
}