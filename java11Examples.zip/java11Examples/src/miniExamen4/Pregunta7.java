package miniExamen4;
/* REPASARRRRRRRRRRRRRRRRRRRRR PREGUNTAR DANI
 * Q: Which two lines of code when inserted in line 1 correctly modifies instance variables? (Choose two.)
 * A: 	A. cCount = setCCount(c);
		E. aCount = a;
 */
public class Pregunta7 {
	int aCount;
	int tCount;
	int cCount;
	int gCount;
	Pregunta7(int a, int tCount, int c, int g) {
		//line 1
		cCount = setCCount(c);
		//setGCount(g);
		aCount = a;		
	}
	int setCCount(int c) {
		return c;
	}
	void setGCount(int gCount) {
		this.gCount = gCount;
	}
	public static void main(String[] args) {
		Pregunta7 ee = new Pregunta7(0, 0, 0, 0);
		System.out.println("aCount: "+ee.aCount+ " tCount: "+ee.tCount+" cCount: "+ee.cCount+" gCount: "+ee.gCount);
	}
}
