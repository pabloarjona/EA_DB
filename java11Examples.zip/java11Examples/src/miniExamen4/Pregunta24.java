package miniExamen4;

import java.util.function.BiFunction;

//NO ENTIENDO VOLVER A HACER
/* Pregunta 24
 * Q: Given...
 * 	  It is required that if p instanceof Pair then p.isValid() returns true.
 *    Which is the smallest set of visibility changes to insure this requirement is met?
 */
public class Pregunta24<T> {
	final BiFunction<T, T, Boolean> validator;
	T left = null; 
	T right = null;
	
	private Pregunta24() {
		validator = null;
	}
	
	Pregunta24(BiFunction<T, T, Boolean> v, T x, T y){
		validator = v;
		set(x, y);
	}

	void set(T x, T y) {
		if(!validator.apply(x, y)) throw new IllegalArgumentException();
		setLeft(x);
		setRigth(y);
	}

	void setRigth(T y) {
		right= y;
		
	}

	void setLeft(T x) {
		left = x;
	}
	final boolean isValid() {
		return validator.apply(left, right);
	}
}
