package miniExamen4;

public enum Season{
	WINTER('w'), SPRING('s'), SUMMER('h'), FALL('f');
	char c;
	private Season(char c) {
		this.c = c;
	}
}
