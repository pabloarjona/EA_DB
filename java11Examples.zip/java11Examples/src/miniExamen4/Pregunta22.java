package miniExamen4;

import java.util.List;
import java.util.TreeSet;

//Consultar duda DANI
/* Pregunta 22
 * Q: Given...
 * 	  Which two method definitions at line n1 in the Bar class compile? (Choose two.)
 * A: B. public List<Integer> foo(Set<CharSequence> m){...}
 * 	  C. public List<Integer> foo(TreeSet<String> m){...}
 */
public class Pregunta22 extends Foo{
	//line 1
	/*Solucion 1
	public List<Integer> foo(Set<CharSequence> m){
		return null;
	}
	*/
	
	public List<Integer> foo(TreeSet<String> m){
		return null;
	}
}
