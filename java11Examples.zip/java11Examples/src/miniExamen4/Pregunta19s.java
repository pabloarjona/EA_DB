package miniExamen4;

import java.lang.annotation.ElementType;
import java.lang.annotation.Target;

@Target(ElementType.TYPE)
public @interface Pregunta19s{
	Pregunta19[] value();
}