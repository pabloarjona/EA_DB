package miniExamen4;

public class Person {
	private String name = "Green";
	public void setName(String name) {
		String title = "Mr. ";
		name = title + name;
	}
	public String toString() {
		return name;
	}

}
