package miniExamen4;

/* Pregunta 18
 * Q: Given...
 * 	  What is the result?
 * A: A. Joe
 *       null
 */
public class Pregunta18 {
	public static void main(String[] args) {
		Person2 p = new Person2("Joe");
		checkPerson(p);
		System.out.println(p);
		p=null;
		checkPerson(p);
		System.out.println(p);
	}

	private static Person2 checkPerson(Person2 p) {
		if(p==null) {
			p = new Person2("Mary");
		}else {
			p= null;
		}
		return p;
	}
}
