package tema13;

import java.lang.annotation.ElementType;


public class Exam {
	

	
	//el paquete es correcto
	@tema13.Exam.Ejercicio1.España.Madrid
	public static void main(String[] args) {

	}

	//P: ¿Compila?
	//R: Compila
	static class Ejercicio1{
		static class España{
			@Target(ElementType.METHOD)
			@interface Madrid{
				public String ____() default "esta vez te has pasado";
			}
		}
	}
	
	

	
}
