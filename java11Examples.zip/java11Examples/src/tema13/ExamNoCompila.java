package tema13;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;

//R: Falla la línea int Adios() = 2, las anotaciones son interfaces que usan métodos a nivel interno para pasar los argumentos no 
//variables
@Documented
@interface Ejercicio3{
	
	abstract int Hola();
	int Adios() = 2; 
	public String Wellcome();
}

//No compila, porque una anotación no puede contenerse así misma y valueOf se ejecuta en tiempo de ejecución y se hace una llamada  
//a Ejercicio4
@Target(ElementType.valueOf(ElementType.class, null))
@interface Ejercicio4{
	abstract int value() default 666;
	abstract Ejercicio4 pecado() default @Ejercicio4(value = 1);
}

@interface SEGA{
	String value() default "Sonic";
}

public class ExamNoCompila {
	
	@SEGA("")
	private String k = "Knucles";
	@SEGA
	private String t = "Tails";
	@SEGA("Amy")
	private String a;
	
	public static void main(String[] args) {
		Ejercicio5();
	}

	//P: ¿Esto está bien?
	//R: No, @Documented tiene un Retention de tipo annotation, solo puede anotar otras anotaciones y sive para que se genere
	// Javadoc de las mismas
	@Documented
	class Ejercicio2{
		
	}
	//R: no compila
	private static void Ejercicio5() {
		var fields = new ExamNoCompila().getClass().getDeclaredFields();
		for (Field f : fields) {
			if(f.isAnnotationPresent(SEGA.class)) {
				System.out.println(f.getAnnotation(SEGA.class).value());
			}
		}
	}
}
