package tema13;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Retention(RetentionPolicy.RUNTIME)
@interface Table{
	int n = 3;  //Son estaticos, final y públicos por defectos = constantes
	//no es obligatiorio con default
	int numero() default 1; 
	String value() default "hola";
	String value2() default "adios";
}

//Si queremos procesarlas en tiempo de ejecución debemos poner RUNTIME

@interface Field{
	
}

//Podemos restringuir su ámbito
@Target(ElementType.METHOD)
@interface Meta{
	
}

//Puede recibir valores primitivos, String, class y ¡otras anotaciones! Los parámetros serán indicados como métodos
@Target(ElementType.FIELD)
@Retention(RetentionPolicy.RUNTIME)
@interface Ultra{
	String value();
	int num = 2;
}

@Target(ElementType.FIELD)
@Retention(RetentionPolicy.RUNTIME)
@interface Mega{
	String value();
	Class<?> numeric() default Annotations.class;		//Con default, los valores deben ser obligatorios
	int num = 2;		//como son anotaciones este valor es public static final
}


//Es una manera de anotar nuestras clases con una serie de metadatos que nos permiten aportar información a la hora de crear clases,
//código reutilizable, etc.
public class Annotations {

	@Table(value = "jejeej", value2="ajajja")
	class Persona{
		
		@Field
		private Integer id;
		@Field
		private String nombre;
	}
	
	public static void main(String ...args) throws NoSuchFieldException, SecurityException {
		//Persona.class.getDeclaredField("id").getAnnotation(Field.class);
		System.out.println(Persona.class.getAnnotation(Table.class).value());
		//int n = Table.n;
	}
		
	
}
