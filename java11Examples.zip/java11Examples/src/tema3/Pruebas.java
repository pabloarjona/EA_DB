package tema3;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
public class Pruebas {
	List<BigDecimal> miList = new ArrayList<>();
	
	public static void main(String...args) {
		new Pruebas().comerMemoria();
	}
	
	public void comerMemoria() {
		while(true) {
			miList.add(new BigDecimal("123456789123456789123456789123456789")); miList.clear();
			System.out.println("+");
		}
	}
}
