package tema3;

abstract class Nueve{
	
}

public class Leccion {
	
	protected class Diez extends Nueve implements Ocho{
		
	}
	
	abstract static class Seis{
		class Cuatro extends Cinco{
			
		}
	}
	
	private interface Ocho{
		
		
	}
	
	final class Cinco extends Diez{
		
	}

}
