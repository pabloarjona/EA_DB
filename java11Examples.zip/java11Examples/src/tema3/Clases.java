package tema3;

class A {}

interface XXX { void saludar();}  

public class Clases {

	private class H {}
	
	public void x() {
		final class G extends H{}
		new H();
	}
	
	public static void xx() {
		Clases.xx();
		new Clases(). new H();
		
		new XXX() {

			@Override
			public void saludar() {
				// TODO Auto-generated method stub
				
			}
			 
		};
	}
	
	
	
}
