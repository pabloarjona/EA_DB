package tema3;

import java.io.Serializable;

interface II<E extends Serializable>{
	E get();
	void set(E e);
}

public class PruebaGenericoSerializable<EXEA extends Serializable> implements II<EXEA> {
	
	public static void main (String...args) {
		new PruebaGenericoSerializable<String>();
	}
		
	public <E> E matar(E tipo) {
		return tipo;
	}
	
	public <E> void morir(E tipo) {
		
	}

	@Override
	public EXEA get() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void set(EXEA e) {
		// TODO Auto-generated method stub
		
	}
	
	
}
