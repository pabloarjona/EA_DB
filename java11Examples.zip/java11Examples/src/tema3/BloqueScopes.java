package tema3;

public class BloqueScopes {
	
	public static void main(String... args) {
		saludar();
	}
	
	public static void saludar() {
		System.out.println("no puedo");
	}

}

class BloqueScopeseee{
	
	private static class Calculadora{
		public static void calcular() {
			System.out.println("pi pi pi pi");
		}
	}
	
	public static void main(String... args) {
		new Calculadora.calcular();
		new MiClase().n = 2;
		new MiClase.ClaseDentroDeMiClase().saludar2();
	}
}

class MiClase{
	int n = 2;
	int n2 = 3;
	public class ClaseDentroDeMiClase {
		void saludar2() {
			System.out.println("¡Bumb!");
		}
	}
}
