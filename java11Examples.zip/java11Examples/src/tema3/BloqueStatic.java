package tema3;

public class BloqueStatic {

	public static void main(String... args) {
		String s = Estatica.CONSTANTE;
		System.out.println("Aún no me llamaron");
		new Estatica() {};
		new Estatica() {};
		new Estatica() {};
	}
}

abstract class Estatica{
	
	static {
		System.out.println("yo voy primero");
	}
		
	public static final String CONSTANTE ="!";
	public Estatica() {
		System.out.println("soy el constructor");
	}
	
	static {
		System.out.println("yo voy primero");
	}
}
