package tema3;

interface I{
	//todos los metodos son abstractos y publicos, es decir van a ser obligados a ser implementados en la clase que lo extienda
	
	//default nos permite crear metodos, no pueden ser invocados de manera directa
	default void saludar() {
		//.................
	}
	
	//si pueden ser invocados de manera directa
	static void saludar2() {
		System.out.println("hola");
	}
}

public class PruebasInterfaces {
	
	public static void main(String...args) {
		I.saludar2();
	}

}
