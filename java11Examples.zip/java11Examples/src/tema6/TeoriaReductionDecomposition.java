package tema6;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.function.BiFunction;
import java.util.function.BinaryOperator;

public class TeoriaReductionDecomposition {
	public static void main(String[] args) {
		List<Integer> nums = Arrays.asList(1,2,3,4,5,6,7,8,9,0);
		//Función que acepta dos parametros y devuelve un resultado
		BiFunction<String, Integer, String> acumulator = new BiFunction<String, Integer, String>(){
			@Override 
			public String apply(String identity, Integer valor) {
				System.out.println("_______________acumulator___________________");
				System.out.println("identity: " +identity);
				System.out.println("valor: " + valor);
				String operacion = (identity.length()+valor)+" "+ identity;
				System.out.println("operacion:"+ operacion);
				System.out.println("__________________________");
				return operacion;
			}
		};
		
		BinaryOperator<String> combiner = new BinaryOperator<String>(){
			@Override
			public String apply(String t, String u) {
				System.out.println("_______________combinador___________________");
				System.out.println("combiner t: " +t);
				System.out.println("combiner u: " + u);
				String operacion = t+u;
				System.out.println("operacion:"+ operacion);
				System.out.println("__________________________");
				return operacion;
			}
		};
		
		//a pelo
		//Optional<Integer> a = nums.stream().reduce((Integer t, Integer u)-> t+u);
		//con identity
		//int b = nums.stream().reduce(5, (Integer t, Integer u) -> t+u);
		//con acumulator
		//String c = nums.stream().reduce("misNumeros => ", acumulator, combiner);
		
		String x = nums.parallelStream().reduce("misNumeros => ", (String acum, Integer valor) -> acum+valor, (String op1, String op2) -> op1+op2);
		System.out.println(x);
		
	}

}
