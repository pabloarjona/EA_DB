package tema6;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class TeoriaStreams {

	public static void main(String[] args) {
		Ejemplo1();
		Ejemplo2();
		Ejemplo3();
	}
	
	public static void Ejemplo1() {
		System.out.println("Ejemplo 1....");
		var miLista= Arrays.asList(66, 99, 23400, 12500000, 11, 252, 899999);
		Stream<Integer> st=  miLista.stream().filter(i -> i > 50 && i <100).filter(i-> i >0);
		List<Integer> l= st.collect(Collectors.toList());
		l.forEach(System.out::println);
		
	}
	
	
	public static void Ejemplo2() {
		System.out.println("Ejemplo 2....");
		Stream<String> s = Stream.of("esto", "mola", "mucho");
		//cada elemento del array lo transformamos en un 55
		//s.map(x-> 55).forEach(System.out::println);
		Function<String, Integer> mf = x-> x.length();
		
		s.collect(Collectors.toMap(x->x, mf));
	}
	
	public static void Ejemplo3() {
		System.out.println("Ejemplo 3...");
		Stream<String> s = Stream.of("esto", "mola", "mucho");
		Function<String, Integer> mf = x -> x.length();
		Optional<String> xxx = s.findAny();
		xxx.ifPresent( (x)->  System.out.println(x));
	}
	
	
}
