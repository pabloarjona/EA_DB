package tema6;

import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import java.util.stream.Stream;

class CursoJava{
	public String autor;
	public boolean esDificil;
	public int numeroAprobados;
	
	public CursoJava(String autor, boolean esDificil, int numeroAprobados) {
		//llamar y acceder a funciones del padre
		super();
		this.autor = autor;
		this.esDificil = esDificil;
		this.numeroAprobados = numeroAprobados;
	}
	
	public String toString() {
		return this.autor;
	}
}

public class TeoriaGroupingPartioning {

	public static void main(String[] args) {
		//es un proveedor, por lo tanto nos devuelve un valor o un objeto sin que nosotros le 
		//pasemos un parametro
		Supplier<CursoJava> cursoCreator= () ->{
			Random r = new Random();
			return new CursoJava("Paco "+r.nextInt(), r.nextBoolean(), r.nextInt());
		};
		Map<String, List<CursoJava>> grouping = null;
		Map<Boolean, List<CursoJava>> partioning = null;
		
		grouping = Stream.generate(cursoCreator).limit(10).collect(Collectors.groupingBy(x -> x.autor));
		
		grouping.entrySet().forEach(x -> System.out.println("key: "+ x.getKey()+ " value: " +x.getValue()));
		
		System.out.println("-----------------------------------------------------------------------------------");
		//List<CursoJava> lista= new List<CursoJava>();

		partioning = Stream.generate(cursoCreator).limit(10).collect(Collectors.partitioningBy(x -> x.numeroAprobados > 0));
		
		partioning.entrySet().forEach(x -> System.out.println("key: " + x.getKey() + " value: "+ x.getValue()));
	}		
	
}
