package tema6;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.function.BinaryOperator;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Leccion1 {
	public static void main(String... args) {
		Ejemplo0();
	}
	public static void Ejemplo0() {
		List<Integer> nums = Arrays.asList(10, 10, 10);
		BinaryOperator<Integer> operator = (x, y) -> x + y;

		int total = nums.stream().reduce(5, operator);
		//Se ejecuta a la vez por eso es probable que no devuelva el mismo resultado que total
		int total2 = nums.stream().parallel().reduce(5, operator);
		System.out.println(total);
		System.out.println(total2);
	}
	/*
	public void Ejemplo() {
		Predicate<?> p = ((x) -> x.hashCode() > 0);
		
		Function<Integer, String> f = (Integer f, String s) -> f.toString() + s;
				
		Consumer<String> c = x -> System.out.println(x);
				
		Consumer<String> cc = x -> x + " ...";
				
		Supplier<Character> s = null;
				
		Supplier<Character> ss = () -> ' ';
	}*/
	
	public void Ejemplo2() {
		//getBoolean(String name)
		Predicate<String> pp = Boolean::getBoolean;
				
		Predicate<Predicate<String>> p = x -> x.test("");
	}
	/*
	public void Ejemplo3() {
		var s = new HashSet<>(Arrays.asList("yo", "tendre", "los", "valores"));
		
		var<Integer, String> m = s.parallelStream().collect(Collectors.toMap(x -> x.length(), y -> y));
		//Map no tiene metodo stream
		m.stream().forEach((x, y) -> System.out.println("key: " + x + " Value: " + y));
	}
	
	public void Ejemplo4() {
		
		var s = new HashSet<>(Arrays.asList("yo", "tendre", "los", "valores"));
			
		var<Integer, String> m = s.parallelStream().collect(Collectors.toMap(x -> x.length(), y -> y));
			
		String algunoEncontrara = m.values().stream().filter(x -> x.contains("o")).findAny();
				
		System.out.println(algunoEncontrara);
				
	}
	*/
	public static void Ejemplo5() {
		Stream<String> s = Stream.of("Una loba como yo no está pa novato", "Una loba como yo no está pa' tipos como tú, uh, uh, uh, uh");
		//Foreach es una operación terminal y por lo tanto el stream() muere
		s.forEach(System.out::println);
		s.filter(x -> x.contains(x));
		s.forEach(System.out::println);
	}
	
	public static void Ejemplo6() {
		var s = new HashSet<>(Arrays.asList("yo", "tendre", "los", "valores"));

		//String replaceAll(String regex, String replacement)		
		Optional<String> esteProfeEsUnDemonio = s.stream().reduce(""::replaceAll);
	}
}

