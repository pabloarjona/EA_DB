package tema6;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.Random;
import java.util.Set;
import java.util.function.BiFunction;
import java.util.function.BinaryOperator;
import java.util.function.DoubleFunction;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class Exam {
	public static void main(String[] args) {
		//var stream = Stream.of(1,2,3);
		//first() / findAny() / anyMatch() / max() / min()
		//System.out.println(stream.anyMatch());
		List<Integer> nums = Arrays.asList(1,2,3,4,6,7,8,9);
		Predicate<Integer> pi = nums::contains;
		Optional<Integer> oi = Stream.of(1,3,5,7,9).filter(pi).reduce((x,y)-> x+y);
		System.out.println(oi.get());
		
		/*No compila
		Random r = new Random();
		//no se parametriza (se quita <Integer> para que funcione)
		IntSupplier<Integer> si = r::nextInt();
		InStream.generate(si);
		
		
		No compila List.of(1,2,3,4,5).parallelStream().parallelStream()..
		
		BiFunction<Double, Double, Double> paca;
		BinaryOperator<Double> puri = paca;
		Function<Double, Double> luci;
		DoubleFunction<Double> paqui = luci;
		
		Stream<String> maldicionAsesina = Stream.of("", "Avada", null, "Kedavra");
		maldicionAsesina.filter(String::isBlank);
		maldicionAsesina.filter(String::isEmpty);
		maldicionAsesina.filter(System.out::print);
		*/
		
		var bools = Stream.of(Boolean.TRUE, null);
		var map = bools.limit(1).collect(Collectors.partitioningBy(b -> b));
		System.out.println(map);
		
		var list = List.of("pes", "car");
		String x = unir(list);
		String y = separar(list);
		System.out.println(x+ " " +y);
		
		var examen = Set.of("estoy", "con", "el tiempo", "justo");
		var result = examen
				.stream()
				.collect(Collectors.partitioningBy(b -> b.contains("o")))
				.entrySet()
				.stream()
				.flatMap(t -> t.getValue().stream())
				.collect(Collectors.groupingBy(s -> !s.startsWith("e")));
		
		System.out.println(result);
		
	}
	
	public static String unir(List<String> values) {
		return values.parallelStream().reduce("a", (x,y) -> x + y, String::concat);
	}
	
	public static String separar(List<String> values) {
		return values.parallelStream().reduce((w ,z) -> z +w).get();
	}

}
