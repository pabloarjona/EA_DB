package tema6;

import java.time.LocalDate;

@FunctionalInterface
interface Maximal<T extends String>{
	int max(T t, LocalDate d);
	void ejemplo();
}

public class TeoriaFunctionalInterfaceLambda {

	
	public static void main(String[] args) {
		//Consumidor: que aceptan solo un valor y no devuelven valor alguno
		
		//Los parentesis seran obligatorios con cero o con más de un parámetro
		//Los tipos tambien seran opcionales
		//Siempre habrá que respetar el orden de los tipos
		//-> indicara el comienzo del cuerpo del método
		//La primera sentencia será return o el void
		//Las llaves {} serán opcionales. Si se incluyen, habrá que poner ;, return etc... como un método normal
		Maximal<String> m = (x,  y) -> x.length() % y.hashCode();
		Maximal<String> mm = TeoriaFunctionalInterfaceLambda::queCasualidad;
	}
	
	public static int queCasualidad(String x, LocalDate y) {
		return x.length() % y.hashCode();
	}
	
}
