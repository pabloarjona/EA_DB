package tema6;

public class TeoriaLambda {

	public static void main(String[] args) {
		Persona p= new Persona(23, "alfonso", "alfonso@gmail.com");
		
		p.valida(x -> x.edad >22);
		/* Es lo mismo
		p.valida(new ValidarPersona() {
			@Override
			public boolean validar(Persona p) {
				return p.edad>22;
			}
		});*/
		//esto es lo mismo que los de arriba
		p.valida(TeoriaLambda::xxx);
	}
	
	public static boolean xxx(Persona p) {
		return true;
	}
	
}

@FunctionalInterface
interface ValidarPersona{
	boolean validar(Persona p);

}


class Persona{
	public int edad;
	public String nombre;
	public String email;
	public boolean valido;
	
	public Persona(int edad, String nombre, String email) {
		super();
		this.edad = edad;
		this.nombre=nombre;
		this.email=email;
		
	}
	
	public boolean valida(ValidarPersona vp) {
		return vp.validar(this);
	}
}