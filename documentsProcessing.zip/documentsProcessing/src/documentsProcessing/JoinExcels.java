package documentsProcessing;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.Arrays;

import org.apache.poi.ss.usermodel.*;
/**
 * Clase que nos sirve para leer y combinar el contenido de X archivos Excel (dentro de una carpeta) en una sola hoja de cálculo
 * @author parjrui
 *
 */
public class JoinExcels {
	
	static String sourceFilePath="";
	static boolean isDirectory=false;
	
	public static void main(String[] args) throws IOException {
		//Movemos todos los archivos xlsx a una carpeta nueva
		String sourceFolderPath = "\\\\10.43.108.140\\Tomcat\\Descargas Notes\\03 PROCEDIMIENTOS OPERATIVOS";
		String destinationFolderPath = "C:\\MergeExcel";
		
		moveXlsxFiles(sourceFolderPath, destinationFolderPath);
		
		//String folderPath = "Ruta de la carpeta que contiene los archivo Excel";
		//String outputFilePath = "Ruta del archivo de salida combinado.xlsx";
		//mergeExcelFiles(folderPath,outputFilePath);
	}

	public static void moveXlsxFiles(String sourceFolderPath, String destinationFolderPath) throws IOException {
		File sourceFolder = new File(sourceFolderPath);
		if(!sourceFilePath.equals("")) {
			sourceFolder = new File(sourceFilePath);
		}
		File[] files = sourceFolder.listFiles();
		
		if(files != null) {
			for(File file : files) {
				if(file.isDirectory()) {
					sourceFilePath= file.getPath();
					moveXlsxFiles(sourceFolderPath, destinationFolderPath);
				}else {
					String fileName = file.getName();
					if(fileName.toLowerCase().endsWith("revisado.xlsx")) {
						moveFile(file, destinationFolderPath);
						sourceFilePath="";
					}
				}
			}
		}
	}

	public static void moveFile(File file, String destinationFolderPath) throws IOException {
		File destinationFolder = new File(destinationFolderPath);
		if(!destinationFolder.exists()) {
			destinationFolder.mkdirs();
		}
		//int cont = 0;
		try {
			Path sourcePath = file.toPath();
			Path destinationPath = new File(destinationFolderPath, file.getName()).toPath();
			Files.copy(sourcePath, destinationPath, StandardCopyOption.REPLACE_EXISTING);
			System.out.println("Archivo copiado: " + file.getName());
			//cont++;
		}catch (IOException e){
			System.out.println("Error al mover el archivo: " + file.getName());
			e.printStackTrace();
		}
	}
}
