package documentsProcessing;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import org.apache.commons.io.FileUtils;


public class JoinDirectories {
	public static void main(String[] args) {
		String sourceFolderPath="Q:\\Grupos\\CIGES-DESARROLLO-APLICACIONES\\NOREMA\\03 PROCEDIMIENTOS OPERATIVOS";
		String targetFolderPath="C:\\MergeExcel";
		try {
			copyDirectories(sourceFolderPath,targetFolderPath);
			System.out.println("Archivos copiados correctamente");
		}catch(IOException e){
			e.printStackTrace();
			System.out.println("Error a la hora de copiar los archivos");
		}
	}

	private static void copyDirectories(String sourceFolderPath, String targetFolderPath) throws IOException {
		Path originPath= Paths.get(sourceFolderPath);
		File sourceFolder= new File(originPath.toString());
	    if(sourceFolder.isDirectory()) {
	    	for(File file : sourceFolder.listFiles()) {
	    		if(file.isDirectory()) {
	    			for(File file2 : file.listFiles()) {
	    				if(file2.isDirectory()) {
	    					try {
	    						FileUtils.copyDirectory(file2,new File(targetFolderPath, file2.getName()));
	    						System.out.println("Archivo copiado correctamente.");
	  	  	    			} catch (IOException e) {
	  	  	    				e.printStackTrace();
	  	  	    				System.out.println("Error a la hora de copiar archivo.");
	  	  	    			}  
	    				}
	    			}
	    		}
	    	}
	    }
	}
}
