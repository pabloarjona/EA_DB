package documentsProcessing;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Date;

public class MergeExcels {
	public static void main(String[] args) throws IOException {
		//Ruta de la carpeta que contiene los archivos xlsx
		String folderPath ="C:\\MergeExcel";
		//Ruta y nombre del archivo Excel combinado
		String outputFileString = "C:\\MergeExcel\\PROCEDIMIENTOS_OPERATIVOS_MERGED.xlsx";
		//File outputFile = new File(outputFileString);
		//new FileOutputStream(new File(outputFileString), false).close();		
		try {
			mergeExcelFiles(folderPath, outputFileString);
			System.out.println("Archivos combinados correctamente");
		}catch (IOException e){
			System.out.println("Error al combinar los archivos Excel.");
			e.printStackTrace();
		}
	}

	public static void mergeExcelFiles(String folderPath, String outputFileString) throws IOException{
		//Creamos el libro de excel
		Workbook mergedWorkbook = new XSSFWorkbook();
		//Workbook mergedWorkbook = WorkbookFactory.create(new File(folderPath));
		//Crear el libro de Excel
		Sheet mergedSheet = mergedWorkbook.createSheet("MergedSheet");
		File folder = new File(folderPath);
		File[] files = folder.listFiles((dir, name) -> name.toLowerCase().endsWith(".xlsx"));
		
		if(files != null) {
			int rowIndex = 0;
			//Copiar la cabecera desde el primer archivo
			Workbook firstWorkbook = WorkbookFactory.create(new File(files[0].getAbsolutePath()));
			Sheet firstSheet = firstWorkbook.getSheetAt(0);
			copyHeader(firstSheet, mergedSheet, rowIndex);
			
			rowIndex++;
			
			//Copiar el contenido de los archivos restantes
			for(int i =0; i<files.length; i++) {
				File file = files[i];
				if(file.length() > 0) {
					Workbook workbook = WorkbookFactory.create(new File(files[i].getAbsolutePath()));
					Sheet sheet = workbook.getSheetAt(0);
					copySheet(sheet, mergedSheet, rowIndex);
					rowIndex += sheet.getLastRowNum();
					workbook.close();
				}
			}
			firstWorkbook.close();
		}
		//Guardamos el archivo excel combinado
		try (FileOutputStream outputStream = new FileOutputStream(outputFileString)){
			mergedWorkbook.write(outputStream);
		}
		
		mergedWorkbook.close();
	}
	
	public static void copyHeader(Sheet sourceSheet, Sheet targetSheet, int rowIndex) {
		Row sourceRow = sourceSheet.getRow(0);
		Row targetRow = targetSheet.createRow(rowIndex);
		
		for(int i =0; i<sourceRow.getLastCellNum(); i++) {
			Cell sourceCell = sourceRow.getCell(i);
			Cell targetCell = targetRow.createCell(i);
			
			if(sourceCell != null) {
				targetCell.setCellValue(sourceCell.getStringCellValue());
			}
		}
	}
	
	public static void copySheet(Sheet sourceSheet, Sheet targetSheet, int rowIndex) {
        for (int i = 1; i <= sourceSheet.getLastRowNum(); i++) {
            Row sourceRow = sourceSheet.getRow(i);
            Row targetRow = targetSheet.createRow(rowIndex);
            if(sourceRow != null) {
            	for (int j = 0; j < sourceRow.getLastCellNum(); j++) {
                    Cell sourceCell = sourceRow.getCell(j);
                    Cell targetCell = targetRow.createCell(j);

                    if (sourceCell != null) {
                    	targetCell.setCellValue(getCellValueAsString(sourceCell));
                    }
                }
            }
            rowIndex++;
        }
	}
	
	private static String getCellValueAsString(Cell sourceCell) {
		String cellValue="";
		if(sourceCell.getCellType() == CellType.STRING) {
			cellValue = sourceCell.getStringCellValue();
		}else if(sourceCell.getCellType() == CellType.NUMERIC) {
			cellValue = String.valueOf(sourceCell.getNumericCellValue());
		}else if(sourceCell.getCellType() == CellType.BOOLEAN) {
			cellValue = String.valueOf(sourceCell.getBooleanCellValue());
		}else if(sourceCell.getCellType() == CellType.FORMULA) {
			cellValue = sourceCell.getCellFormula();
		}
		return cellValue;
	}
}
