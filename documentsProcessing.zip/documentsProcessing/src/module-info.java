/**
 * 
 */
/**
 * @author parjrui
 *
 */
module documentsProcessing {
	requires org.apache.poi.poi;
	requires org.apache.poi.ooxml;
	requires org.apache.commons.io;
}