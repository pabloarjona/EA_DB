/**
 * 
 */
/**
 * @author parjrui
 *
 */
module cartaOperacionales {
	requires opencms;
}