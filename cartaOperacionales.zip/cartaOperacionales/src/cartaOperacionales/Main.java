package cartaOperacionales;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Date;

import org.opencms.file.CmsFile;
import org.opencms.file.CmsObject;
import org.opencms.file.CmsResource;
import org.opencms.xml.content.CmsXmlContent;

public class Main {
	public static void main(String[] args) {
		//test2();
		//prueba();
		//test();
		//test2();
		pasarLongADate("1683190680000");
		//System.out.println(comprobarParseLongADate());
		//devolverFechaFormateada("Fecha", "09/03/2022");
		/*
		DocumentoCartaOperacionalOpencms documento = new DocumentoCartaOperacionalOpencms("1", "EN VIGOR", "TITULO 1", "ASUNTO1", "22/02/2021", "", "", "", 
				"", "", "", "", "", "");
		documento.addAnexo(new Anexo("tituloanexo1", "enlace1"));
		DocumentoCartaOperacionalOpencms documento2 = new DocumentoCartaOperacionalOpencms("2", "EN VIGOR", "TITULO 2", "ASUNTO2", "22/03/2022", "", "", "", 
				"", "", "", "", "", ""); 
		documento2.addAnexo(new Anexo("tituloanexo2.pdf", "enlace2"));
		DocumentoCartaOperacionalOpencms documento3 = new DocumentoCartaOperacionalOpencms("3", "EN VIGOR", "TITULO 3", "ASUNTO3", "22/01/2023", "", "", "", 
				"", "", "", "", "", ""); 
		documento3.addAnexo(new Anexo("tituloanexo3.pdf", "enlace3"));
		DocumentoCartaOperacionalOpencms documento4 = new DocumentoCartaOperacionalOpencms("4", "EN VIGOR", "TITULO 4", "ASUNTO4", "22/01/2022", "", "", "", 
				"", "", "", "", "", ""); 
		documento4.addAnexo(new Anexo("tituloanexo4.pdf", "enlace4"));
		DocumentoCartaOperacionalOpencms documento5 = new DocumentoCartaOperacionalOpencms("5", "CANCELADO", "TITULO 5", "ASUNTO5", "22/01/2021", "", "", "", 
				"", "", "", "", "", ""); 
		documento5.addAnexo(new Anexo("tituloanexo5.pdf", "enlace5"));
		ArrayList<DocumentoCartaOperacionalOpencms> ee = new ArrayList<DocumentoCartaOperacionalOpencms>(); 
		ee.add(documento); ee.add(documento2); ee.add(documento3); ee.add(documento4); ee.add(documento5);
		//listaDocumentos = ee;
		ListaDocumentos lista = new ListaDocumentos(ee);
		NavigableMap<String, NavigableMap<String, ArrayList<DocumentoCartaOperacionalOpencms>>> listaDocumentos = lista.getListaPorSituacionOrdenadaPorAnios();
		for (String key : listaDocumentos.keySet()) {
			System.out.println(key);
			for (String key2 : listaDocumentos.get(key).keySet()) {
				System.out.println(key2);
			}
		}*/
	}
	
	public static void prueba() {
		String fecha="23/12/2020";
		try {
			SimpleDateFormat parseFormat = new SimpleDateFormat("dd/MM/yyyy");
			Date date = parseFormat.parse(fecha);
			String e = Long.toString(date.getTime());
			System.out.println(e);
		}catch (Exception e){
			
		}
	}
	
	public static void test() {
		String fecha= "23/12/2020";
		try{
			SimpleDateFormat parseFormat = new SimpleDateFormat("dd/MM/yyyy");
			Date date = parseFormat.parse(fecha);
			parseFormat.applyLocalizedPattern("dd/MM/yyyy hh:mm");
			String fecha2=  parseFormat.format(date);
			System.out.println(fecha2);
		}catch(ParseException e){
			System.out.println("excepcion");
		}
	}
	
	public static void test2() {
		String fecha = "22/08/2023";
		try {
			SimpleDateFormat parseFormat = new SimpleDateFormat("dd/MM/yyyy");
			Date date = parseFormat.parse(fecha);
			System.out.println(Long.toString(date.getTime())); 
		}catch(ParseException e){
			
		}
	}
	
	private static boolean comprobarParseLongADate() {
		String fecha = "1673218800000";
		if(fecha.length()==13) {
			return true;
		}
		return false;
	}
	
	public static String pasarLongADate(String fecha) {
		try {
			long miliS = Long.parseLong(fecha);
			Date date = new Date();
			date.setTime(miliS);
			fecha =new SimpleDateFormat("dd/MM/yyyy").format(date);
			System.out.println(fecha);
		}catch(Exception e){
			System.out.println();
		}
		return fecha;
	}

	
	public static String getFechaEnVigor() {
		String fechaEnVigor="01/08/2022";
		if(fechaEnVigor.length() == 10){
			fechaEnVigor =fechaEnVigor  + " 01:00";
		}
		System.out.println(fechaEnVigor);
		return fechaEnVigor;
	}
	
	public static String getLastN(String s, int n) {
		if(s== null || n > s.length()) {
			return s;
		}
		return s.substring(s.length()-n);
	}
	
	public static String getDateTime(LocalDateTime date, int format) {
		String fecha=Integer.toString(date.getYear()) +"/"+ Integer.toString(date.getMonthValue())+"/"+Integer.toString(date.getDayOfMonth());
		return fecha;
	}
	
	protected String getNombreKey(String nombrePathKey) {
		String nombreKey;
		int indiceInicio = 0;
		if(nombrePathKey.lastIndexOf("/") != -1)
		{
			indiceInicio = nombrePathKey.lastIndexOf("/");
		}
		int indiceFin = nombrePathKey.lastIndexOf("[");
		nombreKey = nombrePathKey.substring(indiceInicio, indiceFin);
		return nombreKey;
	}
	
	private static void devolverFechaFormateada(String nombreAtributoP, String fecha) {
		if(nombreAtributoP.equals("Fecha") || nombreAtributoP.equals("Fecha_Estado")) {
			String nombreAtributo; 
			if(nombreAtributoP.equals("Fecha")) {
				nombreAtributo = "Fecha_Date";
			}else {
				nombreAtributo = "Fecha_Estado_Date";
			}
			try {
				SimpleDateFormat parseFormat = new SimpleDateFormat("dd/MM/yyyy");
				Date date = parseFormat.parse(fecha);
				System.out.println("Nombre atributo:" +nombreAtributo);
				System.out.println(Long.toString(date.getTime()));
			}catch(Exception e){
				
			}
		}
	}
}
