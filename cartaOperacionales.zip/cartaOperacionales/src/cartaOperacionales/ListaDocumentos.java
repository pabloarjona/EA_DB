package cartaOperacionales;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.NavigableMap;
import java.util.TreeMap;

public class ListaDocumentos extends ArrayList
{

	private static List<DocumentoCartaOperacionalOpencms> listaDocumentos = new ArrayList<>();
	public ListaDocumentos(List<DocumentoCartaOperacionalOpencms> lista){
		super();
		listaDocumentos=lista;
	}
	
	public ListaDocumentos() {

	}
	public  ArrayList<String> getAnios(){
		ArrayList<String> anios = new ArrayList<>();
		boolean encontrado = false;
		String anioFechaEnVigor = "";
		for (DocumentoCartaOperacionalOpencms documento: listaDocumentos){
			encontrado = false;
			for (String anio:anios)
			{
				anioFechaEnVigor = documento.getFechaEnVigor().substring(documento.getFechaEnVigor().lastIndexOf("/")+1);
				if(anio.equals(anioFechaEnVigor)){
					encontrado = true;
				}
			}
			if(!encontrado){
				anios.add(anioFechaEnVigor);
			}
		}
		Collections.sort(anios);
		Collections.reverse(anios);
		return anios;
	}
	
	public static HashMap<String, ArrayList<DocumentoCartaOperacionalOpencms>> getListaPorAnios(String situacion){

		HashMap<String, ArrayList<DocumentoCartaOperacionalOpencms>> listasPorAnios = new HashMap<String, ArrayList<DocumentoCartaOperacionalOpencms>>();
		ArrayList<String> anios = new ArrayList<String>();
		String anioDoc = "";
		
		ArrayList<DocumentoCartaOperacionalOpencms> listaPorAnio = new ArrayList<>();
		for (String anio: anios){
			
			listaPorAnio = new ArrayList<>();
			
			for (DocumentoCartaOperacionalOpencms documento: listaDocumentos){
				anioDoc = documento.getFechaEnVigor().substring(documento.getFechaEnVigor().lastIndexOf("/")+1);
				if(anioDoc.equals(anio) && documento.getSituacion().equals(situacion)){
					listaPorAnio.add(documento);
				}
			}
			if(listaPorAnio.size()>0){
				Collections.sort(listaPorAnio, new ComparaFechas());
				Collections.reverse(listaPorAnio);
				listasPorAnios.put(anio,listaPorAnio);
			}	
		}
		return  listasPorAnios;
	}
	
	public ArrayList<String> getAniosOrdenados(String anio, String situacion){
		ArrayList<String> aniosOrdenados = new ArrayList<>();
		ArrayList<DocumentoCartaOperacionalOpencms> listaDocumentos =getListaPorAnios(situacion).get(anio);
		for(DocumentoCartaOperacionalOpencms documento: listaDocumentos){
			aniosOrdenados.add(documento.getFechaEnVigor().substring(documento.getFechaEnVigor().lastIndexOf("/")+1));
		}
		Collections.sort(aniosOrdenados);
		return aniosOrdenados;
		
	}
	public ArrayList<DocumentoCartaOperacionalOpencms> getListaDocumentosOrdenadosPorFecha(String anio, String situacion){
		ArrayList<String> aniosOrdenados = getAniosOrdenados(anio, situacion);
		ArrayList<DocumentoCartaOperacionalOpencms> listaDocumentos =getListaPorAnios(situacion).get(anio);
		ArrayList<DocumentoCartaOperacionalOpencms> listaDocumentosOrdenados = new ArrayList<>();
		for(String anioOredenado:aniosOrdenados){
			for(DocumentoCartaOperacionalOpencms documento: listaDocumentos){
				if(anioOredenado.equals(documento.getFechaEnVigor().substring(documento.getFechaEnVigor().lastIndexOf("/")+1))){
					listaDocumentosOrdenados.add(documento);
					break;
				}
			}
		}
		return listaDocumentosOrdenados;
		
	}
	
	public NavigableMap<String, NavigableMap<String, ArrayList<DocumentoCartaOperacionalOpencms>>> getListaPorSituacionOrdenadaPorAnios(){
		
		HashMap<String, ArrayList<DocumentoCartaOperacionalOpencms>> listaDocumentosEnVigorPorAnios = getListaPorAnios("EN VIGOR");
		HashMap<String, ArrayList<DocumentoCartaOperacionalOpencms>> listaDocumentosCanceladosPorAnios = getListaPorAnios("CANCELADO");
		
		TreeMap<String, ArrayList<DocumentoCartaOperacionalOpencms>> listaDocumentosEnVigorOrdenadaPorAnios = new TreeMap<>();
		TreeMap<String, ArrayList<DocumentoCartaOperacionalOpencms>> listaDocumentosCanceladosOrdenadaPorAnios = new TreeMap<>();
		listaDocumentosEnVigorOrdenadaPorAnios.putAll(listaDocumentosEnVigorPorAnios);
		listaDocumentosCanceladosOrdenadaPorAnios.putAll(listaDocumentosCanceladosPorAnios);
		
		TreeMap<String, NavigableMap<String, ArrayList<DocumentoCartaOperacionalOpencms>>> listaDocumentosPorSituacion = new TreeMap<>();
		listaDocumentosPorSituacion.put("EN VIGOR", listaDocumentosEnVigorOrdenadaPorAnios.descendingMap());
		listaDocumentosPorSituacion.put("CANCELADO", listaDocumentosCanceladosOrdenadaPorAnios.descendingMap());
		
		return listaDocumentosPorSituacion.descendingMap();
	}
	
}

