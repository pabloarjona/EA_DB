package cartaOperacionales;

import java.util.Comparator;

public class ComparaFechas implements Comparator<DocumentoCartaOperacionalOpencms> {
	@Override
	public int compare(DocumentoCartaOperacionalOpencms doc1, DocumentoCartaOperacionalOpencms doc2){
		String fecha1 = doc1.getFechaEnVigor();
		String fecha2 = doc2.getFechaEnVigor();
		if(!fecha1.equals("") && !fecha2.equals("")){
			fecha1 = fecha1.substring(fecha1.indexOf("/"), fecha1.lastIndexOf("/")).concat(fecha1.substring(0, fecha1.indexOf("/")));
			fecha2 = fecha2.substring(fecha2.indexOf("/"), fecha2.lastIndexOf("/")).concat(fecha2.substring(0, fecha2.indexOf("/")));
		}
		return fecha1.compareTo(fecha2);
	}
}