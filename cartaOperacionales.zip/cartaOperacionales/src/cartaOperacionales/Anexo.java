package cartaOperacionales;

public class Anexo{
	private String nombre;

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	private String link;

	public String getLink() {
		return link;
	}

	public void setLink(String link) {
		this.link = link;
	}
	
	public Anexo() {
		super();
	}

	public Anexo(String nombre, String link) {
		this.nombre = nombre;
		this.link = link;
	}
}
