package cartaOperacionales;

import java.util.ArrayList;
import java.util.Date;

public class DocumentoCartaOperacionalOpencms{
	private String id;
	private String situacion;
	private String titulo;
	private String asunto;
	private String fechaEnVigor;
	private String fechaFinal;
	private Date fechaEnVigorTime;
	private Date fechaFinalTime;
	private String clasSeguridad;
	private String originadoPor;
	private String signatMinisdef1;
	private String signatMinisdef2;
	private String signatMinisdef3;
	private String otroSignat1;
	private String otroSignat2;
	private String otroSignat3;
	private String resourceId;

	private String pathDocumento;
	ArrayList<Anexo> anexos = new ArrayList<Anexo>();

	public ArrayList<Anexo> getAnexos() {
		return anexos;
	}
	
	public void setAnexos(ArrayList<Anexo> anexos) {
		this.anexos = anexos;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}
	
	public String getResourceId() {
		return resourceId;
	}

	public void setResourceId(String resourceId) {
		this.resourceId = resourceId;
	}
	
	public String getSituacion() {
		return situacion;
	}
	public void setSituacion(String situacion) {
		this.situacion = situacion;
	}
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	public String getAsunto() {
		return asunto;
	}
	public void setAsunto(String asunto) {
		this.asunto = asunto;
	}
	public String getFechaEnVigor() {
		return fechaEnVigor;
	}
	public void setFechaEnVigor(String fechaEnVigor) {	
		this.fechaEnVigor = fechaEnVigor;
	}
	public String getFechaFinal() {
		return fechaFinal;
	}
	public void setFechaFinal(String fechaFinal) {
		this.fechaFinal = fechaFinal;
	}
	
	public Date getFechaEnVigorTime() {
		return fechaEnVigorTime;
	}
	public void setFechaEnVigorTime(Date fechaEnVigorTime) {	
		this.fechaEnVigorTime = fechaEnVigorTime;
	}
	public Date getFechaFinalTime() {
		return fechaFinalTime;
	}
	public void setFechaFinalTime(Date fechaFinalTime) {
		this.fechaFinalTime = fechaFinalTime;
	}
	
	public String getClasSeguridad() {
		return clasSeguridad;
	}
	public void setClasSeguridad(String clasSeguridad) {
		this.clasSeguridad = clasSeguridad;
	}
	public String getOriginadoPor() {
		return originadoPor;
	}
	public void setOriginadoPor(String originadoPor) {
		this.originadoPor = originadoPor;
	}
	public String getSignatMinisdef1() {
		return signatMinisdef1;
	}
	public void setSignatMinisdef1(String signatMinisdef1) {
		this.signatMinisdef1 = signatMinisdef1;
	}
	public String getSignatMinisdef2() {
		return signatMinisdef2;
	}
	public void setSignatMinisdef2(String signatMinisdef2) {
		this.signatMinisdef2 = signatMinisdef2;
	}
	public String getSignatMinisdef3() {
		return signatMinisdef3;
	}
	public void setSignatMinisdef3(String signatMinisdef3) {
		this.signatMinisdef3 = signatMinisdef3;
	}
	public String getOtroSignat1() {
		return otroSignat1;
	}
	public void setOtroSignat1(String otroSignat1) {
		this.otroSignat1 = otroSignat1;
	}
	public String getOtroSignat2() {
		return otroSignat2;
	}
	public void setOtroSignat2(String otroSignat2) {
		this.otroSignat2 = otroSignat2;
	}
	public String getOtroSignat3() {
		return otroSignat3;
	}
	public void setOtroSignat3(String otroSignat3) {
		this.otroSignat3 = otroSignat3;
	}
	
	public String getPathDocumento() {
		return pathDocumento;
	}

	public void setPathDocumento(String pathDocumento) {
		this.pathDocumento = pathDocumento;
	}

	public DocumentoCartaOperacionalOpencms() {
		super();
		anexos = new ArrayList<Anexo>();
	}
	public DocumentoCartaOperacionalOpencms(String id, String situacion) {
		this.id = id;
		this.situacion = situacion;
		anexos = new ArrayList<Anexo>();
	}

	public void addAnexo(Anexo anexo){
		anexos.add(anexo);
	}
	public DocumentoCartaOperacionalOpencms(String id, String situacion, String titulo, String asunto, String fechaEnVigor, String fechaFinal, String fechaEnVigorTime, String fechaFinalTime, String clasSeguridad, String originadoPor, 
											String signatMinisdef1, String signatMinisdef2, String signatMinisdef3, String otroSignat1, String otroSignat2, String otroSignat3) {
		this.id = id;
		this.situacion = situacion;
		this.titulo = titulo;
		this.asunto = asunto;
		this.fechaEnVigor = fechaEnVigor;
		this.fechaFinal = fechaFinal;
		this.clasSeguridad = clasSeguridad;
		this.originadoPor = originadoPor;
		this.signatMinisdef1 = signatMinisdef1;
		this.signatMinisdef2 = signatMinisdef2;
		this.signatMinisdef3 = signatMinisdef3;
		this.otroSignat1 = otroSignat1;
		this.otroSignat2 = otroSignat2;
		this.otroSignat3 = otroSignat3;

	}

	public DocumentoCartaOperacionalOpencms(String id, String situacion, String titulo, String asunto, String fechaEnVigor, String fechaFinal, String fechaEnVigorTime, String fechaFinalTime, String clasSeguridad, String originadoPor, 
											String signatMinisdef1, String signatMinisdef2, String signatMinisdef3, String otroSignat1, String otroSignat2, String otroSignat3, String pathDocumento) {
		this.id = id;
		this.situacion = situacion;
		this.titulo = titulo;
		this.asunto = asunto;
		this.fechaEnVigor = fechaEnVigor;
		this.fechaFinal = fechaFinal;
		this.clasSeguridad = clasSeguridad;
		this.originadoPor = originadoPor;
		this.signatMinisdef1 = signatMinisdef1;
		this.signatMinisdef2 = signatMinisdef2;
		this.signatMinisdef3 = signatMinisdef3;
		this.otroSignat1 = otroSignat1;
		this.otroSignat2 = otroSignat2;
		this.otroSignat3 = otroSignat3;
		this.pathDocumento = pathDocumento;
	}
	public void setValueCampo(String name, String valor){

		if(name.toLowerCase().contains("ID_Carta".toLowerCase()))
			setId(valor);
		else if(name.toLowerCase().contains("situacion".toLowerCase()) || name.toLowerCase().contains("situación".toLowerCase()))
			setSituacion(valor);
		else if(name.toLowerCase().contains("titulo".toLowerCase()) || name.toLowerCase().contains("título".toLowerCase()))
			setTitulo(valor);
		else if(name.toLowerCase().contains("asunto".toLowerCase()))
			setAsunto(valor);
		else if(name.toLowerCase().contains("fechaEnVigor".toLowerCase()))
			setFechaEnVigor(valor);
		else if(name.toLowerCase().contains("fechaFinal".toLowerCase()))
			setFechaFinal(valor);
		else if(name.toLowerCase().contains("clasSeguridad".toLowerCase()))
			setClasSeguridad(valor);
		else if(name.toLowerCase().contains("originadoPor".toLowerCase()))
			setOriginadoPor(valor);
		else if(name.toLowerCase().contains("signatMinisdef1".toLowerCase()))
			setSignatMinisdef1(valor);
		else if(name.toLowerCase().contains("signatMinisdef2".toLowerCase()))
			setSignatMinisdef2(valor);
		else if(name.toLowerCase().contains("signatMinisdef3".toLowerCase()))
			setSignatMinisdef3(valor);
		else if(name.toLowerCase().contains("otroSignat1".toLowerCase()))
			setOtroSignat1(valor);
		else if(name.toLowerCase().contains("otroSignat2".toLowerCase()))
			setOtroSignat2(valor);
		else if(name.toLowerCase().contains("otroSignat3".toLowerCase()))
			setOtroSignat3(valor);
	}
	public String getValueCampo(String name){

		if(name.toLowerCase().contains("ID_Carta".toLowerCase()))
			return id;
		else if(name.toLowerCase().contains("situacion".toLowerCase()) || name.toLowerCase().contains("situación".toLowerCase()))
			return situacion;
		else if(name.toLowerCase().contains("titulo".toLowerCase()) || name.toLowerCase().contains("título".toLowerCase()))
			return titulo;
		else if(name.toLowerCase().contains("asunto".toLowerCase()))
			return asunto;
		else if(name.toLowerCase().contains("fechaEnVigor".toLowerCase()))
			return fechaEnVigor;
		else if(name.toLowerCase().contains("fechaFinal".toLowerCase()))
			return fechaFinal;
		else if(name.toLowerCase().contains("clasSeguridad".toLowerCase()))
			return clasSeguridad;
		else if(name.toLowerCase().contains("originadoPor".toLowerCase()))
			return originadoPor;
		else if(name.toLowerCase().contains("signatMinisdef1".toLowerCase()))
			return signatMinisdef1;
		else if(name.toLowerCase().contains("signatMinisdef2".toLowerCase()))
			return signatMinisdef2;
		else if(name.toLowerCase().contains("signatMinisdef3".toLowerCase()))
			return signatMinisdef3;
		else if(name.toLowerCase().contains("otroSignat1".toLowerCase()))
			return otroSignat1;
		else if(name.toLowerCase().contains("otroSignat2".toLowerCase()))
			return otroSignat2;
		else if(name.toLowerCase().contains("otroSignat3".toLowerCase()))
			return otroSignat3;
		else
			return "";
	}
	String titulosAnexos="";
	public String getTitulosAnexos(){
		for (Anexo anexo: anexos){
			titulosAnexos += anexo.getNombre();
		}
		return titulosAnexos;
	}
	String titulosDocumentosAnexos="";
	public String getTitulosDocumentosAnexos(){
		for (Anexo anexo: anexos){
			titulosDocumentosAnexos += "<p><li><a href='#'>"+anexo.getNombre()+"</a></li></p>";
			
		}
		return titulosDocumentosAnexos;
	}
}


