package procedimientosOperativos;

public class Enmienda{
	private String valor;
	private String fecha;
	
	public Enmienda(String valor, String fecha) {
		this.valor = valor;
		this.fecha = fecha;
	}
	public String get(String nombreAtributo){
		String valor = "";
		if(nombreAtributo.equals("Valor")){
			valor = this.valor;
		}else if(nombreAtributo.equals("Fecha")){
			valor =fecha;
		}
		return valor;
	}
	
	public Enmienda() {
		super();
	}

	
}
