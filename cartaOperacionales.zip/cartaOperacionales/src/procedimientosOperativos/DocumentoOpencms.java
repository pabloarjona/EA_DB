package procedimientosOperativos;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;

import org.opencms.file.CmsFile;
import org.opencms.file.CmsObject;
import org.opencms.file.CmsResource;
import org.opencms.i18n.CmsResourceBundleLoader;
import org.opencms.main.CmsException;
import org.opencms.main.OpenCms;
import org.opencms.xml.CmsXmlException;
import org.opencms.xml.content.CmsXmlContent;
import org.opencms.xml.content.CmsXmlContentFactory;
import org.opencms.xml.types.I_CmsXmlContentValue;

import cartaOperacionales.Anexo;

public class DocumentoOpencms {
	ArrayList<Anexo> anexos = new ArrayList<Anexo>();
	private ResourceBundle bundleKeys = null;
	private String id;
	private String structureId;
	private String pathDocumento;
	ArrayList<Enmienda> enmiendas = new ArrayList<Enmienda>();
	HashMap<String, String> datos = new HashMap<String, String>();

	public String getPathDocumento() {
		return pathDocumento;
	}

	public void setPathDocumento(String pathDocumento) {
		this.pathDocumento = pathDocumento;
	}
	
	public String getStructureId() {
		return structureId;
	}
	public void setStructureId(String structureId) {
		this.structureId = structureId;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	
	protected String getNombreKey(String nombrePathKey) {
		String nombreKey;
		int indiceInicio = 0;
		if(nombrePathKey.lastIndexOf("/") != -1)
		{
			indiceInicio = nombrePathKey.lastIndexOf("/");
		}
		int indiceFin = nombrePathKey.lastIndexOf("[");
		nombreKey = nombrePathKey.substring(indiceInicio, indiceFin);
		
		return nombreKey;
	}
	
	public DocumentoOpencms(CmsResource recurso, CmsObject cmsObject) throws Exception {
		//Recogemos el idioma
		Locale idioma = cmsObject.getRequestContext().getLocale();
		
		//Recoge el bundle de las keys
		bundleKeys =CmsResourceBundleLoader.getBundle("ea.keys.documentos", idioma);
		
		CmsFile fileRecurso = cmsObject.readFile(recurso);
		
		//Asigna el path del recurso
		setPathDocumento(recurso.getRootPath()) ;
		
		//Asigna el id del recurso
		setId(recurso.getResourceId().getStringValue()) ;
		
		//Asigna el id de estructura del recurso
		setStructureId(recurso.getStructureId().getStringValue()) ;
		
		//Lee los atributos del recurso
		CmsXmlContent xmlContentRecurso =  CmsXmlContentFactory.unmarshal(cmsObject, fileRecurso);
		List<String> keys =  xmlContentRecurso.getNames(idioma);
		
		I_CmsXmlContentValue atributo, subAtributo;
		Anexo anexo;
		Enmienda enmienda;
		String titulo ="",enlace="", valorEnmienda ="",fechaEnmienda="",nombre, valor;
		for(String key :keys){
			atributo = xmlContentRecurso.getValue(key,idioma);

			if(atributo != null) {
				nombre = atributo.getPath();
				if(nombre.contains("ConfiguracionEspecifica")) {
					continue;
				}else if(nombre.contains("Anexo")) {
					if(!nombre.contains("/")) {
						List<I_CmsXmlContentValue> listaSubvalues =  xmlContentRecurso.getAllSimpleSubValues(atributo);
						
						for(I_CmsXmlContentValue subvalor: listaSubvalues){
							nombre = subvalor.getPath();
							
							subAtributo = xmlContentRecurso.getValue(nombre, idioma);
							valor = subAtributo.getStringValue(cmsObject);
							if(nombre.contains("Titulo")) {
								titulo = valor;
							}
							if(nombre.contains("Enlace")) {
								enlace = valor;
							}
						}
						anexo = new Anexo(titulo,enlace);
						anexos.add(anexo);
					}
				}else if(nombre.contains("Enmienda")) {
					if(!nombre.contains("/")) {
					
						List<I_CmsXmlContentValue> listaSubvalues =  xmlContentRecurso.getAllSimpleSubValues(atributo);
						
						for(I_CmsXmlContentValue subvalor: listaSubvalues){
							nombre = subvalor.getPath();
							
							subAtributo = xmlContentRecurso.getValue(nombre, idioma);
							valor = subAtributo.getStringValue(cmsObject);
							if(nombre.contains("Valor")) {
								valorEnmienda = valor;
							}
							if(nombre.contains("Fecha")) {
								fechaEnmienda = valor;
							}
						}
						enmienda = new Enmienda(valorEnmienda,fechaEnmienda);
						enmiendas.add(enmienda);
					}
				}else { 
					if(getNombreKey(atributo.getPath()).contains("Fecha") && !getNombreKey(atributo.getPath()).contains("Date")){
						darFormatoFechaNueva(atributo, cmsObject, xmlContentRecurso, fileRecurso, recurso, idioma);
					}else if(getNombreKey(atributo.getPath()).contains("Date")) {
						modificarFecha(atributo, cmsObject, xmlContentRecurso, fileRecurso, recurso, idioma);
					}else{
						datos.put(getNombreKey(atributo.getPath()), atributo.getStringValue(cmsObject));
					}
				}
			}
		}
	}
	
	public void modificarFecha(I_CmsXmlContentValue atributo1, CmsObject cmsObject, CmsXmlContent xmlContentRecurso, CmsFile fileRecurso, CmsResource recurso, Locale idioma) throws Exception{
		String nombreAtributo = getNombreKey(atributo1.getPath());
		nombreAtributo= nombreAtributo.substring(0, nombreAtributo.length() - 5);
		I_CmsXmlContentValue atributo2 = xmlContentRecurso.getValue(nombreAtributo,idioma);
		String fecha1 =pasarLongADate(atributo1.getStringValue(cmsObject));
		String fecha2 = atributo2.getStringValue(cmsObject);
		if(fecha1 !=null && fecha2 !=null && !fecha1.equals(fecha2)) {
			atributo2.setStringValue(cmsObject, fecha1);
			datos.put(getNombreKey(atributo2.getPath()), fecha1);
			publicarAtributo(fileRecurso, xmlContentRecurso, cmsObject, recurso);
		}
	}
	
	public void convertirFechaALong(String fecha, I_CmsXmlContentValue atributo, CmsObject cmsObject, CmsFile fileRecurso, CmsXmlContent xmlContentRecurso, CmsResource recurso) {
		try {
			long miliS = Long.parseLong(fecha);
			Date date = new Date();
			date.setTime(miliS);
			fecha = new SimpleDateFormat("dd/MM/yyyy").format(date);
			atributo.setStringValue(cmsObject, Long.toString(date.getTime()));
			datos.put(getNombreKey(atributo.getPath()), fecha);
			publicarAtributo(fileRecurso, xmlContentRecurso, cmsObject, recurso);
		}catch(Exception ex) {
			
		}
	}
	
	public boolean esConvertibleALong(String fecha){
		try{
			Long.parseLong(fecha);
			return true;
		}catch(Exception ex){
			return false;
		}
	}
	
	public String pasarLongADate(String fecha) {
		try {
			long miliS = Long.parseLong(fecha);
			Date date = new Date();
			date.setTime(miliS);
			fecha =new SimpleDateFormat("dd/MM/yyyy").format(date);
		}catch(Exception e){
		}
		return fecha;
	}
	
	public void darFormatoFechaNueva(I_CmsXmlContentValue atributo, CmsObject cmsObject, CmsXmlContent xmlContentRecurso, CmsFile fileRecurso, CmsResource recurso, Locale idioma) throws Exception{
		String nombreAtributo = getNombreKey(atributo.getPath()) + "_Date";
		I_CmsXmlContentValue atributo2 = xmlContentRecurso.getValue(nombreAtributo,idioma);
		datos.put(getNombreKey(atributo.getPath()), atributo.getStringValue(cmsObject));
		String fecha = atributo.getStringValue(cmsObject);
		datos.put(nombreAtributo, fecha);
		SimpleDateFormat parseFormat = new SimpleDateFormat("dd/MM/yyyy");
		Date date = parseFormat.parse(fecha);
		atributo2 = xmlContentRecurso.addValue(cmsObject,nombreAtributo,idioma,0);
		atributo2.setStringValue(cmsObject, Long.toString(date.getTime()));
		publicarAtributo(fileRecurso, xmlContentRecurso, cmsObject, recurso);	
	}
	
	public void publicarAtributo(CmsFile fileRecurso, CmsXmlContent xmlContentRecurso,  CmsObject cmsObject, CmsResource recurso) throws Exception{
		fileRecurso.setContents(xmlContentRecurso.marshal());
		cmsObject.lockResourceTemporary(fileRecurso);
		cmsObject.writeFile(fileRecurso);
		String mySite = cmsObject.getRequestContext().getSiteRoot();
		cmsObject.getRequestContext().setSiteRoot("/");
		cmsObject.unlockResource(recurso.getRootPath());
		OpenCms.getPublishManager().publishResource(cmsObject, recurso.getRootPath());
		cmsObject.getRequestContext().setSiteRoot(mySite);
	}

}
