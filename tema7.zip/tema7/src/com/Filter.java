package com;
import java.util.ServiceLoader;
import es.Helloworld;
import ex.Cucable;

public class Filter {
	public static void main(String[] args) {
		System.out.println("Moduloss");
		Helloworld.holaMundo();
		
		int n = ServiceLoader.load(Cucable.class).findFirst().get().contador();
		
		System.out.println(n);
	}

}
