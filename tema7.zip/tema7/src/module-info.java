/**
 * 
 */
/**
 * @author parjrui
 *
 */
module tema7 {
	requires tema72;
	uses ex.Cucable;
}