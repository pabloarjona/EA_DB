/**
 * 
 */
/**
 * @author parjrui
 *
 */
module normasTecnicas {
	requires opencms;
}