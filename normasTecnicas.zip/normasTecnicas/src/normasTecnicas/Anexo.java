package normasTecnicas;

public class Anexo{
	private String titulo;
	private String enlace;
	
	public String get(String nombreAtributo){
		String valor = "";
		if(nombreAtributo.equals("Titulo")){
			valor = titulo;
		}else if(nombreAtributo.equals("Enlace")){
			valor =enlace;
		}
		return valor;
	}
	
	public Anexo() {
		super();
	}

	public Anexo(String nombre, String link) {
		this.titulo = nombre;
		this.enlace = link;
	}
}
