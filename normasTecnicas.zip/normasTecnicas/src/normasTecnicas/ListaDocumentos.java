package normasTecnicas;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.SortedSet;
import java.util.TreeSet;

import org.opencms.file.CmsFile;
import org.opencms.file.CmsObject;
import org.opencms.file.CmsResource;
import org.opencms.jsp.CmsJspTagContentLoad;
import org.opencms.jsp.CmsJspXmlContentBean;
import org.opencms.xml.content.CmsXmlContent;
import org.opencms.xml.content.CmsXmlContentFactory;
import org.opencms.xml.types.I_CmsXmlContentValue;

public class ListaDocumentos 
{
	CmsJspXmlContentBean xcbContent;
	CmsObject cmsObject;
	List<DocumentoOpencms> listaDocumentos;
	
	public List<DocumentoOpencms> getListaDocumentos() {
		return listaDocumentos;
	}

	public void setListaDocumentos(List<DocumentoOpencms> listaDocumentos) {
		this.listaDocumentos = listaDocumentos;
	}
	
	
	public ListaDocumentos(CmsJspXmlContentBean xcbContent, String tipoDocumento) throws Exception {
		this.xcbContent = xcbContent;
		this.cmsObject = xcbContent.getCmsObject();
		try{
			CmsJspTagContentLoad contentLoad = (CmsJspTagContentLoad) xcbContent.contentload(
					"allInFolder",
					"/.content/"+ tipoDocumento+"/.xml|"+ tipoDocumento,
					false);
			List<CmsResource> listaDocumentosRecursos = contentLoad.getCollectorResult();
			listaDocumentos = new ArrayList<>();
			for(CmsResource recurso: listaDocumentosRecursos){
				DocumentoOpencms documentoOpencms = new DocumentoOpencms(recurso,cmsObject);
				listaDocumentos.add(documentoOpencms);
			}
		}catch(Exception e){
			listaDocumentos = new ArrayList<>();
			throw e;
		}
	}
	
	public ListaDocumentos(CmsJspXmlContentBean xcbContent, String tipoDocumento, String unidad) throws Exception {
		this.xcbContent = xcbContent;
		this.cmsObject = xcbContent.getCmsObject();
		try{
			CmsJspTagContentLoad contentLoad = (CmsJspTagContentLoad) xcbContent.contentload(
					"allInFolder",
					"/.content/"+ tipoDocumento+"/.xml|"+ tipoDocumento,
					false);
			List<CmsResource> listaDocumentosRecursos = contentLoad.getCollectorResult();
			listaDocumentos = new ArrayList<>();
			for(CmsResource recurso: listaDocumentosRecursos){
				CmsFile fileRecurso = cmsObject.readFile(recurso);
				CmsXmlContent xmlContentRecurso =  CmsXmlContentFactory.unmarshal(cmsObject, fileRecurso);
				I_CmsXmlContentValue atributo = xmlContentRecurso.getValue("Unidad", cmsObject.getRequestContext().getLocale());
				DocumentoOpencms documentoOpencms = null;
				if(atributo !=null) {
					if(atributo.getStringValue(cmsObject).equals(unidad)) {
						documentoOpencms = new DocumentoOpencms(recurso,cmsObject);
						listaDocumentos.add(documentoOpencms);
					}
				}else {
					documentoOpencms = new DocumentoOpencms(recurso,cmsObject);
					listaDocumentos.add(documentoOpencms);
				}
				
			}
		}catch(Exception e){
			listaDocumentos = new ArrayList<>();
			throw e;
		}
	}
	
	public ListaDocumentos(List<DocumentoOpencms> listaDocumentos ){
		this.listaDocumentos = listaDocumentos;	
	}
	
	public boolean tieneCampo(String campo){
		for(DocumentoOpencms documento: listaDocumentos) {
			return documento.existeCampo(campo);
		}
		return false;
	}
	private boolean comprobadoIsDate = false;
	public boolean isDate = false;
	private boolean isDate(String nombreAtributo) {
		if(!comprobadoIsDate) {
			String valorAtributo ;
			for(DocumentoOpencms documento: listaDocumentos) {
				valorAtributo = documento.get(nombreAtributo);
				if(valorAtributo != null && !valorAtributo.isEmpty()) {
					try {
						new SimpleDateFormat("dd/MM/yyyy").parse(valorAtributo);
					}catch (ParseException e) {
						isDate = false;
						return false;
					}
				}
			}
			isDate = true;
		}
		return isDate;
	}
	private void ordenarString(List<DocumentoOpencms> listaDatos, String nombreAtributo, boolean ordenacionDescendente) {
	
		Collections.sort(listaDatos, new Comparator<DocumentoOpencms>() {
			   public int compare(DocumentoOpencms obj1, DocumentoOpencms obj2) {
				   if(ordenacionDescendente)
					   return obj2.get(nombreAtributo).compareTo(obj1.get(nombreAtributo));
				   else
					   return obj1.get(nombreAtributo).compareTo(obj2.get(nombreAtributo));
			   }
			});
	}
	
	private void ordenarDate(List<DocumentoOpencms> listaDatos, String nombreAtributo, boolean ordenacionDescendente) {
		Collections.sort(listaDatos, new Comparator<DocumentoOpencms>() {
			   public int compare(DocumentoOpencms documento1, DocumentoOpencms documento2) {
				   String valorAtributo1 = documento1.get(nombreAtributo);
				   Date fecha1 = null;
				   String valorAtributo2 = documento2.get(nombreAtributo);
				   Date fecha2 = null;
					try {
						fecha1 = new SimpleDateFormat("dd/MM/yyyy").parse(valorAtributo1);
						fecha2 = new SimpleDateFormat("dd/MM/yyyy").parse(valorAtributo2);
						if(ordenacionDescendente)
							return fecha2.compareTo(fecha1);
						else
							return fecha1.compareTo(fecha2);
					} catch (ParseException e1) {
						// TODO Auto-generated catch block
						//e1.printStackTrace();
						if(ordenacionDescendente)
							return valorAtributo2.compareTo(valorAtributo1);
						else
							return valorAtributo1.compareTo(valorAtributo2);
					}
			   }
			});
	}
	
	
	/**
	 * Este método agrupa los documentos por el primer atributo y los ordena por el segundo.
	 * Devuelve un Hashmap con los distintos valores del atributo asociados a una lista de documentos
	 * que contienen el valor correspondiente. 
	 * @param nombreAtributo
	 * @param nombreAtributoOrdenacion
	 * @return
	 * @throws ParseException
	 */
	public HashMap<String, List<DocumentoOpencms>> extraerYOrdenarPor(String nombreAtributo, String nombreAtributoOrdenacion) throws ParseException{
		return extraerYOrdenarPor(nombreAtributo, nombreAtributoOrdenacion, false,false);
	}
	
	/**
	 * Este método agrupa los documentos por el primer atributo y los ordena por el segundo.
	 * Devuelve un Hashmap con los distintos valores del atributo asociados a una lista de documentos
	 * que contienen el valor correspondiente. 
	 * @param nombreAtributo
	 * @param nombreAtributoOrdenacion
	 * @param ordenacionDescendente. Se marcará a true si el orden es descendente.
	 * @return
	 * @throws ParseException
	 */
	public HashMap<String, List<DocumentoOpencms>> extraerYOrdenarPor(String nombreAtributo, String nombreAtributoOrdenacion, boolean ordenacionDescendenteAgrupacion, boolean ordenacionDescendenteOrdenacion) throws ParseException{
		HashMap<String, List<DocumentoOpencms>> listaValoresOrdenados = extraer(nombreAtributo, false);
		
		return ordenar(nombreAtributoOrdenacion, ordenacionDescendenteAgrupacion, ordenacionDescendenteOrdenacion,
				listaValoresOrdenados);
	}
	
	
	/**
	 * Este método agrupa los documentos por el primer atributo y los ordena por el segundo.
	 * Devuelve un Hashmap con los distintos valores del atributo asociados a una lista de documentos
	 * que contienen el valor correspondiente. 
	 * @param nombreAtributo
	 * @param nombreAtributoOrdenacion
	 * @param ordenacionDescendente. Se marcará a true si el orden es descendente.
	 * @return
	 * @throws ParseException
	 */
	public HashMap<String, List<DocumentoOpencms>> extraerYOrdenarPorConNumInstruccion(String nombreAtributo, String nombreAtributoOrdenacion, boolean ordenacionDescendenteAgrupacion, boolean ordenacionDescendenteOrdenacion) throws ParseException{
		HashMap<String, List<DocumentoOpencms>> listaValoresOrdenados = extraer(nombreAtributo,true);
		
		return ordenar(nombreAtributoOrdenacion, ordenacionDescendenteAgrupacion, ordenacionDescendenteOrdenacion,
				listaValoresOrdenados);
	}

	/**
	 * @param nombreAtributo
	 * @return
	 */
	 
	private HashMap<String, List<DocumentoOpencms>> extraer(String nombreAtributo,boolean conNumInstruccion) {
		HashMap<String, List<DocumentoOpencms>> listaValoresOrdenados = new HashMap<String, List<DocumentoOpencms>>();
		String valorAtributo = "";
		boolean encontrado;
		if(!isDate(nombreAtributo)) {
			//Si el atributo es un string agrupo por los valores del atributo
			for(DocumentoOpencms documento: listaDocumentos) {
				if(conNumInstruccion) {
					valorAtributo = "";
					String numInstruccion = documento.get("N_Instruccion_General");
					numInstruccion = numInstruccion.substring(0, numInstruccion.indexOf('-'));
					valorAtributo =  numInstruccion+" - "+ documento.get(nombreAtributo);
				}
				else {
				
					valorAtributo = documento.get(nombreAtributo);
				}
				if(valorAtributo.equals("")){valorAtributo = "Sin datos";}
				encontrado = false;
				for(String valorComparar: listaValoresOrdenados.keySet()) {
					if(valorComparar.equals(valorAtributo)) {
						encontrado = true;
						listaValoresOrdenados.get(valorAtributo).add(documento);
					}
				}
				if(!encontrado) {
					List<DocumentoOpencms> listaDatos = new ArrayList<DocumentoOpencms>();
					listaDatos.add(documento);
					listaValoresOrdenados.put(valorAtributo, listaDatos);
				}			
			}
			
		}else {
			//Si el atributo es una fecha devolvemos los datos agrupados por años
			for(DocumentoOpencms documento: listaDocumentos) {
				valorAtributo = documento.get(nombreAtributo);
				String anio = "";
				try{
					Date fecha = new SimpleDateFormat("dd/MM/yyyy").parse(valorAtributo);
					anio = new SimpleDateFormat("yyyy").format(fecha);
				}catch(ParseException e){}
				encontrado = false;
				for(String valorComparar: listaValoresOrdenados.keySet()) {
					if(valorComparar.equals(anio)) {
						encontrado = true;
						listaValoresOrdenados.get(anio).add(documento);
					}
				}
				if(!encontrado) {
					List<DocumentoOpencms> listaDatos = new ArrayList<DocumentoOpencms>();
					listaDatos.add(documento);
					listaValoresOrdenados.put(anio, listaDatos);
				}			
			}
		}
		return listaValoresOrdenados;
	}

	/**
	 * @param nombreAtributoOrdenacion
	 * @param ordenacionDescendenteAgrupacion
	 * @param ordenacionDescendenteOrdenacion
	 * @param listaValoresOrdenados
	 * @return
	 */
	private HashMap<String, List<DocumentoOpencms>> ordenar(String nombreAtributoOrdenacion,
			boolean ordenacionDescendenteAgrupacion, boolean ordenacionDescendenteOrdenacion,
			HashMap<String, List<DocumentoOpencms>> listaValoresOrdenados) {
		LinkedHashMap<String, List<DocumentoOpencms>> listaOrdenada = new LinkedHashMap<String, List<DocumentoOpencms>>();
		for(String key: listaValoresOrdenados.keySet()) {
			List<DocumentoOpencms> listaDatos = listaValoresOrdenados.get(key);
			if(isDate(nombreAtributoOrdenacion)) {
				ordenarDate(listaDatos, nombreAtributoOrdenacion,ordenacionDescendenteOrdenacion);
			}
			else {
				ordenarString(listaDatos, nombreAtributoOrdenacion,ordenacionDescendenteOrdenacion);
			}
		}
		if(ordenacionDescendenteAgrupacion) {
			ArrayList<String> listaLlaves = new ArrayList<String>(listaValoresOrdenados.keySet());
			Collections.sort(listaLlaves, Collections.reverseOrder());
			for(String llave: listaLlaves) {
				listaOrdenada.put(llave, listaValoresOrdenados.get(llave));
			}
		}else {
				
			SortedSet<String> llaves = new TreeSet<>(listaValoresOrdenados.keySet());
			for(String llave: llaves) {
				listaOrdenada.put(llave, listaValoresOrdenados.get(llave));
			}
		}
		return listaOrdenada;
	}


	/**
	 * Devuelve un HashMap de elementos ordenados por el atributo que se ha insertado
	 * Si es una fecha devuelve un HashMap por años ordenados
	 * Si es un string devuelve los datos ordenados y agrupados por los datos del atributo  
	 * @param nombreAtributo
	 * @return
	 * @throws ParseException 
	 */
	public HashMap<String, List<DocumentoOpencms>> extraerPor(String nombreAtributo) throws ParseException{
		return extraerYOrdenarPor(nombreAtributo, nombreAtributo);
	}
	/**
	 * Devuelve un HashMap de elementos ordenados por el atributo que se ha insertado
	 * Si es una fecha devuelve un HashMap por años ordenados
	 * Si es un string devuelve los datos ordenados y agrupados por los datos del atributo  
	 * @param nombreAtributo
	 * @param ordenacionDescendente. Se marcará a true si el orden es descendente.
	 * @return
	 * @throws ParseException 
	 */
	public HashMap<String, List<DocumentoOpencms>> extraerPor(String nombreAtributo, boolean ordenacionDescendente) throws ParseException{
		return extraerYOrdenarPor(nombreAtributo, nombreAtributo, ordenacionDescendente,ordenacionDescendente);
	}
}

