package normasTecnicas;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;

import org.opencms.file.CmsFile;
import org.opencms.file.CmsObject;
import org.opencms.file.CmsResource;
import org.opencms.i18n.CmsResourceBundleLoader;
import org.opencms.main.CmsException;
import org.opencms.main.OpenCms;
import org.opencms.xml.content.CmsXmlContent;
import org.opencms.xml.content.CmsXmlContentFactory;
import org.opencms.xml.types.I_CmsXmlContentValue;

public class DocumentoOpencms {
	private String id;
	private String structureId;
	private String pathDocumento;
	ArrayList<Anexo> anexos = new ArrayList<Anexo>();
	ArrayList<Enmienda> enmiendas = new ArrayList<Enmienda>();
	HashMap<String, String> datos = new HashMap<String, String>();
	private ResourceBundle bundleKeys = null;
	
	public ArrayList<Anexo> getAnexos() {
		return anexos;
	}
	public void setAnexos(ArrayList<Anexo> anexos) {
		this.anexos = anexos;
	}

	public HashMap<String, String> getDatos() {
		return datos;
	}

	public void setDatos(HashMap<String, String> datos) {
		this.datos = datos;
	}
	
	public String get(String atributo) {
		String dato = "";
		String valor = datos.get(atributo); 
		if(valor != null) {
			dato = valor;
		}
		return dato;
	}
	

	public String getAtributoSinComillas(String atributo) {
		
		String valor = get(atributo);
		int indice = valor.indexOf('"');
		while(indice ==0) {
			valor = valor.substring(indice+1);
			indice = valor.indexOf('"');
		}
		indice = valor.lastIndexOf('"');
		while(valor.length() >0 && indice ==valor.length()-1) {
			valor = valor.substring(0,indice-1);
			indice = valor.lastIndexOf('"');
		}
		return valor;
	}
	public boolean existeCampo(String nombreCampo){
		for(String key: datos.keySet()){
			if(key.equals(nombreCampo)){
				return true;
			}
		}
		return false;
	}
	public String getTextoKey(String key){
		
		String keyModificada = "";
		try {
			keyModificada = bundleKeys.getString(key);
		}catch(Exception e) {
			keyModificada = key;
		}
		return keyModificada;
	}
	public String getStructureId() {
		return structureId;
	}
	public void setStructureId(String structureId) {
		this.structureId = structureId;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	
	public String getPathDocumento() {
		return pathDocumento;
	}

	public void setPathDocumento(String pathDocumento) {
		this.pathDocumento = pathDocumento;
	}
	public boolean isId(String key){
		if(key.contains("_ID") || key.contains("ID_")){
			return true;
		}
		return false;
	}
	public boolean isRazonDerogacion(String key){
		if(key.contains("Razon_de_la_derogacion")){
			return true;
		}
		return false;
	}
	public boolean isKey(String keyAComparar, String key){
		if(key.contains(keyAComparar)){
			return true;
		}
		return false;
	}
	public boolean tieneValor(String key){
		String valor = datos.get(key);
		if(valor !=null && !valor.equals("")){
			return true;
		}
		return false;
	}
	public String getValorTitulo(int longitud){
		String titulo = "";
		if(get("Titulo") != null && !get("Titulo").isEmpty()){
			titulo = getCampoRecortado("Titulo",longitud);
		}else if(get("Asunto") != null && !get("Asunto").isEmpty()){
			titulo = getCampoRecortado("Asunto",longitud);
		
		}else if(get("Subject") != null && !get("Subject").isEmpty()){
			titulo = getCampoRecortado("Subject",longitud);
		}
		return titulo;
	}
	public String getCampoRecortado(String nombreCampo, int longitud) {
		String valorCampo = this.get(nombreCampo).trim();
		String palabraFinal = "";
		if(valorCampo.length()< longitud) {
			palabraFinal = valorCampo;
			
		}
		else {
			String[] palabras = valorCampo.split(" ");		
			String texto="";
			int i=0;
			while(texto.length()<longitud-4 && i<palabras.length) {
				palabraFinal = texto;
				texto += " " + palabras[i];
				i++;
			}
			palabraFinal += " ...";			
		}
		return palabraFinal;
	}
	
	protected String getNombreKey(String nombrePathKey) {
		String nombreKey;
		int indiceInicio = 0;
		if(nombrePathKey.lastIndexOf("/") != -1)
		{
			indiceInicio = nombrePathKey.lastIndexOf("/");
		}
		int indiceFin = nombrePathKey.lastIndexOf("[");
		nombreKey = nombrePathKey.substring(indiceInicio, indiceFin);
		
		return nombreKey;
	}
	public DocumentoOpencms(CmsResource recurso, CmsObject cmsObject) throws CmsException {
		//Recogemos el idioma
		Locale idioma = cmsObject.getRequestContext().getLocale();
		
		//Recoge el bundle de las keys
		bundleKeys =CmsResourceBundleLoader.getBundle("ea.keys.documentos", idioma);
		
		CmsFile fileRecurso = cmsObject.readFile(recurso);
		
		//Asigna el path del recurso
		setPathDocumento(recurso.getRootPath()) ;
		
		//Asigna el id del recurso
		setId(recurso.getResourceId().getStringValue()) ;
		
		//Asigna el id de estructura del recurso
		setStructureId(recurso.getStructureId().getStringValue()) ;
		
		//Lee los atributos del recurso
		CmsXmlContent xmlContentRecurso =  CmsXmlContentFactory.unmarshal(cmsObject, fileRecurso);
		List<String> keys =  xmlContentRecurso.getNames(idioma);
		
		I_CmsXmlContentValue atributo, subAtributo;
		Anexo anexo;
		Enmienda enmienda;
		String titulo ="",enlace="", valorEnmienda ="",fechaEnmienda="",nombre, valor;
		for(String key :keys){
			atributo = xmlContentRecurso.getValue(key,idioma);

			if(atributo != null) {
				nombre = atributo.getPath();
				if(nombre.contains("ConfiguracionEspecifica")) {
					continue;
				}else if(nombre.contains("Anexo")) {
					if(!nombre.contains("/")) {
				
					
						List<I_CmsXmlContentValue> listaSubvalues =  xmlContentRecurso.getAllSimpleSubValues(atributo);
						
						for(I_CmsXmlContentValue subvalor: listaSubvalues){
							nombre = subvalor.getPath();
							
							subAtributo = xmlContentRecurso.getValue(nombre, idioma);
							valor = subAtributo.getStringValue(cmsObject);
							if(nombre.contains("Titulo")) {
								titulo = valor;
							}
							if(nombre.contains("Enlace")) {
								enlace = valor;
							}
						}
						anexo = new Anexo(titulo,enlace);
						anexos.add(anexo);
					}
				}else if(nombre.contains("Enmienda")) {
					if(!nombre.contains("/")) {
					
						List<I_CmsXmlContentValue> listaSubvalues =  xmlContentRecurso.getAllSimpleSubValues(atributo);
						
						for(I_CmsXmlContentValue subvalor: listaSubvalues){
							nombre = subvalor.getPath();
							
							subAtributo = xmlContentRecurso.getValue(nombre, idioma);
							valor = subAtributo.getStringValue(cmsObject);
							if(nombre.contains("Valor")) {
								valorEnmienda = valor;
							}
							if(nombre.contains("Fecha")) {
								fechaEnmienda = valor;
							}
						}
						enmienda = new Enmienda(valorEnmienda,fechaEnmienda);
						enmiendas.add(enmienda);
					}
				}else { 
					if(getNombreKey(atributo.getPath()).contains("Fecha") && !getNombreKey(atributo.getPath()).contains("Date")){
						darFormatoFechaNueva(atributo, cmsObject, xmlContentRecurso, fileRecurso, recurso, idioma);
					}else if(getNombreKey(atributo.getPath()).contains("Date")) {
						modificarFecha(atributo, cmsObject, xmlContentRecurso, fileRecurso, recurso, idioma);
					}else{
						datos.put(getNombreKey(atributo.getPath()), atributo.getStringValue(cmsObject));
					}
				}
			}
		}
	}
	
	public void modificarFecha(I_CmsXmlContentValue atributo1, CmsObject cmsObject, CmsXmlContent xmlContentRecurso, CmsFile fileRecurso, CmsResource recurso, Locale idioma) {
		try {
			String nombreAtributo = getNombreKey(atributo1.getPath());
			nombreAtributo= nombreAtributo.substring(0, nombreAtributo.length() - 5);
			I_CmsXmlContentValue atributo2 = xmlContentRecurso.getValue(nombreAtributo,idioma);
			String fecha1 =pasarLongADate(atributo1.getStringValue(cmsObject));
			String fecha2 = atributo2.getStringValue(cmsObject);
			if(fecha1 !=null && fecha2 !=null && !fecha1.equals(fecha2)) {
				atributo2.setStringValue(cmsObject, fecha1);
				datos.put(getNombreKey(atributo2.getPath()), fecha1);
				publicarAtributo(fileRecurso, xmlContentRecurso, cmsObject, recurso);
			}
		}catch(Exception e) {
			
		}
	}
	
	public void darFormatoFechaNueva(I_CmsXmlContentValue atributo, CmsObject cmsObject, CmsXmlContent xmlContentRecurso, CmsFile fileRecurso, CmsResource recurso, Locale idioma) {
		try {
			String nombreAtributo = getNombreKey(atributo.getPath()) + "_Date";
			I_CmsXmlContentValue atributo2 = xmlContentRecurso.getValue(nombreAtributo,idioma);
			datos.put(getNombreKey(atributo.getPath()), atributo.getStringValue(cmsObject));
			String fecha = atributo.getStringValue(cmsObject);
			datos.put(nombreAtributo, fecha);
			SimpleDateFormat parseFormat = new SimpleDateFormat("dd/MM/yyyy");
			Date date = parseFormat.parse(fecha);
			atributo2 = xmlContentRecurso.addValue(cmsObject,nombreAtributo,idioma,0);
			atributo2.setStringValue(cmsObject, Long.toString(date.getTime()));
			publicarAtributo(fileRecurso, xmlContentRecurso, cmsObject, recurso);
		}catch(Exception e){
		
		}
	}
	
	
	public String pasarLongADate(String fecha) {
		try {
			long miliS = Long.parseLong(fecha);
			Date date = new Date();
			date.setTime(miliS);
			fecha =new SimpleDateFormat("dd/MM/yyyy").format(date);
		}catch(Exception e){
		}
		return fecha;
	}
	
	public void publicarAtributo(CmsFile fileRecurso, CmsXmlContent xmlContentRecurso,  CmsObject cmsObject, CmsResource recurso) throws Exception{
		fileRecurso.setContents(xmlContentRecurso.marshal());
		cmsObject.lockResourceTemporary(fileRecurso);
		cmsObject.writeFile(fileRecurso);
		String mySite = cmsObject.getRequestContext().getSiteRoot();
		cmsObject.getRequestContext().setSiteRoot("/");
		cmsObject.unlockResource(recurso.getRootPath());
		OpenCms.getPublishManager().publishResource(cmsObject, recurso.getRootPath());
		cmsObject.getRequestContext().setSiteRoot(mySite);
	}
	
	/**
	 * Devuelve un string con el titulo de los ficheros anexos
	 * @return String con los nombres de los ficheros anexos
	 */
	String titulosAnexos="";
	public String getTitulosAnexos(){
		for (Anexo anexo: anexos){
			titulosAnexos += anexo.get("Titulo");
		}
		return titulosAnexos;
	}
	
	String titulosDocumentosAnexos="";
	
	/**
	 * Devuelve el titulo de los ficheros anexos
	 * @return Código html con los nombres de los ficheros anexos
	 */
	public String getTitulosDocumentosAnexos(){
		for (Anexo anexo: anexos){
			titulosDocumentosAnexos += "<p><li><a href='#'>"+anexo.get("Titulo")+"</a></li></p>";
			
		}
		return titulosDocumentosAnexos;
	}
	public String toString() {
		String espacio = "<br>           ";
		StringBuffer datos = new StringBuffer();
		datos.append("ID: "+this.id);
		datos.append(espacio);
		datos.append("Path: "+this.pathDocumento);
		datos.append(espacio);
		for(String key: this.datos.keySet()) {
		
			datos.append(key+ ": "+this.datos.get(key));
			datos.append(espacio);
		}
		return datos.toString();
	}
}
