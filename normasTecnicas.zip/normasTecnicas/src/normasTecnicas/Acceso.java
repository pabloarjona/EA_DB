package normasTecnicas;

import java.util.Enumeration;
import java.util.List;
import java.util.Locale;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

import org.opencms.file.CmsGroup;
import org.opencms.file.CmsObject;
import org.opencms.file.CmsUser;
import org.opencms.i18n.CmsResourceBundleLoader;
import org.opencms.jsp.CmsJspXmlContentBean;
import org.opencms.main.CmsException;
import org.opencms.main.OpenCms;
import org.opencms.security.CmsRole;

public class Acceso {
	CmsObject cmsObject;
	CmsJspXmlContentBean xcbContent;
	String tipoDocumento;
	CmsUser usuario;
	Locale idioma;
	/**
	 * Constructor
	 * @param xcbContent
	 * @param tipoDocumento
	 */
	public Acceso(CmsJspXmlContentBean xcbContent, String tipoDocumento)  {
		this.xcbContent = xcbContent;
		this.cmsObject = xcbContent.getCmsObject();
		this.tipoDocumento = tipoDocumento;
		usuario = cmsObject.getRequestContext().getCurrentUser();
		idioma = cmsObject.getRequestContext().getLocale();
	}
	/**
	 * Este método nos confirma si para ese tipo de Documento y para los grupos de la unidad 
	 * debe tener acceso.
	 * @param nombreBundle
	 * @param nombreUnidadOrganizativa
	 * @param tipoDocumento
	 * @return boolean
	 * @throws CmsException
	 */
	public boolean tienePermisoParaVisualizarEnUnidad(String nombreBundle, String nombreUnidadOrganizativa) throws CmsException {
		boolean existe = false;
			 
		List<CmsGroup>  grupos = null;
		List<CmsUser> usuariosGrupo = null;
		
		ResourceBundle bundleUnidadOrganizativa =null;
		try {
			bundleUnidadOrganizativa =CmsResourceBundleLoader.getBundle(nombreBundle, idioma);
		}catch (MissingResourceException e) {
			return false;
		}
		if(!bundleUnidadOrganizativa.containsKey(nombreUnidadOrganizativa)) {
			return false;
		}
		
		String unidadOrganizativa = bundleUnidadOrganizativa.getString(nombreUnidadOrganizativa);
		
		grupos = OpenCms.getOrgUnitManager().getGroups(cmsObject, unidadOrganizativa, false);
		for(CmsGroup grupo: grupos) {
			usuariosGrupo = cmsObject.getUsersOfGroup(grupo.getName());
			if(usuariosGrupo.contains(usuario)){
				for (Enumeration<String> keys = bundleUnidadOrganizativa.getKeys(); keys.hasMoreElements();) {
					String key =keys.nextElement();
					if(!key.equals(nombreUnidadOrganizativa)) {
						String unidadGrupo = bundleUnidadOrganizativa.getString(key);
						if(grupo.getName().contains(unidadGrupo) && tipoDocumento.contains(unidadGrupo)) {
							existe = true;
							break;
						}
					}
				}
			}
		}
		return existe;
	}
	
	/**
	 * Este método devuelve si el usuario que accede puede o no 
	 * dar de alta nuevos documentos para el tipo de documento 
	 * con que se ha iniciado el acceso 
	 * @return boolean
	 * @throws CmsException
	 */
	public boolean tienePermisoRealizarAltaDocumento() throws CmsException {
		boolean tienePermiso = false;
		
			
			if(OpenCms.getRoleManager().hasRole(cmsObject, usuario.getName(), CmsRole.ROOT_ADMIN)){
				//Si es ADMINiSTRADOR  tiene permiso
				tienePermiso = true;
			}else{
				//Comprobamos las distintas unidades organizativas y sus grupos
				
				//Unidad organizativa de Instrucciones Particulares
				String nombreBundle = "ea.grupo_instrucciones_particulares";
				String nombreUnidad = "Grupo-InstruccionesParticulares";
				tienePermiso = tienePermisoParaVisualizarEnUnidad(nombreBundle, nombreUnidad);
				
				//Unidad organizativa de Disposiciones Generales
				if(!tienePermiso) {
					nombreBundle = "ea.grupo_disposiciones_generales";
					nombreUnidad = "Grupo-DisposicionesGenerales";
					tienePermiso = tienePermisoParaVisualizarEnUnidad(nombreBundle, nombreUnidad);
				}
				
				//Unidad organizativa de Conceptos Empleo Operativo
				if(!tienePermiso) {
					nombreBundle = "ea.grupo_conceptos_empleo_operativo";
					nombreUnidad = "Grupo-ConceptoEmpleoOperativo";
					tienePermiso = tienePermisoParaVisualizarEnUnidad(nombreBundle, nombreUnidad);
				}
				
				//Unidad organizativa de N	ormas Tecnicas				
				if(!tienePermiso) {
					nombreBundle = "ea.grupo_normas_tecnicas";
					nombreUnidad = "Grupo-NormasTecnicas";
					tienePermiso = tienePermisoParaVisualizarEnUnidad(nombreBundle, nombreUnidad);
				}
			}
		return tienePermiso;
	}
}