/**
 * 
 */
/**
 * @author parjrui
 *
 */
module mainModuleProject2 {
	exports es;
	exports services;
	provides services.Service1 with services.Service1Impl;
}
