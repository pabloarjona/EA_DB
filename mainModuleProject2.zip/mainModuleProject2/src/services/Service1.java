package services;

public interface Service1 {

	Double contador();
}
