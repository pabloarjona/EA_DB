package services;

import java.util.Random;
import java.util.stream.DoubleStream;

public class Service1Impl implements Service1{

	@Override
	public Double contador() {
		// TODO Auto-generated method stub
		var r = new Random();
		DoubleStream.generate(r::nextDouble).limit(100).forEach(System.out::print);
		return Double.parseDouble(r.toString());
	}

}