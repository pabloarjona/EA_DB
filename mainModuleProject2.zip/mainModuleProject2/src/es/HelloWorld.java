package es;

public class HelloWorld {

	public static void holaMundo() {
		System.out.println("Main de la clase hola mundo.");
	}
}
