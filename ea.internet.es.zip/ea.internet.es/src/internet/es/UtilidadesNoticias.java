package internet.es;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

import org.opencms.db.CmsResourceState;
import org.opencms.file.CmsFile;
import org.opencms.file.CmsObject;
import org.opencms.file.CmsResource;
import org.opencms.main.CmsException;
import org.opencms.main.OpenCms;
import org.opencms.xml.CmsXmlException;
import org.opencms.xml.content.CmsXmlContent;
import org.opencms.xml.content.CmsXmlContentFactory;
import org.opencms.xml.types.CmsXmlVfsFileValue;
import org.opencms.xml.types.I_CmsXmlContentValue;

public class UtilidadesNoticias {
	
	private CmsObject cmsObject;
	CmsXmlContent xmlContentOrigen;
	CmsXmlContent xmlContentDestino;
	HashMap<String, String> valoresACambiar;
	Locale locale;
	CmsResource recursoComponenteACambiar;
	String pathRecurso;
	
	public UtilidadesNoticias(CmsObject cmsObject) {
		super();
		this.cmsObject = cmsObject;
		locale = cmsObject.getRequestContext().getLocale();
	}

	public CmsXmlContent getIndex() throws CmsException {
		String path = cmsObject.getRequestContext().getUri();
		CmsResource index = cmsObject.readResource(path);
		CmsFile fileIndex = cmsObject.readFile(index);
		CmsXmlContent xmlContentIndex = CmsXmlContentFactory.unmarshal(cmsObject, fileIndex);
		return xmlContentIndex;
	}
	
	
	public void cambiarAtributosEnIndex(String pathRecurso) throws Exception {
		this.pathRecurso = pathRecurso;
		this.recursoComponenteACambiar = getRecursoACambiar();
		
		if(recursoComponenteACambiar != null){
			CmsFile fileComponenteACambiar = cmsObject.readFile(recursoComponenteACambiar);
			CmsXmlContent xmlContent = CmsXmlContentFactory.unmarshal(cmsObject, fileComponenteACambiar);
			
			xmlContentOrigen = xmlContent;
			String fecha ="", titulo="";
			
			//Recojo los valores a cambiar
			String key = "Fecha[1]";
			I_CmsXmlContentValue valorAtributo = xmlContentOrigen.getValue(key, locale);
			if(valorAtributo != null) {
				fecha = valorAtributo.getStringValue(cmsObject);
			}
			
			key = "Titulo[1]";
			valorAtributo = xmlContentOrigen.getValue(key, locale);
			if(valorAtributo != null) {
				titulo = valorAtributo.getStringValue(cmsObject);
			}
			
			//Asigno  los valores en el HashMap
			valoresACambiar = new HashMap<String, String>();
			valoresACambiar.put("Fecha[1]", fecha);
			valoresACambiar.put("Titulo[1]", titulo);
			
			//Cambio los valores
			cambiarValoresAtributosComponente(valoresACambiar, xmlContentDestino,"imagenPrincipal");
		}
		
	}

	/**
	 * @param queryString
	 * @return
	 * @throws CmsException
	 * @throws CmsXmlException
	 * @throws UnsupportedEncodingException
	 */
	private CmsResource getRecursoACambiar() throws CmsException, CmsXmlException, UnsupportedEncodingException {
		CmsResource recursoComponenteACambiar = getRecursoEnIndex("noticiaEA");
		if(recursoComponenteACambiar == null && !pathRecurso.equals("")) {
			String siteInicio = cmsObject.getRequestContext().getSiteRoot();
			cmsObject.getRequestContext().setSiteRoot("/");
			try {
				recursoComponenteACambiar = cmsObject.readResource(pathRecurso);
				cmsObject.getRequestContext().setSiteRoot(siteInicio);
			}catch (Exception e) {
				cmsObject.getRequestContext().setSiteRoot(siteInicio);
				throw e;
			}
		}
		return recursoComponenteACambiar;
	}
	public CmsResource getRecursoEnIndex(String tipoRecurso) throws CmsException {
		CmsResource recurso = null;
		xmlContentDestino = getIndex();
		Locale en = new Locale("en");
		I_CmsXmlContentValue elemento =null;
		List<I_CmsXmlContentValue> valores = xmlContentDestino.getValues(en);
		for(int j=1;j<valores.size();j++) {
			elemento = valores.get(j);
			if (elemento.getTypeName().equals(CmsXmlVfsFileValue.TYPE_NAME ) && elemento.getPath().contains("Uri")){
				if (elemento.getStringValue(cmsObject).contains(tipoRecurso)){
				recurso = cmsObject.readResource(elemento.getStringValue(cmsObject));
				}
			}
		}
		return recurso;
	}
	public String cambiarValoresAtributosComponente(HashMap<String, String> valoresACambiar, CmsXmlContent xmlContentDestino, String tipoElementoACambiar) throws Exception {
		this.valoresACambiar = valoresACambiar;
		this.xmlContentDestino = xmlContentDestino;
		CmsResource recursoComponenteACambiar = getRecursoEnIndex(tipoElementoACambiar);
		String estado="";
		if(recursoComponenteACambiar != null) {
			CmsFile fileComponenteACambiar = cmsObject.readFile(recursoComponenteACambiar);
			CmsXmlContent xmlContent = CmsXmlContentFactory.unmarshal(cmsObject, fileComponenteACambiar);
							
			I_CmsXmlContentValue valorAtributo = null;
				
			ArrayList<String> keys = new ArrayList<String>(valoresACambiar.keySet());
			
			for(String key:keys) {
				valorAtributo = xmlContent.getValue(key, locale);
				if(valorAtributo == null){valorAtributo = xmlContent.addValue(cmsObject,key,locale,0);}
				valorAtributo.setStringValue(cmsObject, valoresACambiar.get(key));
			}
			
			fileComponenteACambiar.setContents(xmlContent.marshal());
			cmsObject.lockResource(fileComponenteACambiar);
			//cmsObject.lockResourceTemporary(fileComponenteACambiar);
			cmsObject.writeFile(fileComponenteACambiar);
			estado = recursoComponenteACambiar.getState().toString();
			//Publicamos la noticia
			String site = cmsObject.getRequestContext().getSiteRoot();
			try {
				if(recursoComponenteACambiar.getState().equals(CmsResourceState.STATE_CHANGED)) {
					cmsObject.getRequestContext().setSiteRoot("/");
					cmsObject.unlockResource(fileComponenteACambiar);
					OpenCms.getPublishManager().publishResource(cmsObject, recursoComponenteACambiar.getRootPath());
					cmsObject.getRequestContext().setSiteRoot(site);
				}
			}catch (Exception e) {
				cmsObject.getRequestContext().setSiteRoot(site);
				estado= e.getMessage()+"Error exception en metodo cambiarValoresAtributosComponente";
				throw new OpenCmsException(estado);
			}
		}
		return estado;
	}
	
	public String cambiarValoresAtributosComponente2(HashMap<String, String> valoresACambiar, CmsXmlContent xmlContentDestino, String tipoElementoACambiar) throws Exception {
		this.valoresACambiar = valoresACambiar;
		this.xmlContentDestino = xmlContentDestino;
		CmsResource recursoComponenteACambiar = getRecursoEnIndex(tipoElementoACambiar);
		String estado="";
		if(recursoComponenteACambiar != null) {
			CmsFile fileComponenteACambiar = cmsObject.readFile(recursoComponenteACambiar);
			CmsXmlContent xmlContent = CmsXmlContentFactory.unmarshal(cmsObject, fileComponenteACambiar);
							
			I_CmsXmlContentValue valorAtributo = null;
				
			ArrayList<String> keys = new ArrayList<String>(valoresACambiar.keySet());
			
			for(String key:keys) {
				valorAtributo = xmlContent.getValue(key, locale);
				if(valorAtributo == null){valorAtributo = xmlContent.addValue(cmsObject,key,locale,0);}
				valorAtributo.setStringValue(cmsObject, valoresACambiar.get(key));
			}
			
			fileComponenteACambiar.setContents(xmlContent.marshal());
			cmsObject.lockResource(fileComponenteACambiar);
			//cmsObject.lockResourceTemporary(fileComponenteACambiar);
			cmsObject.writeFile(fileComponenteACambiar);
			estado = recursoComponenteACambiar.getState().toString();
			//Publicamos la noticia
			String site = cmsObject.getRequestContext().getSiteRoot();
			try {
				if(recursoComponenteACambiar.getState().equals(CmsResourceState.STATE_CHANGED)) {
					cmsObject.getRequestContext().setSiteRoot("/");
					cmsObject.unlockResource(fileComponenteACambiar);
					OpenCms.getPublishManager().publishResource(cmsObject, recursoComponenteACambiar.getRootPath());
					cmsObject.getRequestContext().setSiteRoot(site);
				}
			}catch (Exception e) {
				cmsObject.getRequestContext().setSiteRoot(site);
				estado= e.getMessage()+"Error exception en metodo cambiarValoresAtributosComponente";
				throw new OpenCmsException(estado);
			}
		}
		return estado;
	}
	
}
class OpenCmsException extends Exception { 
    public OpenCmsException(String errorMessage) {
        super(errorMessage);
    }
}
