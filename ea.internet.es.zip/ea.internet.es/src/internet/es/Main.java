package internet.es;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;

import org.opencms.file.CmsObject;
import org.opencms.flex.CmsFlexController;
import org.opencms.jsp.util.CmsJspStandardContextBean;
import org.opencms.xml.containerpage.CmsADESessionCache;

public class Main {
	public static void main(String[] args) throws Exception {
		//EjemploNoticias();
		//EjemploAeronaves();
	}
	
	private static void EjemploAeronaves() throws Exception {
		LinkedList<ImagenGaleria> imagenes = new LinkedList<>();
		Aeronave aeronave1 = new Aeronave("true", "Airbus A330 (T.24/TK.24. Lorem)", "presentacion", "Transporte", "true",
				"/.galleries/images/aeronaves/block.jpg", "Aeroanve", "5 estrellas", "4 estrellas", "4 estrellas", "4 estrellas",
				"El Beechcraft F-33 -Bonanza- (E.", "Su estructura ", "Lorem ", imagenes);
		Aeronave aeronave2 = new Aeronave("true", "Airbus A330", "presentacion2", "Otros", "false",
				"/.galleries/images/aeronaves/block.jpg", "Aeroanve", "4 estrellas", "4 estrellas", "4 estrellas", "4 estrellas",
				"El Beechcraft F-33 -Bonanza- (E-24) es un avión monoplano y monomotor, que contiene tres plazas ademas del piloto.", "Su estructura es metálica...", "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent sodales maximus nibh ac luctus. Donec nec venenatis purus, eget faucibus mi. Duis vel ipsum elit.", imagenes);
		ArrayList<Aeronave> lista= new ArrayList<>();
		lista.add(aeronave1); lista.add(aeronave2);
		ListaAeronaves listaAeronaves = new ListaAeronaves();
		listaAeronaves.setListaAeronaves(lista);
		for(Aeronave a : listaAeronaves.getListaAeronaves()) {
			System.out.println("AERONAVE: " +a.getNombre() );
			//System.out.println("DESCRIPCIÓN: Activo: "+ a.getActivo() +" Presentacion: "+a.getPresentacion() +" Tipo de aeronave: "+a.getTipoAeronave()+ " EsImagenDecorativa: "+a.getEsImagenDecorativa()+ " UrlImagen: "+ a.getUrlImagen() + " Texto alternativo: "+a.getTextoAlternativoImagen());
			//System.out.println("DATOS TÉCNICOS: VelocidadMáxima: "+a.getVelocidadMaxima()+ " VelocidadCrucero: "+a.getVelocidadCrucero()+ " Autonomía: "+a.getAutonomia()+" Techo máximo: "+a.getTechoMaximo());
			System.out.println("HISTORIA: Titulo historia: "+a.getTituloHistoria()+" Descripción historia: "+a.getDescripcionHistoria());
			//System.out.print("GALERIA: DescripciónGaleria: "+a.getDescripcionGaleria()+" Imagen galeria: ");
			for(ImagenGaleria iG : a.getImagenes()) {
				System.out.print(" Url imagen: "+ iG.getUrlImagen());
				System.out.print(" Texto alternativo: "+ iG.getTextoAlternativo());
			}
			System.out.println();
			System.out.println();
		}
		//EJEMPLO QUERY
		System.out.println("Ejemplo query...");
		String id="";
		String query = "resourceId=8d8b17e2-52c2-11ee-b874-005056bf91c5";
		if(query != null  && query.contains("resourceId")) {
			id= query.substring(query.indexOf('=')+1, query.length());
			System.out.println(id);
		}
	}

	private static void EjemploNoticias() throws Exception {
		Date date1, date2, date3, date4, date5, date6;
		Calendar calendar = Calendar.getInstance();
		calendar.set(2023, 1, 20);
		date1 = calendar.getTime();
		calendar.set(2022, 11, 20);
		date2 =calendar.getTime();
		calendar.set(2021, 10, 20);
		date3 =calendar.getTime();
		calendar.set(2023, 8, 12);		
		date4 =calendar.getTime();
		calendar.set(2022, 2, 20);
		date5 = calendar.getTime();
		calendar.set(2023, 2, 20);
		date6 = calendar.getTime();
		
		Noticia n1 = new Noticia("1","urlImagenPrincipal1", "altImagenPrincipal1", "titulo1","resumen1","texto1","20/02/2023", date1);
		Noticia n2 = new Noticia("2","urlImagenPrincipal2", "altImagenPrincipal2", "titulo2","resumen2","texto2","20/12/2022", date2);
		Noticia n3 = new Noticia("3","urlImagenPrincipal3", "altImagenPrincipal3", "titulo3","resumen3","texto3","20/11/2022", date3);
		Noticia n4 = new Noticia("4", "urlImagenPrincipal4", "altImagenPrincipal4", "titulo4","resumen4","texto4","20/08/2023", date4);
		Noticia n5 = new Noticia("5","urlImagenPrincipal5", "altImagenPrincipal5", "titulo5","resumen5","texto5","20/02/2022", date5);
		Noticia n6 = new Noticia("6","urlImagenPrincipal6", "altImagenPrincipal6", "titulo6","resumen6","texto6","20/02/2023", date6);
		
		ListaNoticias listaNoticias = new ListaNoticias();
		ArrayList<Noticia> noticias = new ArrayList<>();
		noticias.add(n1);
		noticias.add(n2);
		noticias.add(n3);
		noticias.add(n4);
		noticias.add(n5);
		noticias.add(n6);
		listaNoticias.setNoticias(noticias);
		System.out.println("LISTA SIN ORDENAR...");
		for (Noticia n : listaNoticias.noticiasTotal) {
			System.out.print(n.getUrlImagenComparte()+" ");
			System.out.print(n.getTitulo()+" ");
			System.out.println(n.getFecha());
		}
		System.out.println("LISTA ORDENADA...");
		for(Noticia n: listaNoticias.getRecentNoticias()) {
			System.out.print(n.getTitulo()+": ");
			System.out.println(n.getFecha());
		}
		
		//********NOTICIA 1*******************************//
		System.out.println("---------NOTICIA 1----------------");
		n1.setValorAtributo("RelacionAeronave[1]/Opcion", "Airbus A310 (T.22)");
		n1.setValorAtributo("RelacionPremio[1]/Opcion", "EA");
		n5.setValorAtributo("RelacionAeronave[1]/Opcion", "Airbus A310 (T.22)");
		n5.setValorAtributo("RelacionPremio[1]/Opcion", "EA");
		/*
		n1.setValorAtributo("RelacionUnidad[1]/Opcion", "Ala 46");
		n1.setValorAtributo("RelacionUnidad[1]/Opcion", "Ala 12");
		n1.setValorAtributo("RelacionAeronave[1]/Opcion", "Beechcraft 33C Bonanza (E.24)");
		n1.setValorAtributo("RelacionHistoria[1]/Opcion", "Aniversario");
		n1.setValorAtributo("RelacionHistoria[1]/Opcion", "Hito");
		n1.setValorAtributo("RelacionPremio[1]/Opcion", "Pintura Museo");
		n1.setValorAtributo("RelacionOperacion[1]/Opcion", "Ejercicio");
		n1.setValorAtributo("RelacionOperacion[1]/Opcion", "Misión nacional");
		n1.setValorAtributo("RelacionFormacion[1]/Opcion", "Intercambio");
		n1.setValorAtributo("RelacionPersonal[1]/Opcion", "Retiro");
		n1.setValorAtributo("RelacionPersonal[1]/Opcion", "Reconocimiento");
*/
		//********NOTICIA 2*******************************//
		System.out.println("---------NOTICIA 2----------------");
		n2.setValorAtributo("RelacionUnidad[1]/Opcion", "Ala 12");
		n2.setValorAtributo("RelacionUnidad[1]/Opcion", "Academia General del Aire - Base Aérea de San Javier");
		n2.setValorAtributo("RelacionAeronave[1]/Opcion", "Pilatus PC-21 (E.27)");
		n2.setValorAtributo("RelacionPremio[1]/Opcion", "Sostenibilidad");
		n2.setValorAtributo("RelacionPremio[1]/Opcion", "Vehículos");		
		//n2.setValorAtributo("RelacionPersonal[1]/Opcion", "Reconocimiento");
		
		//**************NOTICIA 3*******************************//
		System.out.println("---------NOTICIA 3----------------");
		n3.setValorAtributo("RelacionUnidad[1]/Opcion", "Ala 12");
		n3.setValorAtributo("RelacionUnidad[1]/Opcion", "Ala 46");
		n3.setValorAtributo("RelacionUnidad[1]/Opcion", "Ala asdas");

		//n5.setValorAtributo("RelacionPremio[1]/Opcion", "Sostenibilidad");
		n3.setValorAtributo("RelacionPremio[1]/Opcion", "EA");
		n3.setValorAtributo("RelacionPremio[1]/Opcion", "Pintura Museo");
		n3.setValorAtributo("RelacionOperacion[1]/Opcion", "Misión nacional");
		n3.setValorAtributo("RelacionOperacion[1]/Opcion", "Ejercicio");
		n3.setValorAtributo("RelacionTecnologia[1]/Opcion", "Vehículos");
		n3.setValorAtributo("RelacionFormacion[1]/Opcion", "Hardware");
		n3.setValorAtributo("RelacionPersonal[1]/Opcion", "Reconocimiento");
				
		//********NOTICIA 4*******************************//
		System.out.println("---------NOTICIA 4----------------");
		n4.setValorAtributo("RelacionUnidad[1]/Opcion", "Ala 12");
		n4.setValorAtributo("RelacionUnidad[1]/Opcion", "Ala 46");
		//n4.setValorAtributo("RelacionHistoria[1]/Opcion", "Horas de vuelo");		
		n4.setValorAtributo("RelacionPremio[1]/Opcion", "EA");
		n4.setValorAtributo("RelacionPremio[1]/Opcion", "Pintura Museo");
		n4.setValorAtributo("RelacionOperacion[1]/Opcion", "Misión nacional");
		n4.setValorAtributo("RelacionOperacion[1]/Opcion", "Ejercicio");		
		n4.setValorAtributo("RelacionTecnologia[1]/Opcion", "Vehículos");
		n4.setValorAtributo("RelacionFormacion[1]/Opcion", "Hardware");
		n4.setValorAtributo("RelacionPersonal[1]/Opcion", "Reconocimiento");
		//********NOTICIA 5*******************************//
		System.out.println("---------NOTICIA 5----------------");
		/*
		n5.setValorAtributo("RelacionUnidad[1]/Opcion", "Ala 12");
		n5.setValorAtributo("RelacionUnidad[1]/Opcion", "Ala 46");
		n5.setValorAtributo("RelacionPremio[1]/Opcion", "Sostenibilidad");
		n5.setValorAtributo("RelacionPremio[1]/Opcion", "EA");
		n5.setValorAtributo("RelacionPremio[1]/Opcion", "Pintura Museo");
		n5.setValorAtributo("RelacionOperacion[1]/Opcion", "Misión nacional");
		n5.setValorAtributo("RelacionOperacion[1]/Opcion", "Ejercicio");
		n5.setValorAtributo("RelacionTecnologia[1]/Opcion", "Vehículos");
		n5.setValorAtributo("RelacionFormacion[1]/Opcion", "Hardware");
		n5.setValorAtributo("RelacionPersonal[1]/Opcion", "Reconocimiento");
		*/
		//********NOTICIA 6*******************************//
		System.out.println("---------NOTICIA 6----------------");
		n6.setValorAtributo("RelacionUnidad[1]/Opcion", "Ala 12");
		n6.setValorAtributo("RelacionUnidad[1]/Opcion", "Ala 46");
		n6.setValorAtributo("RelacionUnidad[1]/Opcion", "Ala adsd");

		//n5.setValorAtributo("RelacionPremio[1]/Opcion", "Sostenibilidad");
		n6.setValorAtributo("RelacionPremio[1]/Opcion", "EA");
		n6.setValorAtributo("RelacionPremio[1]/Opcion", "Pintura Museo");
		n6.setValorAtributo("RelacionOperacion[1]/Opcion", "Misión nacional");
		n6.setValorAtributo("RelacionOperacion[1]/Opcion", "Ejercicio");
		n6.setValorAtributo("RelacionTecnologia[1]/Opcion", "Vehículos");
		n6.setValorAtributo("RelacionFormacion[1]/Opcion", "Hardware");
		n6.setValorAtributo("RelacionPersonal[1]/Opcion", "Reconocimiento");
		
		//*****PRUEBA HASHMAP CATEGORIAS**********///
		System.out.println("PRUEBA HASHMAP CATEGORIAS...");
		HashMap<String,ArrayList<String>> categorias = n5.getCategorias();
		for (String r : categorias.keySet()) {
			System.out.println(r+": ");
			for(String re : categorias.get(r)) {
				System.out.println(re);
			}
		}
		
		//*****PRUEBA HASHMAP CATEGORIAS**********///
		LinkedList<Noticia> noticiasRelacionadas = listaNoticias.getNoticiasRelacionadas(n5);
		for (Noticia noticia : noticiasRelacionadas) {
			noticia.getUrlImagenComparte();
			System.out.println("Noticia : "+noticia.getTitulo()+" " +noticia.getFechaString());
		}
		//System.out.println(noticiasRelacionadas);
		//EJEMPLO QUERY
		System.out.println("Ejemplo query...");
		String id="";
		String query = "resourceId=8d8b17e2-52c2-11ee-b874-005056bf91c5&path=/sites/internet.es/.content/noticiaEA/noticiaEA_00008.xml";
		String query2=null;
		String queryCategoria="categoria=801%20Escuadrón%20de%20Fuerzas%20Aéreas";
		if(query != null  && query.contains("resourceId")) {
			id= query.substring(query.indexOf('=')+1, query.indexOf('&'));
			System.out.println(id);
		}
	
	}
}