package internet.es;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
//********NUEVOO****************//
import java.util.stream.Collectors;

import org.opencms.file.CmsFile;
import org.opencms.file.CmsObject;
import org.opencms.file.CmsResource;
import org.opencms.file.CmsResourceFilter;
import org.opencms.main.OpenCms;
import org.opencms.xml.content.CmsXmlContent;
import org.opencms.xml.content.CmsXmlContentFactory;
import org.opencms.xml.types.CmsXmlNestedContentDefinition;
import org.opencms.xml.types.I_CmsXmlContentValue;

public class ListaNoticias {
	CmsObject cmsObject;
	ArrayList<Noticia> noticiasTotal;
	String pathContentNoticias ;
	String tipoRecurso = "noticiaEA";
	List<CmsResource> listaRecursosNoticias = null;
	Locale locale;


	/**
	 * @return the tipoRecurso
	 */
	public String getTipoRecurso() {
		return tipoRecurso;
	}

	/**
	 * @param tipoRecurso the tipoRecurso to set
	 */
	public void setTipoRecurso(String tipoRecurso) {
		this.tipoRecurso = tipoRecurso;
	}
	
	//****PRUEBA**********************//
	public ListaNoticias() {
		
	}
	
	public ListaNoticias(CmsObject cmsObject, String pathContentNoticias) {
		super();
		this.pathContentNoticias = pathContentNoticias;
		this.cmsObject = cmsObject;
		locale = cmsObject.getRequestContext().getLocale();
	}
	
	public String getListaAtributos() throws Exception {
			StringBuffer sb = new StringBuffer();
			List<CmsResource> listaRecursos = getListaRecursosNoticias();
			
			for(CmsResource recurso: listaRecursos) {
				sb.append("<BR><STRONG>RECURSO</STRONG>: "+ recurso.getRootPath()+"<BR>");
				CmsFile fileRecurso = cmsObject.readFile(recurso);
				CmsXmlContent xmlContent = CmsXmlContentFactory.unmarshal(cmsObject, fileRecurso);
				
				String valor = "";
				I_CmsXmlContentValue atributo;
				
				//Asignamos todos los valores a la noticia
				List<String> keys = xmlContent.getNames(locale);
				for(String key : keys) {
					atributo = xmlContent.getValue(key, locale);
					sb.append("ATRIBUTO"+"<BR>");
					sb.append("key: "+key+"<BR>");
					sb.append("atributo: "+atributo+"<BR>");
					if(atributo.getClass().equals(CmsXmlNestedContentDefinition.class)){
						List<I_CmsXmlContentValue> listaAtributosHijos =  xmlContent.getAllSimpleSubValues(atributo);
						for(I_CmsXmlContentValue atributoHijo: listaAtributosHijos) {
							if(!atributo.getClass().equals(CmsXmlNestedContentDefinition.class) && !atributo.getPath().contains("/")){
								valor = atributo.getStringValue(cmsObject);
								sb.append("valor: "+valor+"<BR>");
							}							
						}
					}else if (!atributo.getPath().contains("/")){
						valor = atributo.getStringValue(cmsObject);
						sb.append("valor: "+valor+"<BR>");
					}
				}				
			}
		return sb.toString();
	}
	
	/**
	 * @return the noticiasTotal
	 * @throws Exception 
	 */
	public ArrayList<Noticia> getNoticias() throws Exception {
		if(noticiasTotal == null) {
			ArrayList<Noticia> listaNoticias = new ArrayList<Noticia>();
			List<CmsResource> listaRecursos = getListaRecursosNoticias();
			Noticia noticia;
			for(CmsResource recurso: listaRecursos) {
				noticia = new Noticia(cmsObject, recurso);
				
				listaNoticias.add(noticia);
			}
			noticiasTotal =  listaNoticias; 
		}
		ordenarFecha(noticiasTotal, true);
		return noticiasTotal;
	}
	/**
	 * @param numeroNoticias
	 * @return
	 * @throws Exception 
	 */
	public ArrayList<Noticia> getNoticias(int numeroNoticias) throws Exception{
		ArrayList<Noticia> noticiasFiltradas = new ArrayList<Noticia>();
		
		List<CmsResource> listaRecursos = getListaRecursosNoticias();
		Noticia noticia;
		int i=0;
		for(CmsResource recurso: listaRecursos) {
			noticia = new Noticia(cmsObject, recurso);
			
			noticiasFiltradas.add(noticia);
			if(i == numeroNoticias) {
				break;
			}
			i++;
		}
		return noticiasFiltradas;		
	}
	
	private void ordenarFecha(List<Noticia> listaNoticias, boolean ordenacionDescendente) {
		Collections.sort(listaNoticias, new Comparator<Noticia>() {
		   public int compare(Noticia noticia1, Noticia noticia2) {
			   Date fecha1 = noticia1.getFecha();
			   Date fecha2 = noticia2.getFecha();
				if(ordenacionDescendente)
					return fecha2.compareTo(fecha1);
				else
					return fecha1.compareTo(fecha2);
					
			   }
			});
	}
	
	private int getAnioNoticia(Noticia noticia) {
		Calendar calendar = Calendar.getInstance();
	    calendar.setTime(noticia.getFecha());
	    return calendar.get(Calendar.YEAR);
	    
	}
	public ArrayList<Noticia> getNoticias(String anio) throws Exception{
		boolean isNumeric = anio.chars().allMatch( Character::isDigit );
		ArrayList<Noticia> noticiasFiltradas = null;
		if(isNumeric) {
			noticiasFiltradas = new ArrayList<Noticia>();
			ArrayList<Noticia> listaTotal = getNoticias();
			for(Noticia noticia:listaTotal) {
		        int dateYear = getAnioNoticia(noticia);
		        if(dateYear == Integer.valueOf(anio)) {
		        	noticiasFiltradas.add(noticia);
		        }
			}
		}
		return noticiasFiltradas;
	}
	private List<CmsResource> getListaRecursosNoticias() throws Exception{
		if(listaRecursosNoticias == null) {
				CmsResourceFilter filtro = CmsResourceFilter.requireType(OpenCms.getResourceManager().getResourceType(tipoRecurso));
				listaRecursosNoticias = cmsObject.readResources(pathContentNoticias,filtro, true);
		}
		return listaRecursosNoticias;
	}
	
	public ArrayList<String> getAnios() throws Exception{
		ArrayList<String> anios = new ArrayList<String>();
		ArrayList<Noticia> listaTotal = getNoticias();
		int dateYear;
		String anio;
		for(Noticia noticia:listaTotal) {
			dateYear = getAnioNoticia(noticia);
			anio = String.valueOf(dateYear);
			if(!anios.contains(anio)){
				anios.add(anio);
			}
		}
		Collections.sort(anios, Collections.reverseOrder());
		return anios;
	}
	public ArrayList<String> getCategorias(){
		ArrayList<String> categorias = new ArrayList<String>();
		return categorias;
	}
	
	//***********PRUEBA************************//
	public void setNoticias(ArrayList<Noticia> noticias) {
		this.noticiasTotal = noticias;
	} 
	
	//***********NUEVOOO**********************//
	public ArrayList<Noticia> getRecentNoticias() throws Exception{
		ArrayList<Noticia> noticias = getNoticias().stream().
				limit(3).collect(Collectors.toCollection(ArrayList::new));
		return noticias;
	}
	
	public LinkedList<Noticia> getNoticiasRelacionadas(Noticia noticia) {
		LinkedList<Noticia> noticiasRelacionadas = new LinkedList<Noticia>();
		for(int i =0; i<noticiasTotal.size(); i++) {
			if(noticia.getId()!=noticiasTotal.get(i).getId()) {
				if(tienenMismasCategorias(noticia, noticiasTotal.get(i))) {
					noticiasRelacionadas.add(noticiasTotal.get(i));
				}
			}
		}
		ordenarFecha(noticiasRelacionadas, true);
		return noticiasRelacionadas.stream().limit(3).collect(Collectors.toCollection(LinkedList<Noticia>::new));
	}
	
	public boolean tienenMismasCategorias(Noticia n1, Noticia n2) {
		for(Map.Entry<String, ArrayList<String>> entry : n1.getCategorias().entrySet()) {
			String key = entry.getKey();
			ArrayList<String> valores = entry.getValue();
			//Verificamos si la clave existe en el otro hashmap
			if(!n2.getCategorias().containsKey(key)) {
				return false;
			}
			//verificamos si los valores existen en los dos hashmaps
			if(!n2.getCategorias().get(key).containsAll(valores)) {
				return false;
			}
		}
		return true;
	}
	
	@Override
	public String toString() {
		StringBuffer sb = new StringBuffer();
		ArrayList<Noticia> noticias = null;
		try {
			noticias = getNoticias();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		for(Noticia noticia:noticias) {
			sb.append("<BR><STRONG>NOTICIA</STRONG>: "+ noticia.toString()+"<BR>");
		}
		
		return sb.toString();
	}



}
