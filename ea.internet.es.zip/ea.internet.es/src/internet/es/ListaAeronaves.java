package internet.es;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.opencms.file.CmsObject;
import org.opencms.file.CmsResource;
import org.opencms.file.CmsResourceFilter;
import org.opencms.main.OpenCms;

public class ListaAeronaves  {

	private CmsObject cmsObject;
	private String pathContentAeronaves;
	private final String tipoRecurso = "aeronave";
	private List<CmsResource> listaRecursosAeronaves = null;
	private ArrayList<Aeronave> listaAeronaves;
	
	public ListaAeronaves() {
		var stream = Stream.of(1,2,3);
		List l = new ArrayList();
	}
	
	public ListaAeronaves(CmsObject cmsObject, String pathContentAeronaves) throws Exception {
		super();
		this.pathContentAeronaves = pathContentAeronaves;
		this.cmsObject = cmsObject;
		getAeronaves();
	}

	public void getAeronaves() throws Exception{
		if(this.listaAeronaves == null) {
			ArrayList<Aeronave> listaAeronaves = new ArrayList<>();
			this.listaRecursosAeronaves= listaRecursosAeronaves == null 
					? cmsObject.readResources(this.pathContentAeronaves,CmsResourceFilter.requireType(OpenCms.getResourceManager().getResourceType(tipoRecurso)), true) 
							: listaRecursosAeronaves;
			for(CmsResource recurso : this.listaRecursosAeronaves) {
				listaAeronaves.add(new Aeronave(cmsObject, recurso));
			}
			setListaAeronaves(listaAeronaves);
		}
	}
	

	
	public String getTipoRecurso() {
		return tipoRecurso;
	}

	public ArrayList<Aeronave> getListaAeronaves() {
		return listaAeronaves;
	}

	public ArrayList<Aeronave> getListaAeronavesActivas() {
		return listaAeronaves.stream().filter(a -> a.getActivo().equals("true"))
				.collect(Collectors.toCollection(ArrayList::new));
	}
	
	public void setListaAeronaves(ArrayList<Aeronave> listaAeronaves) {
		this.listaAeronaves = listaAeronaves;
	}

}
