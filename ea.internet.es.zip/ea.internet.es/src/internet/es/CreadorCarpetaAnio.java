package internet.es;

import java.util.List;
import java.util.Locale;

import org.opencms.file.CmsFile;
import org.opencms.file.CmsObject;
import org.opencms.file.CmsProperty;
import org.opencms.file.CmsResource;
import org.opencms.file.CmsVfsResourceNotFoundException;
import org.opencms.file.types.CmsResourceTypeFolder;
import org.opencms.jsp.util.CmsJspContentAccessBean;
import org.opencms.main.CmsException;
import org.opencms.main.OpenCms;
import org.opencms.xml.content.CmsXmlContent;
import org.opencms.xml.content.CmsXmlContentFactory;
import org.opencms.xml.types.I_CmsXmlContentValue;

public class CreadorCarpetaAnio {

	CmsObject cmsObject = null;

	public CreadorCarpetaAnio(CmsObject cmsObject1){
		cmsObject = cmsObject1;
	}
	
	public CmsResource crearCarpeta( String pathCarpeta) throws Exception  {
		CmsResource recurso = null;
		if(!cmsObject.existsResource(pathCarpeta)) {
			recurso = cmsObject.createResource(pathCarpeta,OpenCms.getResourceManager().getResourceType(CmsResourceTypeFolder.RESOURCE_TYPE_NAME));
		}
		
		return recurso;
	}
	public CmsResource cambiarListaNoticiasRevistaAlIndex(String pathCarpeta, CmsResource listaNoticias) throws Exception{

		pathCarpeta += "/index.html";

		CmsResource index = cmsObject.readResource(pathCarpeta);

		CmsFile fileNueva = cmsObject.readFile(index);
		CmsXmlContent xmlContentNueva = CmsXmlContentFactory.unmarshal(cmsObject, fileNueva);

		Locale en = new Locale("en");
		I_CmsXmlContentValue actualValue =null;

		List<I_CmsXmlContentValue> valores = xmlContentNueva.getValues(en);
		for(int j=1;j<valores.size();j++) {
			actualValue = valores.get(j);
			if (actualValue.getPath().contains("Uri") 
					&& actualValue.getStringValue(cmsObject).contains(OpenCms.getResourceManager().getResourceType(listaNoticias).getTypeName())){
				break;
			}
		}
		if(actualValue != null){
			actualValue.setStringValue(cmsObject, listaNoticias.getRootPath());
			fileNueva.setContents(xmlContentNueva.marshal());
			cmsObject.writeFile(fileNueva);
		}
		
		return index;
	}
	
	private String getCarpetaExistente(String pathCarpetas, String yearAActualizar) throws Exception{
		int i= 1;
		boolean existe = false;
		String pathCarpetaACopiar = "";
		while(!existe && i< 200){
				pathCarpetaACopiar = pathCarpetas + (Integer.valueOf(yearAActualizar) - i);
				existe = cmsObject.existsResource(pathCarpetaACopiar);
				i++;
		}
		if(!existe){
			i = 1;
			pathCarpetaACopiar = "";
			while(!existe && i< 200){
					pathCarpetaACopiar = pathCarpetas + (Integer.valueOf(yearAActualizar) + i);
					existe = cmsObject.existsResource(pathCarpetaACopiar);
					i++;

			}
		}
		return pathCarpetaACopiar;
	}
	public CmsResource copiarCarpeta( String pathCarpetas, String yearAActualizar) throws Exception{
		CmsResource recurso = null;
		String pathNuevaCarpeta = pathCarpetas + yearAActualizar;
		String pathCarpetaACopiar = getCarpetaExistente(pathCarpetas,yearAActualizar);
		cmsObject.copyResource(pathCarpetaACopiar,pathNuevaCarpeta);
		recurso = cmsObject.readResource(pathNuevaCarpeta);
		return recurso;
	}
	public CmsResource cambiarAnioListaNoticias(CmsResource listaNoticias,String year){
		CmsResource recurso = null;
		try{
			CmsFile fileNueva = cmsObject.readFile(listaNoticias);
			CmsXmlContent xmlContentNueva = CmsXmlContentFactory.unmarshal(cmsObject, fileNueva);
			xmlContentNueva.getValue("Year", cmsObject.getRequestContext().getLocale(), 0).setStringValue(cmsObject, year);
			fileNueva.setContents(xmlContentNueva.marshal());
			cmsObject.writeFile(fileNueva);
			recurso = listaNoticias;
		}catch(CmsException e){
			recurso = null;
		}
		return recurso;
	}
	public CmsResource copiarListaNoticias(String tipoComponente) throws CmsException{
		String tipo = tipoComponente;
		String pathRevista = ".content/" + tipo + "/";
		String pathElementoACopiar = pathRevista + getNombreNuevoElemento(tipo,1);
		String nombreElemento = getPrimerNombreElemento(tipo,pathRevista);
		String pathNuevoElemento = pathRevista + nombreElemento;
		CmsResource recurso = null;
		try{
			cmsObject.copyResource(pathElementoACopiar, pathNuevoElemento);
			recurso= cmsObject.readResource(pathNuevoElemento);

		}catch(CmsException e3){
			return recurso;
		}
		return recurso;
	}
	private String getPrimerNombreElemento(String tipoRecurso, String pathElementos) throws CmsException{
		int num= 1;
		String pathElemento = "";
		
		String nombreElemento ="";
		try{
			while(true){
				nombreElemento = getNombreNuevoElemento(tipoRecurso,num);
				pathElemento = pathElementos + nombreElemento;
				cmsObject.readResource(pathElemento);
				num++;
			}

		}catch(CmsVfsResourceNotFoundException e){
			return nombreElemento;
		}
	}
	public String getNombreNuevoElemento(String tipoRecurso, int number){

		//CREAMOS EL NOMBRE DEL NUEVO ELEMENTO
		String numberS = String.valueOf(number);
		while(numberS.length() <5){
			numberS = "0" + numberS;
		}

		return tipoRecurso + "-" + numberS + ".xml";
	}
	public Object crearCarpetaAnioSiNoExiste(CmsJspContentAccessBean beanContent, String yearNoticia) throws Exception{

			//Comprobar si existe la carpeta del año y si no crearla.
			String yearActualizar = yearNoticia;
			String tipoComponente = "listaNoticiasEA";

			String pathCarpetas = beanContent.getValue().get("RutaRaiz").toString();
			String pathCarpeta = pathCarpetas + yearActualizar;
			CmsResource carpeta = null;
			CmsResource revista = null;
			boolean existe = cmsObject.existsResource(pathCarpeta);
			if (!existe) {
					
				//CmsResource carpeta = utilidades.crearCarpeta(pathCarpeta);
				carpeta = copiarCarpeta(pathCarpetas, yearActualizar);
				carpeta = cambiarTitle(carpeta, "Noticias " + yearActualizar);

				revista = copiarListaNoticias(tipoComponente);
				revista = cambiarAnioListaNoticias(revista, yearActualizar);
				revista = cambiarTitle(revista, yearActualizar);

				CmsResource index = cambiarListaNoticiasRevistaAlIndex(pathCarpeta, revista);
				index = cambiarTitle(index, "Noticias-" + yearActualizar);
			}
		return revista;

	}
	public CmsResource cambiarTitle(CmsResource recurso, String value) throws Exception{
		CmsProperty property = null;
		String site = cmsObject.getRequestContext().getSiteRoot();
		try {

			cmsObject.getRequestContext().setSiteRoot("/");

			property = cmsObject.readPropertyObject(recurso, "Title", false);
			if (property.getValue() != null ) {
				property.setValue(value, CmsProperty.TYPE_INDIVIDUAL);
				cmsObject.writePropertyObject(recurso.getRootPath(), property);
			}

			property = cmsObject.readPropertyObject(recurso, "Description", false);
			if (property.getValue() != null ) {
				property.setValue(value, CmsProperty.TYPE_INDIVIDUAL);
				cmsObject.writePropertyObject(recurso.getRootPath(), property);
			}

			if (recurso.isFolder()) {
				property = cmsObject.readPropertyObject(recurso, "NavText", false);
				if (property.getValue() != null ) {
					property.setValue(value, CmsProperty.TYPE_INDIVIDUAL);
					cmsObject.writePropertyObject(recurso.getRootPath(), property);
				}
			}

			cmsObject.getRequestContext().setSiteRoot(site);
		}catch (Exception e){
			cmsObject.getRequestContext().setSiteRoot(site);
			throw e;
		}
		return recurso;
	}
	
}