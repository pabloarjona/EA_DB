package internet.es;

public abstract class AtributosCompartidos {
	protected String urlImagenComparte;
	protected String textoAlternativoComparte;
	protected String enlaceComparte;
	
	public void inicializarAtributosCompartidos(String urlImagenComparte, String textoAlternativoComparte, String enlaceComparte) {
		this.urlImagenComparte = urlImagenComparte;
		this.textoAlternativoComparte = textoAlternativoComparte;
		this.enlaceComparte = enlaceComparte;
	}

	public String getUrlImagenComparte() {
		return urlImagenComparte;
	}

	public void setUrlImagenComparte(String urlImagenComparte) {
		this.urlImagenComparte = urlImagenComparte;
	}

	public String getTextoAlternativoComparte() {
		return textoAlternativoComparte;
	}

	public void setTextoAlternativoComparte(String textoAlternativoComparte) {
		this.textoAlternativoComparte = textoAlternativoComparte;
	}

	public String getEnlaceComparte() {
		return enlaceComparte;
	}

	public void setEnlaceComparte(String enlaceComparte) {
		this.enlaceComparte = enlaceComparte;
	}
	
}
