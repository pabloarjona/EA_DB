package internet.es;

public class ImagenGaleria {
	private String urlImagen;
	private String textoAlternativo;
	
	public ImagenGaleria(String urlImagen, String textoAlternativo) {
		super();
		this.urlImagen = urlImagen;
		this.textoAlternativo = textoAlternativo;
	}
	
	public String getUrlImagen() {
		return urlImagen;
	}
	public void setUrlImagen(String urlImagen) {
		this.urlImagen = urlImagen;
	}
	public String getTextoAlternativo() {
		return textoAlternativo;
	}
	public void setTextoAlternativo(String textoAlternativo) {
		this.textoAlternativo = textoAlternativo;
	}
}
