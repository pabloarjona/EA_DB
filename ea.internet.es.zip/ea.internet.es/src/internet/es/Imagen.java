package internet.es;

public class Imagen {
	private String urlImagen;
	private String textoAlternativo;
	private String enlace;
	
	public Imagen(String urlImagen, String textoAlternativo, String enlace) {
		super();
		this.urlImagen = urlImagen;
		this.textoAlternativo = textoAlternativo;
		this.enlace = enlace;
	}
	public String getUrlImagen() {
		return urlImagen;
	}
	public void setUrlImagen(String urlImagen) {
		this.urlImagen = urlImagen;
	}
	public String getTextoAlternativo() {
		return textoAlternativo;
	}
	public void setTextoAlternativo(String textoAlternativo) {
		this.textoAlternativo = textoAlternativo;
	}
	public String getEnlace() {
		return enlace;
	}
	public void setEnlace(String enlace) {
		this.enlace = enlace;
	}
}
