package internet.es;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

import org.opencms.file.CmsFile;
import org.opencms.file.CmsObject;
import org.opencms.file.CmsResource;
import org.opencms.main.CmsException;
import org.opencms.main.OpenCms;
import org.opencms.xml.content.CmsXmlContent;
import org.opencms.xml.content.CmsXmlContentFactory;
import org.opencms.xml.types.CmsXmlNestedContentDefinition;
import org.opencms.xml.types.I_CmsXmlContentValue;

public class Noticia extends AtributosCompartidos{
	String urlImagenPrincipal;
	String altImagenPrincipal;
	String titulo;
	String resumen;
	String texto;
	String fechaString;
	Date fecha;
	String filename;
	private CmsObject cmsObject;
	private CmsResource recursoNoticia;
	private Locale locale;
	private String id;
	private String tipoNoticia;
	private HashMap<String, ArrayList<String>> categorias;
	
	public Noticia(CmsObject cmsObject, CmsResource recursoNoticia) throws CmsException{
		super();
		this.cmsObject = cmsObject;
		this.recursoNoticia = recursoNoticia;
		inicializarAtributosCompartidos("","","");
		locale = cmsObject.getRequestContext().getLocale();
		this.filename = recursoNoticia.getRootPath();
		categorias = new HashMap<String, ArrayList<String>>();
		asignarAtributos();
	}
		
	//********************PRUEBA*******************************************//
	public Noticia(String id , String urlImagenPrincipal, String altImagenPrincipal, String titulo, String resumen, String texto, String fechaString, Date fecha) {
		inicializarAtributosCompartidos("","","");
		this.id = id;
		this.urlImagenPrincipal = urlImagenPrincipal;
		this.altImagenPrincipal = altImagenPrincipal;
		this.titulo = titulo;
		this.resumen = resumen;
		this.texto = texto;
		this.fechaString = fechaString;
		this.fecha = fecha;
	}
	/**
	 * @return the categorias
	 */
	public HashMap<String, ArrayList<String>> getCategorias() {
		return categorias;
	}

	/**
	 * @param categorias the categorias to set
	 */
	public void setCategorias(HashMap<String, ArrayList<String>> categorias) {
		this.categorias = categorias;
	}
	
	public boolean tieneSubcategoria(String subcategoria) {
		ArrayList<String> opciones;
		for(String key:categorias.keySet()) {
			opciones = categorias.get(key);
			for(String opcion: opciones) {
				if(opcion.equals(subcategoria)) {
					return true;
				}
			}
		}
		return false;
	}
	private void asignarAtributos() throws CmsException {
		//Recojo el xml de la noticia origen 
		CmsFile fileNoticia = cmsObject.readFile(recursoNoticia);
		CmsXmlContent xmlContentNoticia = CmsXmlContentFactory.unmarshal(cmsObject, fileNoticia);
		
		//Asignamos el id
		id = recursoNoticia.getStructureId().getStringValue();

		//Asignamos el tipoRecurso
		tipoNoticia = OpenCms.getResourceManager().getResourceType(recursoNoticia.getTypeId()).getTypeName();
				
		String valor = "";
		I_CmsXmlContentValue atributo;
		
		//Asignamos todos los valores a la noticia
		List<String> keys = xmlContentNoticia.getNames(locale);
		for(String key : keys) {
			atributo = xmlContentNoticia.getValue(key, locale);
			if(!atributo.getClass().equals(CmsXmlNestedContentDefinition.class)){
				valor = atributo.getStringValue(cmsObject);
				setValorAtributo(key, valor);
			}
		}		
	}
	
	public void setValorAtributo(String atributo, String valor) {
		switch (atributo) {
		case "Titulo[1]": {
			setTitulo(valor);
			break;
		}
		case "Resumen[1]": {
			setResumen(valor);
			break;
		}
		case "Descripcion[1]": {
			setTexto(valor);
			break;
		}
		case "Fecha[1]": {
			Date date = new Date(Long.valueOf(valor));
			setFecha(date);
			DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
			setFechaString(dateFormat.format(date));
			break;
		}
		case "ImagenPrincipal[1]/UrlImagen[1]": {
			setUrlImagenPrincipal(valor);
			break;
		}
		case "ImagenPrincipal[1]/TextoAlternativo[1]": {
			setAltImagenPrincipal(valor);
			break;
		}
		//************CORREGUIRRRRRRRRRRRRR******
		case "Comparte[1]/Imagen[1]/UrlImagen[1]":{
			setUrlImagenComparte(valor);
			break;
		}
		case "Comparte[1]/Imagen[1]/TextoAlternativo[1]":{
			setTextoAlternativoComparte(valor); 
			break;
		}
		case "Comparte[1]/Imagen[1]/Enlace[1]":{
			setEnlaceComparte(valor);
			break;
		}
		//**********HASTA AQUÍ********************
		default:
			break;
		}
		if(atributo.contains("Relacion")) {
			int indiceCorchete = atributo.indexOf("[");
			String relacion = atributo.substring(0,indiceCorchete);
			String categoria = relacion.substring(8);
			
			ArrayList<String> opciones = categorias.get(categoria);
			if(opciones == null) {
				opciones = new ArrayList<String>();
			}
			opciones.add(valor);
			categorias.put(categoria, opciones);
		}
	}
	
	
	/**
	 * @return the tipoNoticia
	 */
	public String getTipoNoticia() {
		return tipoNoticia;
	}

	/**
	 * @param tipoNoticia the tipoNoticia to set
	 */
	public void setTipoNoticia(String tipoNoticia) {
		this.tipoNoticia = tipoNoticia;
	}

	/**
	 * @return the filename
	 */
	public String getFilename() {
		return filename;
	}

	/**
	 * @param filename the filename to set
	 */
	public void setFilename(String filename) {
		this.filename = filename;
	}

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the urlImagenPrincipal
	 */
	public String getUrlImagenPrincipal() {
		return urlImagenPrincipal;
	}
	/**
	 * @param urlImagenPrincipal the urlImagenPrincipal to set
	 */
	public void setUrlImagenPrincipal(String urlImagenPrincipal) {
		this.urlImagenPrincipal = urlImagenPrincipal;
	}
	/**
	 * @return the altImagenPrincipal
	 */
	public String getAltImagenPrincipal() {
		return altImagenPrincipal;
	}
	/**
	 * @param altImagenPrincipal the altImagenPrincipal to set
	 */
	public void setAltImagenPrincipal(String altImagenPrincipal) {
		this.altImagenPrincipal = altImagenPrincipal;
	}
	/**
	 * @return the titulo
	 */
	public String getTitulo() {
		return titulo;
	}
	/**
	 * @param titulo the titulo to set
	 */
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	/**
	 * @return the resumen
	 */
	public String getResumen() {
		return resumen;
	}
	/**
	 * @param resumen the resumen to set
	 */
	public void setResumen(String resumen) {
		this.resumen = resumen;
	}
	/**
	 * @return the texto
	 */
	public String getTexto() {
		return texto;
	}
	/**
	 * @param texto the texto to set
	 */
	public void setTexto(String texto) {
		this.texto = texto;
	}
	
	/**
	 * @return the fechaString
	 */
	public String getFechaString() {
		return fechaString;
	}
	/**
	 * @param fechaString the fechaString to set
	 */
	public void setFechaString(String fechaString) {
		this.fechaString = fechaString;
	}
	/**
	 * @return the fecha
	 */
	public Date getFecha() {
		return fecha;
	}
	/**
	 * @param fecha the fecha to set
	 */
	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}
	@Override
	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append("<BR>");
		sb.append("<STRONG>NOTICIA</STRONG>");
		sb.append("<BR>");
		sb.append("Path");sb.append(filename);sb.append("<BR>");
		sb.append("titulo");sb.append(titulo);sb.append("<BR>");
		sb.append("fecha");sb.append(fechaString);sb.append("<BR>");
		sb.append("resumen");sb.append(resumen);sb.append("<BR>");
		sb.append("texto");sb.append(texto);sb.append("<BR>");
		sb.append("urlImagenPrincipal");sb.append(urlImagenPrincipal);sb.append("<BR>");
		sb.append("altImagenPrincipal");sb.append(altImagenPrincipal);sb.append("<BR>");
		sb.append("RELACIONES");
		sb.append("<BR>");
		for(String key: categorias.keySet()) {
			sb.append("Relación: ");sb.append(key);sb.append("<BR>");
			ArrayList<String> opciones = categorias.get(key);
			for(String opcion:opciones) {
				sb.append("&nbsp;Opción: ");sb.append(opcion);sb.append("<BR>");
			}
		}
		return sb.toString();
	}
	

}