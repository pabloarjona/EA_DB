package internet.es;

import java.util.LinkedList;
import java.util.Locale;
import org.opencms.file.CmsObject;
import org.opencms.file.CmsResource;
import org.opencms.main.CmsException;
import org.opencms.main.OpenCms;
import org.opencms.xml.content.CmsXmlContent;
import org.opencms.xml.content.CmsXmlContentFactory;
import org.opencms.xml.types.CmsXmlNestedContentDefinition;
import org.opencms.xml.types.I_CmsXmlContentValue;

public class Aeronave {
	//Descripcion
	private String activo;
	private String nombre;
	private String tipoAeronave;
	private String esImagenDecorativa;
	private String urlImagen;
	private String textoAlternativoImagen;
	
	//Presentación
	private String designacionFabricante;
	private String designacionEA;
	private String mision;
	private String fechaPrimerVuelo;
	private String fechaServicioEspana;
	private String paisOrigen;
	private String fabricante;
	private LinkedList<String> unidades = new LinkedList<>();
	
	//DATOS DETALLE
	//DIMENSIONES
	private String longitud;
	private String envergadura;
	private String altura;
	//PESO  	
	private String vacio;
	private String maximoDespegue;
	//VELOCIDAD
	private String velocidadMaxima;
	private String velocidadCrucero;
	//AUTONOMIA
	private String distancia;
	private String tiempo;
	
	private String motores;
	private String techoMaximo;
	private String reabastecimientoVuelo;
	private String armamento;
	
	//Datos técnicos
	private String velocidadMaximaEstrellas;
	private String velocidadCruceroEstrellas;
	private String autonomiaEstrellas;
	private String techoMaximoEstrellas;
	
	//Historia
	private String tituloHistoria;
	private String descripcionHistoria;
	//Galeria
	private String descripcionGaleria;
	private LinkedList<ImagenGaleria> imagenes = new LinkedList<>();

	private String fileName;
	private CmsObject cmsObject;
	private CmsResource recursoAeronave;
	private Locale locale;
	private String id;

	public Aeronave(CmsObject cmsObject, CmsResource recursoAeronave) throws CmsException {
		super();
		this.cmsObject = cmsObject;
		this.recursoAeronave = recursoAeronave;
		this.locale = cmsObject.getRequestContext().getLocale();
		this.fileName = recursoAeronave.getRootPath();
		asignarAtributos();
	}

	public Aeronave(String activo, String nombre, String tipoAeronave, String esImagenDecorativa, String urlImagen,
			String textoAlternativoImagen, String categoria, String designacionFabricante, String designacionEA,
			String mision, String fechaPrimerVuelo, String fechaServicioEspana, String paisOrigen, String fabricante,
			LinkedList<ImagenGaleria> imagenes) {
		super();
		this.activo = activo;
		this.nombre = nombre;
		this.tipoAeronave = tipoAeronave;
		this.esImagenDecorativa = esImagenDecorativa;
		this.urlImagen = urlImagen;
		this.textoAlternativoImagen = textoAlternativoImagen;
		this.designacionFabricante = designacionFabricante;
		this.designacionEA = designacionEA;
		this.mision = mision;
		this.fechaPrimerVuelo = fechaPrimerVuelo;
		this.fechaServicioEspana = fechaServicioEspana;
		this.paisOrigen = paisOrigen;
		this.fabricante = fabricante;
		this.imagenes = imagenes;
	}


	private void asignarAtributos() throws CmsException{
		CmsXmlContent xmlContentAeronave= CmsXmlContentFactory.unmarshal(cmsObject, cmsObject.readFile(recursoAeronave));
		this.id= recursoAeronave.getStructureId().getStringValue();
		this.tipoAeronave = OpenCms.getResourceManager().getResourceType(recursoAeronave.getTypeId()).getTypeName();
		for(String key : xmlContentAeronave.getNames(locale)) {
			I_CmsXmlContentValue  atributo = xmlContentAeronave.getValue(key, locale);
			if(atributo.getPath().contains("ImagenGaleria") && !atributo.getPath().contains("/")) {
				setValoresAtributo(xmlContentAeronave, atributo);
			}else {
				if(!atributo.getClass().equals(CmsXmlNestedContentDefinition.class)) {
					setValorAtributo(key, atributo.getStringValue(cmsObject));
				}
			}
		}
	}	
	
	private void setValoresAtributo(CmsXmlContent xmlContentAeronave, I_CmsXmlContentValue atributo) {
		String imagenDecorativa="", urlImagen="", textoAlternativo="";
		int cont=0;
		for(I_CmsXmlContentValue subvalor: xmlContentAeronave.getAllSimpleSubValues(atributo)) {
			I_CmsXmlContentValue subAtributo = xmlContentAeronave.getValue(subvalor.getPath(), locale);
			if(subvalor.getPath().contains("UrlImagen")) {
				urlImagen = subAtributo.getStringValue(cmsObject);
				cont++;
			}
			else if(subvalor.getPath().contains("TextoAlternativo")) {
				textoAlternativo = subAtributo.getStringValue(cmsObject);
				cont++;
			}
			if(cont==3) {
				imagenes.add(new ImagenGaleria(urlImagen, textoAlternativo));
				cont=0;
			}
		}
	}
	
	private void setValorAtributo(String atributo, String valor) { 
		switch(atributo) {
			//Descripcion
			case "Activo[1]":{
				setActivo(valor);
				break;
			}
			case "Nombre[1]":{
				setNombre(valor);
				break;
			}
			case "TipoAeronave[1]":{
				setTipoAeronave(valor);
				break;
			}
			case "ImagenPrincipal[1]/EsImagenDecorativa[1]":{
				setEsImagenDecorativa(valor);
				break;
			}
			case "ImagenPrincipal[1]/UrlImagen[1]":{
				setUrlImagen(valor);
				break;
			}
			case "ImagenPrincipal[1]/TextoAlternativo[1]":{
				setTextoAlternativoImagen(valor);
				break;
			}
			//Presentacion
			case "DesignacionFabricante[1]":{
				setDesignacionFabricante(valor);
				break;
			}
			case "DesignacionEA[1]":{
				setDesignacionEA(valor);
				break;
			}case "Mision[1]":{
				setMision(valor);
				break;
			}case "FechaPrimerVuelo[1]":{
				setFechaPrimerVuelo(valor);
				break;
			}case "FechaServicioEspana[1]":{
				setFechaServicioEspana(valor);
				break;
			}case "PaisOrigen[1]":{
				setPaisOrigen(valor);
				break;
			}case "Fabricante[1]":{
				setFabricante(valor);
				break;
			}
			//Datos técnicos
			case "VelocidadMaximaEstrellas[1]":{
				setVelocidadMaximaEstrellas(valor);
				break;
			}
			case "VelocidadCruceroEstrellas[1]":{
				setVelocidadCruceroEstrellas(valor);
				break;
			}
			case "AutonomiaEstrellas[1]":{
				setAutonomiaEstrellas(valor);
				break;
			}
			case "TechoMaximoEstrellas[1]": {
				setTechoMaximoEstrellas(valor);
				break;
			}
			//Datos detalle
			case "Longitud[1]":{
				setLongitud(valor);
				break;
			}
			case "Envergadura[1]":{
				setEnvergadura(valor);
				break;
			}
			case "Altura[1]":{
				setAltura(valor);
				break;
			}
			case "Vacio[1]": {
				setVacio(valor);
				break;
			}
			case "MaximoDespegue[1]":{
				setMaximoDespegue(valor);
				break;
			}
			case "VelocidadMaxima[1]":{
				setVelocidadMaxima(valor);
				break;
			}
			case "VelocidadCrucero[1]":{
				setVelocidadCrucero(valor);
				break;
			}
			case "Distancia[1]":{
				setDistancia(valor);
				break;
			}
			case "Tiempo[1]":{
				setTiempo(valor);
				break;
			}
			case "Motores[1]": {
				setMotores(valor);
				break;
			}
			case "TechoMaximo[1]":{
				setTechoMaximo(valor);
				break;
			}
			case "ReabastecimientoVuelo[1]":{
				setReabastecimientoVuelo(valor);
				break;
			}
			case "Armamento[1]": {
				setArmamento(valor);
				break;
			}
			//Historia
			case "TituloHistoria[1]": {
				setTituloHistoria(valor);
				break;
			}
			case "DescripcionHistoria[1]":{
				setDescripcionHistoria(valor);
				break;
			}
			//Galeria
			case "DescripcionGaleria[1]":{
				setDescripcionGaleria(valor);
				break;
			}
			default: 
				if(atributo.contains("Unidad")) {
					unidades.add(valor);
				}
				break;
		}
	}

	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}

	public String getActivo() {
		return activo;
	}
	public void setActivo(String activo) {
		this.activo = activo;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getTipoAeronave() {
		return tipoAeronave;
	}
	public void setTipoAeronave(String tipoAeronave) {
		this.tipoAeronave = tipoAeronave;
	}
	
	public String getEsImagenDecorativa() {
		return esImagenDecorativa;
	}

	public void setEsImagenDecorativa(String esImagenDecorativa) {
		this.esImagenDecorativa = esImagenDecorativa;
	}

	public String getUrlImagen() {
		return urlImagen;
	}

	public void setUrlImagen(String urlImagen) {
		this.urlImagen = urlImagen;
	}

	public String getTextoAlternativoImagen() {
		return textoAlternativoImagen;
	}

	public void setTextoAlternativoImagen(String textoAlternativoImagen) {
		this.textoAlternativoImagen = textoAlternativoImagen;
	}

	public String getVelocidadMaxima() {
		return velocidadMaxima;
	}
	public void setVelocidadMaxima(String velocidadMaxima) {
		this.velocidadMaxima = velocidadMaxima;
	}
	public String getVelocidadCrucero() {
		return velocidadCrucero;
	}
	public void setVelocidadCrucero(String velocidadCrucero) {
		this.velocidadCrucero = velocidadCrucero;
	}
	public String getTechoMaximo() {
		return techoMaximo;
	}
	public void setTechoMaximo(String techoMaximo) {
		this.techoMaximo = techoMaximo;
	}
	public String getTituloHistoria() {
		return tituloHistoria;
	}
	public void setTituloHistoria(String tituloHistoria) {
		this.tituloHistoria = tituloHistoria;
	}
	public String getDescripcionHistoria() {
		return descripcionHistoria;
	}
	public void setDescripcionHistoria(String descripcionHistoria) {
		this.descripcionHistoria = descripcionHistoria;
	}
	public String getDescripcionGaleriagetDescripcionGaleria() {
		return descripcionGaleria;
	}
	public void setDescripcionGaleria(String descripcionGaleria) {
		this.descripcionGaleria = descripcionGaleria;
	}
	
	public LinkedList<ImagenGaleria> getImagenes() {
		return imagenes;
	}

	public void setImagenes(LinkedList<ImagenGaleria> imagenes) {
		this.imagenes = imagenes;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	

	public String getDesignacionFabricante() {
		return designacionFabricante;
	}

	public void setDesignacionFabricante(String designacionFabricante) {
		this.designacionFabricante = designacionFabricante;
	}

	public String getDesignacionEA() {
		return designacionEA;
	}

	public void setDesignacionEA(String designacionEA) {
		this.designacionEA = designacionEA;
	}

	public String getMision() {
		return mision;
	}

	public void setMision(String mision) {
		this.mision = mision;
	}

	public String getFechaPrimerVuelo() {
		return fechaPrimerVuelo;
	}

	public void setFechaPrimerVuelo(String fechaPrimerVuelo) {
		this.fechaPrimerVuelo = fechaPrimerVuelo;
	}

	public String getFechaServicioEspana() {
		return fechaServicioEspana;
	}

	public void setFechaServicioEspana(String fechaServicioEspana) {
		this.fechaServicioEspana = fechaServicioEspana;
	}

	public String getPaisOrigen() {
		return paisOrigen;
	}

	public void setPaisOrigen(String paisOrigen) {
		this.paisOrigen = paisOrigen;
	}

	public String getFabricante() {
		return fabricante;
	}

	public void setFabricante(String fabricante) {
		this.fabricante = fabricante;
	}

	public LinkedList<String> getUnidad() {
		return unidades;
	}

	public void setUnidad(LinkedList<String> unidad) {
		this.unidades = unidad;
	}

	public String getLongitud() {
		return longitud;
	}

	public void setLongitud(String longitud) {
		this.longitud = longitud;
	}

	public String getEnvergadura() {
		return envergadura;
	}

	public void setEnvergadura(String envergadura) {
		this.envergadura = envergadura;
	}

	public String getAltura() {
		return altura;
	}

	public void setAltura(String altura) {
		this.altura = altura;
	}

	public String getVacio() {
		return vacio;
	}

	public void setVacio(String vacio) {
		this.vacio = vacio;
	}

	public String getMaximoDespegue() {
		return maximoDespegue;
	}

	public void setMaximoDespegue(String maximoDespegue) {
		this.maximoDespegue = maximoDespegue;
	}

	public String getTiempo() {
		return tiempo;
	}

	public void setTiempo(String tiempo) {
		this.tiempo = tiempo;
	}

	public String getDistancia() {
		return distancia;
	}

	public void setDistancia(String distancia) {
		this.distancia = distancia;
	}

	public String getMotores() {
		return motores;
	}

	public void setMotores(String motores) {
		this.motores = motores;
	}

	public String getReabastecimientoVuelo() {
		return reabastecimientoVuelo;
	}

	public void setReabastecimientoVuelo(String reabastecimientoVuelo) {
		this.reabastecimientoVuelo = reabastecimientoVuelo;
	}

	public String getArmamento() {
		return armamento;
	}

	public void setArmamento(String armamento) {
		this.armamento = armamento;
	}

	public String getVelocidadMaximaEstrellas() {
		return velocidadMaximaEstrellas;
	}

	public void setVelocidadMaximaEstrellas(String velocidadMaximaEstrellas) {
		this.velocidadMaximaEstrellas = velocidadMaximaEstrellas;
	}

	public String getVelocidadCruceroEstrellas() {
		return velocidadCruceroEstrellas;
	}

	public void setVelocidadCruceroEstrellas(String velocidadCruceroEstrellas) {
		this.velocidadCruceroEstrellas = velocidadCruceroEstrellas;
	}

	public String getAutonomiaEstrellas() {
		return autonomiaEstrellas;
	}

	public void setAutonomiaEstrellas(String autonomiaEstrellas) {
		this.autonomiaEstrellas = autonomiaEstrellas;
	}

	public String getTechoMaximoEstrellas() {
		return techoMaximoEstrellas;
	}

	public void setTechoMaximoEstrellas(String techoMaximoEstrellas) {
		this.techoMaximoEstrellas = techoMaximoEstrellas;
	}
	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append("<BR>");
		sb.append("<STRONG>AERONAVE</STRONG>");
		sb.append("<BR>");
		sb.append("Path");
		sb.append(fileName);
		//Descripcion
		sb.append("<BR>");
		sb.append("activo");
		sb.append(activo);
		sb.append("<BR>");
		sb.append("nombre");
		sb.append(nombre);
		sb.append("<BR>");
		sb.append("tipoAeronave");
		sb.append(tipoAeronave);
		sb.append("<BR>");
		sb.append("esImagenDecorativa");
		sb.append(esImagenDecorativa);
		sb.append("<BR>");
		sb.append("urlImagen");
		sb.append(urlImagen);
		sb.append("<BR>");
		sb.append("textoAlternativoImagen");
		sb.append(textoAlternativoImagen);
		//Presentacion
		sb.append("<BR>");
		sb.append("designacionFabricante");
		sb.append(designacionFabricante);
		sb.append("<BR>");
		sb.append("DesignacionEA");
		sb.append(designacionEA);
		sb.append("<BR>");
		sb.append("Mision");
		sb.append(mision);
		sb.append("<BR>");
		sb.append("fechaPrimerVuelo");
		sb.append(fechaPrimerVuelo);
		sb.append("<BR>");
		sb.append("fechaServicioEspana");
		sb.append(fechaServicioEspana);
		sb.append("<BR>");
		sb.append("paisOrigen");
		sb.append(paisOrigen);
		sb.append("<BR>");
		sb.append("fabricante");
		sb.append(fabricante);
		sb.append("<BR>");
		sb.append("Unidades");
		sb.append(unidades.size());
		for(String unidad : unidades) {
			sb.append("<BR>");
			sb.append("unidad");
			sb.append(unidad);
		}
		//Datos técnicos
		sb.append("<BR>");
		sb.append("velocidadMaximaEstrellas");
		sb.append(velocidadMaximaEstrellas);
		sb.append("<BR>");
		sb.append("velocidadCruceroEstrellas");
		sb.append(velocidadCruceroEstrellas);
		sb.append("<BR>");
		sb.append("autonomiaEstrellas");
		sb.append(autonomiaEstrellas);
		sb.append("<BR>");
		sb.append("techoMaximoEstrellas");
		sb.append(techoMaximoEstrellas);
		//Datos detalle
		sb.append("<BR>");
		sb.append("longitud");
		sb.append(longitud);
		sb.append("<BR>");
		sb.append("envergadura");
		sb.append(envergadura);
		sb.append("<BR>");
		sb.append("altura");
		sb.append(altura);
		sb.append("<BR>");
		sb.append("vacio");
		sb.append(vacio);
		sb.append("<BR>");
		sb.append("maximoDespegue");
		sb.append(maximoDespegue);
		sb.append("<BR>");
		sb.append("velocidadMaxima");
		sb.append(velocidadMaxima);
		sb.append("<BR>");
		sb.append("velocidadCrucero");
		sb.append(velocidadCrucero);
		sb.append("<BR>");
		sb.append("distancia");
		sb.append(distancia);
		sb.append("<BR>");
		sb.append("tiempo");
		sb.append(tiempo);
		sb.append("<BR>");
		sb.append("motores");
		sb.append(motores);
		sb.append("<BR>");
		sb.append("techoMaximo");
		sb.append(techoMaximo);
		sb.append("<BR>");
		sb.append("reabastecimientoVuelo");
		sb.append(reabastecimientoVuelo);
		sb.append("<BR>");
		sb.append("Armamento");
		sb.append(armamento);
		//Historia
		sb.append("<BR>");
		sb.append("tituloHistoria");
		sb.append(tituloHistoria);
		sb.append("<BR>");
		sb.append("descripcionHistoria");
		sb.append(descripcionHistoria);
		//Galeria
		sb.append("<BR>");
		sb.append("descripcionGaleria");
		sb.append(descripcionGaleria);
		sb.append("<BR>");
		sb.append("Imagen");
		sb.append(imagenes.size());
		for(ImagenGaleria iG : imagenes) {
			sb.append("<BR>");
			sb.append("<BR>");
			sb.append("urlImagenGaleria");
			sb.append(iG.getUrlImagen());
			sb.append("<BR>");
			sb.append("altImagenGaleria");
			sb.append(iG.getTextoAlternativo());
		}
		return sb.toString();
	}
}
