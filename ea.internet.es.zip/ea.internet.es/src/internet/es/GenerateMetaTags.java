package internet.es;

import org.opencms.file.CmsObject;
import org.opencms.file.CmsResource;
import org.opencms.file.CmsResourceFilter;
import org.opencms.jsp.CmsJspXmlContentBean;
import org.opencms.main.CmsException;
import org.opencms.main.OpenCms;
import org.opencms.xml.content.CmsXmlContent;
import org.opencms.xml.content.CmsXmlContentFactory;
import org.opencms.xml.types.I_CmsXmlContentValue;

public class GenerateMetaTags {
	private String titulo;
	private String descripcion;
	private String imagen;
	
	public GenerateMetaTags(CmsJspXmlContentBean xcbContent2, String path) throws CmsException {
		CmsObject cmsObject2 = xcbContent2.getCmsObject();
		String folder = cmsObject2.getRequestContext().getFolderUri().replace("/", "");
		CmsResourceFilter cmsResourceFilter = null;
		CmsResource recurso = null;
		if(folder.isEmpty()) {
			cmsResourceFilter =  CmsResourceFilter.requireType(OpenCms.getResourceManager().getResourceType("videoPrincipal"));
			recurso= cmsObject2.readResources("/.content/videoPrincipal/",cmsResourceFilter, true).get(0);
		}else if(!path.isEmpty()) {
		    int startIndex = path.indexOf("/internet.es") + "/internet.es".length();
	        if (startIndex != -1 && startIndex < path.length()) {
	            String resultado = path.substring(startIndex);
	            cmsResourceFilter = CmsResourceFilter.requireType(OpenCms.getResourceManager().getResourceType(obtenerRecurso(folder)));
				recurso= cmsObject2.readResource(resultado, cmsResourceFilter);
	        }
		}else {
			cmsResourceFilter = CmsResourceFilter.requireType(OpenCms.getResourceManager().getResourceType(obtenerRecurso(folder)));
			if(folder.equals("AlistatePerfiles-personales")) {
				recurso= cmsObject2.readResource("/.content/persona/persona_00001.xml", cmsResourceFilter);
			}else if(folder.equals("LiderazgoJEMA")){
				recurso= cmsObject2.readResource("/.content/persona/persona_00002.xml", cmsResourceFilter);
			}else{
				recurso = cmsObject2.readResources("/.content/"+obtenerRecurso(folder)+"/", cmsResourceFilter, true).get(0);
			}
		}
		CmsXmlContent xmlContentResource= CmsXmlContentFactory.unmarshal(cmsObject2, cmsObject2.readFile(recurso));
		for(String key : xmlContentResource.getNames(cmsObject2.getRequestContext().getLocale())) {
			I_CmsXmlContentValue atributo = xmlContentResource.getValue(key, cmsObject2.getRequestContext().getLocale());
			if(atributo.getPath().contains("CamposSEO")) {
				if(key.equals("CamposSEO[1]/Titulo[1]")){
					setTitulo(atributo.getStringValue(cmsObject2));
				}else if(key.equals("CamposSEO[1]/Descripcion[1]")){
					setDescripcion(atributo.getStringValue(cmsObject2));
				}else if(key.equals("CamposSEO[1]/Imagen[1]")){
					setImagen(atributo.getStringValue(cmsObject2));
				}
			}
		}
	}

	private String obtenerRecurso(String folderName) {
		String recurso = folderName;
		switch(folderName) {
		case "ActualidadNoticias":
			recurso = "listaNoticiasEA";
			break;
		case "ActualidadNoticiasNoticia":
			recurso = "noticiaEA";
			break;
		case "ActualidadNoticiasListaNoticiasCategoria":
			recurso = "listaNoticiasEA";
			break;
		case "ActualidadRincon-del-aviador":
			recurso = "listaArticulos";
			break;
		case "ActualidadRincon-del-aviadorArticulo":
			recurso = "articulo";
			break;
		case "Aeronaves":
			recurso="listaAeronaves";
			break;
		case "AeronavesAeronave":
			recurso="aeronave";
			break;
		case "Aire-y-EspacioPatrullas":
			recurso = "listaPatrullas";
			break;
		case "Aire-y-EspacioPatrullasPatrulla":
			recurso = "patrulla";
			break;
		case "AlistatePerfiles-personales":
			recurso ="persona";
			break;
		case "LiderazgoJEMA":
			recurso = "persona";
			break;
		case "Unidades":
			recurso = "listadoUnidades";
			break;
		case "UnidadesUnidad":
			recurso = "unidad";
			break;
		case "Cookies":
			recurso = "infoCookies";
			break;
		
		default: 
			break;
		}
		return recurso;
	}
	
	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getImagen() {
		return imagen;
	}

	public void setImagen(String imagen) {
		this.imagen = imagen;
	}
	
	@Override
	public String toString() {
		StringBuilder metaTags = new StringBuilder();
        // Generar las etiquetas meta
		metaTags.append("<meta property=\"og:title\" content=\"").append(titulo).append("\">");
		metaTags.append("<meta property=\"og:description\" content=\"").append(descripcion).append("\">");
		metaTags.append("<meta property=\"og:imagen\" content=\"").append(imagen).append("\">");
        return metaTags.toString();
		
	}
}
