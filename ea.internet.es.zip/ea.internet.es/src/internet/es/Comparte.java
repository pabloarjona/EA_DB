package internet.es;

import java.util.LinkedList;
import java.util.Locale;

import org.opencms.file.CmsObject;
import org.opencms.file.CmsResource;
import org.opencms.main.CmsException;
import org.opencms.xml.content.CmsXmlContent;
import org.opencms.xml.content.CmsXmlContentFactory;
import org.opencms.xml.types.I_CmsXmlContentValue;

public class Comparte {
	
	//Atributos
	private String tituloComparte;
	private LinkedList<Imagen>  imagenesComparte;
	
	private CmsObject cmsObject;
	private CmsResource recursoComparte;
	private Locale locale;
	
	public Comparte(CmsObject cmsObject, CmsResource recursoComparte) throws CmsException {
		super();
		this.cmsObject = cmsObject;
		this.recursoComparte = recursoComparte;
		this.locale = cmsObject.getRequestContext().getLocale();
		asignarAtributos();
	}
	
	private void asignarAtributos() throws CmsException{
		CmsXmlContent xmlContentComparte= CmsXmlContentFactory.unmarshal(cmsObject, cmsObject.readFile(recursoComparte));
		for(String key : xmlContentComparte.getNames(locale)) {
			I_CmsXmlContentValue  atributo = xmlContentComparte.getValue(key, locale);
			if(atributo.getPath().contains("Comparte[1]/Titulo[1]")) {
				setTituloComparte(atributo.getStringValue(cmsObject));
			}else if(atributo.getPath().contains("Imagen")){
				setValoresAtributo(xmlContentComparte, atributo);
			}
		}
	}
	
	private void setValoresAtributo(CmsXmlContent xmlContent, I_CmsXmlContentValue atributo) {
		String urlImagen="", textoAlternativo="", enlace="";
		int cont=0;
		for(I_CmsXmlContentValue subvalor : xmlContent.getAllSimpleSubValues(atributo)) {
			I_CmsXmlContentValue subAtributo = xmlContent.getValue(subvalor.getPath(), locale);
			if(subvalor.getPath().contains("UrlImagen")) {
				urlImagen = subAtributo.getStringValue(cmsObject);
				cont++;
			}else if(subvalor.getPath().contains("TextoAlternativo")) {
				textoAlternativo=subAtributo.getStringValue(cmsObject);
				cont++;
			}else if(subvalor.getPath().contains("Enlace")) {
				enlace = subAtributo.getStringValue(cmsObject);
				cont++;
			}
			if(cont==3) {
				imagenesComparte.add(new Imagen(urlImagen, textoAlternativo, enlace));
				cont=0;
			}
		}
	}
	
	public String getTituloComparte() {
		return tituloComparte;
	}

	public void setTituloComparte(String tituloComparte) {
		this.tituloComparte = tituloComparte;
	}
	

	public LinkedList<Imagen> getImagenesComparte() {
		return imagenesComparte;
	}

	public void setImagenesComparte(LinkedList<Imagen> imagenesComparte) {
		this.imagenesComparte = imagenesComparte;
	}
	
}

