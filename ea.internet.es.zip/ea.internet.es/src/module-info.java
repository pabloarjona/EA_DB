/**
 * 
 */
/**
 * @author parjrui
 *
 */
module internet.es {
	requires opencms;
}