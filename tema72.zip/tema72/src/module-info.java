/**
 * @author parjrui
 *
 */
module tema72 {
	exports es;
	exports ex;
	//permitir hacer reflexion
	opens es;
	provides ex.Cucable with es.CucableImpl;
}