package ex;

public interface Cucable {

	int contador();
}
