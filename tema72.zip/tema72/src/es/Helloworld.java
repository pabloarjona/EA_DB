package es;

public class Helloworld {
	public static void holaMundo() {
		System.out.println("Hola mundo");
	}


}
