package es;

import java.util.Random;

import ex.Cucable;

public class CucableImpl implements Cucable{

	@Override
	public int contador() {
		return new Random().nextInt();
	}
}
