package es;

import ex.ServiceSintomas;

public class ServiceSintomasImpl implements ServiceSintomas{

	public boolean meDuele() {
		System.out.println("Me duele todo");
		return true;
	}
}
