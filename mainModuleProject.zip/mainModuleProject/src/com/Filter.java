package com;

import java.util.ServiceLoader;

import es.HelloWorld;
import services.Service1;
public class Filter {

	public static void main(String[] args) {
		System.out.println("Main de la clase filter");
		HelloWorld.holaMundo();
		Double n = ServiceLoader.load(Service1.class).findFirst().get().contador();
		System.out.println(n);
	}
}
