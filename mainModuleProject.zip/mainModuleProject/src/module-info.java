/**
 * @author parjrui
 *
 */
module mainModuleProject { 
	requires mainModuleProject2;
	uses services.Service1;
}