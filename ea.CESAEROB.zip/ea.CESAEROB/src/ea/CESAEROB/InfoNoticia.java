package ea.CESAEROB;

import java.util.Date;
import java.util.Locale;
import org.opencms.file.CmsObject;
import org.opencms.file.CmsResource;
import org.opencms.main.CmsException;
import org.opencms.xml.content.CmsXmlContent;
import org.opencms.xml.content.CmsXmlContentFactory;
import org.opencms.xml.types.CmsXmlNestedContentDefinition;
import org.opencms.xml.types.I_CmsXmlContentValue;

public class InfoNoticia{
	
	private String fecha;
	private Date fechaDate;
	private String titulo;
	private String fotoEsImagenDecorativa;
	private String fotoEnlace;
	private String fotoTextoAlt;
	private String resumen;
	
	private String filename;
	private CmsObject cmsObject;
	private CmsResource recurso;
	private Locale locale;
	private String id;
	
	public InfoNoticia(CmsObject cmsObject, CmsResource recurso) throws CmsException {
		super();
		this.cmsObject = cmsObject;
		this.recurso = recurso;
		this.locale = this.cmsObject.getRequestContext().getLocale();
		this.filename = this.recurso.getRootPath();
		asignarAtributos();
	}

	private void asignarAtributos() throws CmsException{
		CmsXmlContent xmlContentAeronave= CmsXmlContentFactory.unmarshal(cmsObject, cmsObject.readFile(recurso));
		this.id = recurso.getStructureId().getStringValue();
		for(String key: xmlContentAeronave.getNames(locale)) {
			I_CmsXmlContentValue atributo = xmlContentAeronave.getValue(key, locale);
			if(!atributo.getClass().equals(CmsXmlNestedContentDefinition.class)) {
				setValorAtributo(key, atributo.getStringValue(cmsObject));
			}
		}
	}
	
	private void setValorAtributo(String atributo, String valor) {
		switch(atributo) {
		case "Fecha[1]":{
			setFecha(valor);
			setFechaDate(new Date(Long.parseLong(valor)));
			break;
		}
		case "Titulo[1]":{
			setTitulo(valor);
			break;
		}
		case "Foto[1]/EsImagenDecorativa[1]":{
			setFotoEsImagenDecorativa(valor);
			break;
		}
		case "Foto[1]/Enlace[1]":{
			setFotoEnlace(valor);
			break;
		}
		case "Foto[1]/TextoAlternativo[1]":{
			setFotoTextoAlt(valor);
			break;
		}
		case "Resumen[1]":{
			setResumen(valor);
			break;
		}
		}
	}
	
	public Date getFechaDate() {
		return fechaDate;
	}

	public void setFechaDate(Date fechaDate) {
		this.fechaDate = fechaDate;
	}

	public String getFecha() {
		return fecha;
	}

	public void setFecha(String fecha) {
		this.fecha = fecha;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	
	public String getFotoEsImagenDecorativa() {
		return fotoEsImagenDecorativa;
	}

	public void setFotoEsImagenDecorativa(String fotoEsImagenDecorativa) {
		this.fotoEsImagenDecorativa = fotoEsImagenDecorativa;
	}

	public String getFotoEnlace() {
		return fotoEnlace;
	}

	public void setFotoEnlace(String fotoEnlace) {
		this.fotoEnlace = fotoEnlace;
	}

	public String getFotoTextoAlt() {
		return fotoTextoAlt;
	}

	public void setFotoTextoAlt(String fotoTextoAlt) {
		this.fotoTextoAlt = fotoTextoAlt;
	}

	public String getResumen() {
		return resumen;
	}

	public void setResumen(String resumen) {
		this.resumen = resumen;
	}

	public String getFilename() {
		return filename;
	}

	public void setFilename(String filename) {
		this.filename = filename;
	}

	@Override
	public String toString() {
		return "InfoNoticia [fecha=" + fecha + ", fechaDate=" + fechaDate + ", titulo=" + titulo
				+ ", fotoEsImagenDecorativa=" + fotoEsImagenDecorativa + ", fotoEnlace=" + fotoEnlace
				+ ", fotoTextoAlt=" + fotoTextoAlt + ", resumen=" + resumen + ", filename=" + filename + ", cmsObject="
				+ cmsObject + ", recurso=" + recurso + ", locale=" + locale + ", id=" + id + "]";
	}



	
}