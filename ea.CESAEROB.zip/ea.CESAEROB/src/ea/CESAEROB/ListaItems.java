package ea.CESAEROB;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

import org.opencms.file.CmsObject;
import org.opencms.file.CmsResource;
import org.opencms.file.CmsResourceFilter;
import org.opencms.main.OpenCms;

public class ListaItems{
	CmsObject cmsObject;
	String pathContent;
	String tipoRecurso = "infoNoticia";
	List<CmsResource> listaRecursos;
	LinkedList<InfoNoticia> listaInfoNoticias;
	
	public ListaItems(CmsObject cmsObject, String pathContent) throws Exception{
		super();
		this.pathContent = pathContent;
		this.cmsObject = cmsObject;
		getItems();
	}
	
	public void getItems() throws Exception{
		if(this.listaInfoNoticias == null){
			LinkedList<InfoNoticia> listaItemsNew = new LinkedList<>();
			this.listaRecursos = listaRecursos == null 
					? cmsObject.readResources(this.pathContent,CmsResourceFilter.requireType(OpenCms.getResourceManager().getResourceType(tipoRecurso)), true) 
					: listaRecursos;
			for (CmsResource recurso : this.listaRecursos) {
				listaItemsNew.add(new InfoNoticia (this.cmsObject, recurso));
			}
			setListaInfoNoticias(listaItemsNew);
		}
	}
	
	public LinkedList<InfoNoticia> getListaInfoNoticias() {
		Collections.sort(this.listaInfoNoticias, (n1,n2) -> n2.getFechaDate().compareTo(n1.getFechaDate()));
		return this.listaInfoNoticias;
	}
	public void setListaInfoNoticias(LinkedList<InfoNoticia> listaInfoNoticias) {
		this.listaInfoNoticias = listaInfoNoticias;
	}
	
}