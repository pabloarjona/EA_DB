package documentosASA;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;

import org.opencms.file.CmsFile;
import org.opencms.file.CmsObject;
import org.opencms.file.CmsResource;
import org.opencms.main.OpenCms;
import org.opencms.xml.content.CmsXmlContent;
import org.opencms.xml.content.CmsXmlContentFactory;
import org.opencms.xml.types.I_CmsXmlContentValue;

public class DocumentoOpencms{
	private String id;
	private String continente;
	private String pais;
	private String resourceId;
	private String pathDocumento;
	private static String DE_ESPANIA_OTRO_PAIS = "De España a otro país";
	private static String DE_OTRO_PAIS_A_ESPANIA = "De otro país a España";
	private static String SIN_CATALOGAR = "Sin Catalogar";
	private static String SIN_FECHA_EN_VIGOR = "Sin fecha en vigor";
	ArrayList<Anexo> anexos = new ArrayList<Anexo>();
	
	public DocumentoOpencms() {
		super();
		anexos = new ArrayList<Anexo>();
	}
	public DocumentoOpencms(String id, String continente) {
		this.id = id;
		this.continente = continente;
		anexos = new ArrayList<Anexo>();
	}
	
	public DocumentoOpencms(String id, String continente, String pais) {
		this.id = id;
		this.continente = continente;
		this.pais = pais;
	}

	public DocumentoOpencms(String id, String continente, String pais, String pathDocumento) {
		this.id = id;
		this.continente = continente;
		this.pais = pais;
		this.pathDocumento = pathDocumento;
	}
	

	
	public DocumentoOpencms(CmsResource recurso, CmsObject cmsObject) throws Exception {
		this.resourceId = recurso.getResourceId().toString();
		CmsFile fileRecurso = cmsObject.readFile(recurso);
		CmsXmlContent xmlContentRecurso =  CmsXmlContentFactory.unmarshal(cmsObject, fileRecurso);
		String mySite = cmsObject.getRequestContext().getSiteRoot();
		cmsObject.getRequestContext().setSiteRoot("/"); //Envia al site del root
		OpenCms.getPublishManager().publishResource(cmsObject, recurso.getRootPath());
		cmsObject.getRequestContext().setSiteRoot(mySite);
		
		Locale idioma = cmsObject.getRequestContext().getLocale();
		List<String> keys =  xmlContentRecurso.getNames(idioma);
		int i = 1;
		I_CmsXmlContentValue value;
		Anexo anexo;
		for(String key :keys){
			value = xmlContentRecurso.getValue(key,idioma);
			if(value != null) {
				if(!value.getPath().contains("Anexo")) {
					
					setValueCampo(key, value.getStringValue(cmsObject));
				}
				else{
					anexo = new Anexo(value.getDocument().getValue("Titulo",idioma).getStringValue(cmsObject), value.getDocument().getValue("Enlace",idioma).getStringValue(cmsObject), value.getDocument().getValue("Fecha",idioma).getStringValue(cmsObject), value.getDocument().getValue("OrigenDestino",idioma).getStringValue(cmsObject));
				}
			}
			i++;
		}
	}
	
	public ArrayList<Anexo> getAnexos() {
		return anexos;
	}

	public void setAnexos(ArrayList<Anexo> anexos) {
		this.anexos = anexos;
	}
	
	public String getResourceId() {
		return resourceId;
	}
	
	public void setResourceId(String resourceId) {
		this.resourceId = resourceId;
	}
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getContinente() {
		return continente;
	}

	public void setContinente(String continente) {
		this.continente = continente;
	}

	public String getPais() {
		return pais;
	}

	public void setPais(String pais) {
		this.pais = pais;
	}

	public String getPathDocumento() {
		return pathDocumento;
	}

	public void setPathDocumento(String pathDocumento) {
		this.pathDocumento = pathDocumento;
	}
	
	public void addAnexo(Anexo anexo){
		anexos.add(anexo);
	}
	
	public void setValueCampo(String name, String valor){
		if(name.toLowerCase().contains("id".toLowerCase()))
			setId(valor);
		else if(name.toLowerCase().contains("continente".toLowerCase()))
			setContinente(valor);
		else if(name.toLowerCase().contains("pais".toLowerCase()) || name.toLowerCase().contains("país".toLowerCase()))
			setPais(valor);
	}
	
	public String getValueCampo(String name){

		if(name.toLowerCase().contains("id".toLowerCase()))
			return id;
		else if(name.toLowerCase().contains("continente".toLowerCase()))
			return continente;
		else if(name.toLowerCase().contains("pais".toLowerCase()) || name.toLowerCase().contains("país".toLowerCase()))
			return pais;
		else
			return "";
	}
	String titulosAnexos="";
	public String getTitulosAnexos(){
		for (Anexo anexo: anexos){
			titulosAnexos += anexo.getNombre();
		}
		return titulosAnexos;
	}
	String titulosDocumentosAnexos="";
	public String getTitulosDocumentosAnexos(){
		
		for (Anexo anexo: anexos){
			titulosDocumentosAnexos += "<p><li><a href='#'>"+anexo.getNombre()+"</a></li></p>";
		}
		return titulosDocumentosAnexos;
	}
	
	public static LinkedHashMap<String, LinkedHashMap<String, ArrayList<Anexo>>> getAnexosPorOrigenDestinoYFecha(ArrayList<Anexo> anexos){
		ArrayList<Anexo> deOtroPaisAEspana = new ArrayList<>(), deEspanaAOtroPais = new ArrayList<>(), sinCatalogar = new ArrayList<>();
		LinkedHashMap<String, ArrayList<Anexo>> salida = new LinkedHashMap<>();
		for (Anexo anexo: anexos) {
			if(anexo.getOrigenDestino()== null) sinCatalogar.add(anexo);
			else if(anexo.getOrigenDestino().equals(DE_OTRO_PAIS_A_ESPANIA))  deOtroPaisAEspana.add(anexo);
			else if(anexo.getOrigenDestino().equals(DE_ESPANIA_OTRO_PAIS)) deEspanaAOtroPais.add(anexo);
			else sinCatalogar.add(anexo);
		}
		if(!deEspanaAOtroPais.isEmpty()) {
			salida.put(DE_ESPANIA_OTRO_PAIS, deEspanaAOtroPais);
		}
		if(!deOtroPaisAEspana.isEmpty()) {
			salida.put(DE_OTRO_PAIS_A_ESPANIA, deOtroPaisAEspana);
		}
		if(!sinCatalogar.isEmpty()) {
			salida.put(SIN_CATALOGAR, sinCatalogar);
		}
		LinkedHashMap<String, LinkedHashMap<String, ArrayList<Anexo>>> salidaFinal = new LinkedHashMap<>();
		for(String key : salida.keySet()) {
			ArrayList<Anexo> listaAnexos = salida.get(key);
			LinkedHashMap<String, ArrayList<Anexo>> anexosPorFechas = getAnexosPorFecha(listaAnexos);
			salidaFinal.put(key, anexosPorFechas);
		}
		return salidaFinal;
	}
	
	public static LinkedHashMap<String, ArrayList<Anexo>> getAnexosPorFecha(ArrayList<Anexo> anexos){
		LinkedHashMap<String, ArrayList<Anexo>> salida = new LinkedHashMap<String, ArrayList<Anexo>>();
        ArrayList<Anexo> anexosOrdenados2 = null;
        for (Anexo anexo : anexos) {
            boolean anadido = false;
            //Recorre el hashmap para ver si alguno tiene misma fecha
            for(String key : salida.keySet()) {
                if(key.equals(anexo.getFecha())){
                    salida.get(key).add(anexo);
                    Collections.sort(salida.get(key), new SortByNombre());
                    anadido = true;
                }
            }
            if(!anadido){
                anexosOrdenados2 = new ArrayList<Anexo>();
                anexosOrdenados2.add(anexo);
                salida.put(anexo.getFecha(), anexosOrdenados2);
            }
        }
		List<String> lista= new ArrayList<>(salida.keySet());
		Collections.sort(lista, new SortByDate());
		LinkedHashMap<String, ArrayList<Anexo>> linked = new LinkedHashMap<>();
		//linked.putAll(salida);
		for(String key : lista) {
			if(key.equals("")) {
				ArrayList<Anexo> listaSinFecha = salida.get(key);
				linked.put(SIN_FECHA_EN_VIGOR, listaSinFecha);
			}else {
				linked.put(key, salida.get(key));
			}
		}
        return linked;
    }
}

class SortByNombre implements Comparator<Anexo>{
	public int compare(Anexo a, Anexo b) {
		return a.getNombre().compareTo(b.getNombre());
	}
}

class SortByDate implements Comparator<String>{
	public static boolean isNumeric(String input) {
		boolean result;
		try {
			Integer.parseInt(input);
			result= true;
		}catch(NumberFormatException excepcion){
			result=false;
		}
		return result;
	}

	@Override
	public int compare(String a, String b) {
		int fecha1,fecha2;
		if(!isNumeric(a)) {  fecha1=-1; }
		else fecha1 =Integer.parseInt(a); 
		if(!isNumeric(b)) { fecha2=-1; }
		else fecha2=Integer.parseInt(b); 
		return  fecha2 - fecha1;
	}
}
