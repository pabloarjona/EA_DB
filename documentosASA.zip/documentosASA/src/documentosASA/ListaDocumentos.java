package documentosASA;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

public class ListaDocumentos extends ArrayList
{
	private List<DocumentoOpencms> listaDocumentos = new ArrayList<>();
	public ListaDocumentos(List<DocumentoOpencms> lista){
		super();
		listaDocumentos=lista;
	}
	public  ArrayList<String> getContinentes(){
		ArrayList<String> continentes = new ArrayList<>();
		boolean encontrado = false;
		for (DocumentoOpencms documento: listaDocumentos){
			encontrado = false;
			for (String continente:continentes)
			{
				if(continente.equals(documento.getContinente())){
					encontrado = true;
				}
			}
			if(!encontrado){
				continentes.add(documento.getContinente());
			}
		}
		return continentes;
	}
	
	public HashMap<String, ArrayList<DocumentoOpencms>> getListaPorContinentes(){

		HashMap<String, ArrayList<DocumentoOpencms>> listasPorContinentes = new HashMap<String, ArrayList<DocumentoOpencms>>();
		ArrayList<String> continentes = getContinentes();
		String continenteDoc = "";
		
		ArrayList<DocumentoOpencms> listaPorContinente = new ArrayList<>();
		
		for (String continente: continentes){
			
			listaPorContinente = new ArrayList<>();
			
			for (DocumentoOpencms documento: listaDocumentos){
				continenteDoc = documento.getContinente();
				
				if(continenteDoc.equals(continente)){
					listaPorContinente.add(documento);
				}
			}
			
			listasPorContinentes.put(continente,listaPorContinente);
		}
		
		return  listasPorContinentes;
	}
	public ArrayList<String> getPaisesOrdenados(String continente){
		ArrayList<String> paisesOrdenados = new ArrayList<>();
		ArrayList<DocumentoOpencms> listaDocumentos =getListaPorContinentes().get(continente);
		for(DocumentoOpencms documento: listaDocumentos){
			paisesOrdenados.add(documento.getPais());
		}
		Collections.sort(paisesOrdenados);
		return paisesOrdenados;
		
	}
	public ArrayList<DocumentoOpencms> getDocumentosOrdenados(String continente){
		ArrayList<String> paisesOrdenados = getPaisesOrdenados(continente);
		ArrayList<DocumentoOpencms> listaDocumentos =getListaPorContinentes().get(continente);
		ArrayList<DocumentoOpencms> listaDocumentosOrdenados = new ArrayList<>();
		for(String pais:paisesOrdenados){
			for(DocumentoOpencms documento: listaDocumentos){
				if(pais.equals(documento.getPais())){
					listaDocumentosOrdenados.add(documento);
					break;
				}
			}
		}
		return listaDocumentosOrdenados;
		
	}
	public HashMap<String, ArrayList<DocumentoOpencms>> getListaOrdenadaPorContinentes(){
		HashMap<String, ArrayList<DocumentoOpencms>> listaDocumentosPorContinentes = getListaPorContinentes();
		
		for (String clave:listaDocumentosPorContinentes.keySet()) {
			ArrayList<DocumentoOpencms> listaDocumentosPorContinente = getDocumentosOrdenados(clave);
			listaDocumentosPorContinentes.put(clave, listaDocumentosPorContinente);
		}
		return listaDocumentosPorContinentes;
	}
	
	public ArrayList<DocumentoOpencms> getListaDocumentosPorPaisYContinente(String continente, String pais){
		HashMap<String, ArrayList<DocumentoOpencms>> listaDocumentos = getListaOrdenadaPorContinentes();
		ArrayList<DocumentoOpencms> listaDocumentosContinente = (ArrayList<DocumentoOpencms>) listaDocumentos.get(continente).stream().filter(x -> x.getPais() == pais).collect(Collectors.toList());
		return listaDocumentosContinente;
	}
	
	//public HashMap<String, ArrayList<Anexo>> getAnexosPorOrigenDestinoListado(ArrayList<Anexos>)
	
}


