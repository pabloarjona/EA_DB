package documentosASA;

public class Anexo{
	private String nombre;
	private String fecha;
	private String origenDestino;
	private String link;
	
	public Anexo() {
		super();
	}
	
	public Anexo(String nombre, String link, String fecha, String origenDestino) {
		this.nombre = nombre;
		this.link = link;
		this.fecha =fecha;
		this.origenDestino = origenDestino;
	}
	
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getLink() {
		return link;
	}

	public void setLink(String link) {
		this.link = link;
	}
	
	public String getFecha() {
		return fecha;
	}
	
	public void setFecha(String fecha) {
		this.fecha = fecha;
	}
	
	public String getOrigenDestino() {
		return origenDestino;
	}
	
	public void setOrigenDestino(String origenDestino) {
		this.origenDestino = origenDestino;
	}
}
