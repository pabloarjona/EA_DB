package documentosASA;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

import org.opencms.file.CmsObject;
import org.opencms.file.CmsResource;
import org.opencms.jsp.CmsJspTagContentLoad;
import org.opencms.jsp.CmsJspXmlContentBean;
import org.opencms.util.CmsUUID;

public class Main {
	
	public void prueba() {
		CmsJspXmlContentBean xcbContent = new CmsJspXmlContentBean(pageContext, request, response);
		CmsObject cmsObject = xcbContent.getCmsObject();

		CmsJspTagContentLoad contentLoad = (CmsJspTagContentLoad) xcbContent.contentload(
				"allInFolder",
				"/.content/documentoConceptoEmpleoOperativo/.xml|documentoConceptoEmpleoOperativo",
				false);
		List<CmsResource> listaDocumentosRecursos = contentLoad.getCollectorResult();
	}
	
	public static void main(String[] args) {
		ArrayList<Anexo> prueba = new ArrayList<>();
		Anexo anexo = new Anexo("1_esp-per-2023.pdf","/.galleries/files/documento/865870E8F439D34DC1256FDD0036F16C/1_esp-per-2023.pdf", "2023", "De otro país a España");
		Anexo anexo1 = new Anexo("1_nato-ram-per-2022-russia-ukraine-conflict.pdf","/.galleries/files/documento/865870E8F439D34DC1256FDD0036F16C/1_nato-ram-per-2022-russia-ukraine-conflict.pdf", "2022", "De otro país a España");
		Anexo anexo2 = new Anexo("2018-ALEMANIA-DIC-ES.pdf","/.galleries/files/documento/865870E8F439D34DC1256FDD0036F16C/2018-ALEMANIA-DIC-ES.pdf", "2018", "De otro país a España");
		Anexo anexo3 = new Anexo("2018-ES-DIC-ALEMANIA.pdf","/.galleries/files/documento/865870E8F439D34DC1256FDD0036F16C/2018-ES-DIC-ALEMANIA.pdf", "2019", "De otro país a España");
		Anexo anexo4 = new Anexo("2019-ALEMANIA-DIC-ES.pdf","/.galleries/files/documento/865870E8F439D34DC1256FDD0036F16C/2019-ALEMANIA-DIC-ES.pdf", "2019", "De España a otro país");
		Anexo anexo5 = new Anexo("2019-ES-DIC-ALEMANIA.pdf","/.galleries/files/documento/865870E8F439D34DC1256FDD0036F16C/2019-ES-DIC-ALEMANIA.pdf", "2019", "De otro país a España");
		Anexo anexo6 = new Anexo("2020-ALEMANIA-DIC-ES.pdf","/.galleries/files/documento/865870E8F439D34DC1256FDD0036F16C/2020-ALEMANIA-DIC-ES.pdf", "2020", "De España a otro país");
		Anexo anexo7 = new Anexo("2020-ES-DIC-ALEMANIA.pdf","/.galleries/files/documento/865870E8F439D34DC1256FDD0036F16C/2020-ES-DIC-ALEMANIA.pdf", "2019", "De España a otro país");
		Anexo anexo8 = new Anexo("2021-ALEMANIA-DIC-ES.pdf","/.galleries/files/documento/865870E8F439D34DC1256FDD0036F16C/2021-ALEMANIA-DIC-ES.pdf", "2019", "De España a otro país");
		Anexo anexo9 = new Anexo("2_221212_permanent-exemption-esp-per-23-426-0016-dg.pdf","/.galleries/files/documento/865870E8F439D34DC1256FDD0036F16C/2_221212_permanent-exemption-esp-per-23-426-0016-dg.pdf", "2019", "De España a otro país");
		Anexo anexo10 = new Anexo("2_traduccion-de-cortesia-sv-russia-ukraine-conflict.docx","/.galleries/files/documento/865870E8F439D34DC1256FDD0036F16C/2_traduccion-de-cortesia-sv-russia-ukraine-conflict.docx", "2019", "De España a otro país");
		Anexo anexo11 = new Anexo("3_20221215_traduccion_esp_per-_2023.docx","/.galleries/files/documento/865870E8F439D34DC1256FDD0036F16C/3_20221215_traduccion_esp_per-_2023.docx", "2019", "De España a otro país");
		Anexo anexo12 = new Anexo("70200000-E-22-015325-Rm-RV-Trasportfluge-Russland-Ukraine-Konflikt-im-Rahme.PDF","/.galleries/files/documento/865870E8F439D34DC1256FDD0036F16C/70200000-E-22-015325-Rm-RV-Trasportfluge-Russland-Ukraine-Konflikt-im-Rahme.PDF", "2019", "De España a otro país");
		Anexo anexo13 = new Anexo("ADA-ALEMANIA-A-ESPANA-2022.pdf", "/.galleries/files/documento/865870E8F439D34DC1256FDD0036F16C/ADA-ALEMANIA-A-ESPANA-2022.pdf", "2023", "De España a otro país");
		Anexo anexo14 = new Anexo("ADA-ALEMANIA-A-ESPANA-2023_1.docx.pdf", "/.galleries/files/documento/865870E8F439D34DC1256FDD0036F16C/ADA-ALEMANIA-A-ESPANA-2023_1.docx.pdf", "2023", "De España a otro país");
		Anexo anexo15 = new Anexo("ADA-ALEMANIA-A-ESPANA-2023_2.pdf", "/.galleries/files/documento/865870E8F439D34DC1256FDD0036F16C/ADA-ALEMANIA-A-ESPANA-2023_2.pdf", "2019", "De España a otro país");
		Anexo anexo16 = new Anexo("ADA-ESPANA-A-ALEMANIA-2021.pdf","/.galleries/files/documento/865870E8F439D34DC1256FDD0036F16C/ADA-ESPANA-A-ALEMANIA-2021.pdf", "2019","De otro país a España");
		Anexo anexo17 = new Anexo("ALEMANIA-DG.pdf", "/.galleries/files/documento/865870E8F439D34DC1256FDD0036F16C/ALEMANIA-DG.pdf", "2019", "De España a otro país");
		Anexo anexo18 = new Anexo("EJEMPLO-FORMULARIO-DANGEROUS-GOODS-FORBIDEN.pdf", "/.galleries/files/documento/865870E8F439D34DC1256FDD0036F16C/EJEMPLO-FORMULARIO-DANGEROUS-GOODS-FORBIDEN.pdf", "2019", "De España a otro país");
		Anexo anexo19 = new Anexo("Ejemplo-Formulario-rellenado.pdf", "/.galleries/files/documento/865870E8F439D34DC1256FDD0036F16C/Ejemplo-Formulario-rellenado.pdf", "2019", "De otro país a España");
		Anexo anexo20 = new Anexo("FORMULARIO-Dangerous-Goods-.doc", "/.galleries/files/documento/865870E8F439D34DC1256FDD0036F16C/FORMULARIO-Dangerous-Goods-.doc", "2019", "De otro país a España");
		Anexo anexo21 = new Anexo("FORMULARIO-DANGEROUS-GOODS-ALEMANIA.dotx", "/.galleries/files/documento/865870E8F439D34DC1256FDD0036F16C/FORMULARIO-DANGEROUS-GOODS-ALEMANIA.dotx", "2019", "De España a otro país");
		Anexo anexo22 = new Anexo("INCIDENCIAS-EN-LA-AGREGADURIA-DE-BERLIN-DE-INFO-A-TODAS-LAS-UNIDADES.pdf", "/.galleries/files/documento/865870E8F439D34DC1256FDD0036F16C/INCIDENCIAS-EN-LA-AGREGADURIA-DE-BERLIN-DE-INFO-A-TODAS-LAS-UNIDADES.pdf", "", "De España a otro país");
		Anexo anexo23 = new Anexo("Instrucciones-formulario.doc", "/.galleries/files/documento/865870E8F439D34DC1256FDD0036F16C/Instrucciones-formulario.doc", "", "De España a otro país");
		Anexo anexo24 = new Anexo("Instrucciones-formulario_723_08_04_2005-12_00_07_BDE.doc", "/.galleries/files/documento/865870E8F439D34DC1256FDD0036F16C/Instrucciones-formulario_723_08_04_2005-12_00_07_BDE.doc", "", "De España a otro país");
		Anexo anexo25 = new Anexo("Nota-Verbal-160_2021.pdf", "/.galleries/files/documento/865870E8F439D34DC1256FDD0036F16C/Nota-Verbal-160_2021.pdf", "2019", "De España a otro país");
		Anexo anexo26 = new Anexo("report_2022-ALEMANIA-COD-ES.pdf", "/.galleries/files/documento/865870E8F439D34DC1256FDD0036F16C/report_2022-ALEMANIA-COD-ES.pdf", "2019", "De España a otro país");
		prueba.add(anexo);prueba.add(anexo1);prueba.add(anexo2);prueba.add(anexo3);prueba.add(anexo4);prueba.add(anexo5);
		prueba.add(anexo6);prueba.add(anexo7);prueba.add(anexo8);prueba.add(anexo9);prueba.add(anexo10);prueba.add(anexo11);
		prueba.add(anexo12);prueba.add(anexo13);prueba.add(anexo14);prueba.add(anexo15);prueba.add(anexo16);prueba.add(anexo17);
		prueba.add(anexo18);prueba.add(anexo19);prueba.add(anexo20);prueba.add(anexo21);prueba.add(anexo22);prueba.add(anexo23);
		
		LinkedHashMap<String, LinkedHashMap<String, ArrayList<Anexo>>> anexosPorOrigenYDestinoYAnos = DocumentoOpencms.getAnexosPorOrigenDestinoYFecha(prueba);
		for(String key : anexosPorOrigenYDestinoYAnos.keySet()) {		
			System.out.println(key.toUpperCase());
			System.out.println();
			for(String key2 : anexosPorOrigenYDestinoYAnos.get(key).keySet()) {
				System.out.println(key2);
				System.out.println();
				for (Anexo e : anexosPorOrigenYDestinoYAnos.get(key).get(key2)) {
					System.out.println(e.getNombre());	
					System.out.println();
				}
			}
		}
		System.out.println(anexosPorOrigenYDestinoYAnos.size());
			
	}
}
