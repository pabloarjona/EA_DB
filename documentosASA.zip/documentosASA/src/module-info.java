/**
 * 
 */
/**
 * @author parjrui
 *
 */
module documentosASA {
	requires opencms;
}