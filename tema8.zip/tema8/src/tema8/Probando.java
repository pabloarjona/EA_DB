package tema8;

import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Probando {
	static int n = 0;
	static Lock l = new ReentrantLock();
	
	public static void main(String[] args) throws InterruptedException, ExecutionException{
		//Cambiar xxx aquí
		Supplier<Callable<Integer>> sci = () -> Probando::xx;
		
		List<Callable<Integer>> l =Stream.generate(sci).limit(100).collect(Collectors.toList());
		
		ExecutorService es = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors());
		
		l.forEach(x-> es.submit(x));
		
		Thread.sleep(1000);
		
		System.out.println("total=> "+ n);
		
		es.shutdown();
	}
	//synchronized no deja el metodo XXX libre hasta que no este libre
	public static int xxx() {
		System.out.println(n);
		return ++n;
	}
	
	public static int xx() {
		if(l.tryLock()) {
			l.lock();
			System.out.println(n);
			++n;
			l.unlock();
		}else {
			System.out.println("estoy bloqueado");
		}
		return n;
	}
	//Hace lo mismo que el synchronized
	public static int x() {
		l.lock();
		System.out.println(n);
		++n;
		l.unlock();
		return n;
	}
	
}
