package tema8;

import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.stream.IntStream;

public class ExamenNoCompilan {

	private static Lock wc = new ReentrantLock();
	
	//Error línea 3 -> hay que usar runnable
	public static void Ejercicio1Examen() {
		ScheduledExecutorService service = Executors.newSingleThreadScheduledExecutor();
		//service.scheduleWithFixedDelay(()-> {System.out.print("+"); return 22;}, 01, 11, TimeUnit.SECONDS);
	}
	
	//No Compila-> falla línea 3
	public void Ejercicio3Examen() {
		try {
			//if(wc.lock(5, TimeUnit.MINUTES)) {
				System.out.println("ohhhhh yeaahhh");
				wc.lock();
			//}
		}catch( /*InterruptedException e*/){
			
		}
	}
	
	static int contador = 0;
	//No compila -> Falla en el método add línea 4
	public void Ejecicio4Examen() {
		final ExecutorService service = Executors.newSingleThreadExecutor();
		try {
			var r = new ArrayList<Future<?>>();
			IntStream.iterate(0,  i -> i +1).limit(5).forEach(i -> r.add(service.execute(() -> { ++contador; })));
			for(Future<?> result : r) {
				System.out.println(result.get() + " ");
			}
		}finally{
			if(service != null) {
				service.shutdown();
			}
		}
	}
	
	public static void main(String[] args) throws InterruptedException {
		
	}
	
}
