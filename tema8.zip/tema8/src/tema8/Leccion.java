package tema8;

import java.util.ArrayList;
import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.Callable;
import java.util.concurrent.CyclicBarrier;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.stream.IntStream;

class Cuentame {
	public static int contador = 0;
}

public class Leccion {
	public static void main(String[] args) throws InterruptedException, ExecutionException, TimeoutException, BrokenBarrierException {
		//Leccion1();
		//Leccion2();
		//Leccion3();
		Leccion5();
		//Leccion7();
		//Leccion8();
	}
	//Correcto: Ninguno falla
	public static void Leccion1() {
		new Thread(() -> {}).start();
		new Thread(() -> { return;}).start();
		new Thread(() -> { throw new NullPointerException();}).run();
	}
	//Correcto una expecion que confirma la regla
	//Como las tareas son lanzadas con un delay de 1 segundo, es prácticamente imposible que veamos algo por consola 
	//Probad a poner Thread.sleep(1000);
	public static void Leccion2() throws InterruptedException, ExecutionException, TimeoutException {
		//Error en 0 microsegundos
		String wtf = Executors.newSingleThreadExecutor().submit(() -> "fiuuuu").get(0, TimeUnit.MICROSECONDS);
		System.out.println(wtf);
	}
	
	//FALTA EL SHUTDON -> 
	//1 pregunta -> Correcto: Un número entre 11 y 55
	//invokeAny lanza todos los callables y en cuanto uno devuelve su resultado, cancela todos los demás. 
	//2 pregunta -> CORRECTA: NO
	public static void Leccion3() throws InterruptedException {
		var ml = new ArrayList<Callable<Integer>>();
		ml.add(() -> 11);
		ml.add(() -> 22);
		ml.add(() -> 33);
		ml.add(() -> 44);
		ml.add(() -> 55);
		System.out.println(Executors.newSingleThreadExecutor().invokeAll(ml));
	}
	
	//Correcta: falta linea 4
	public static void Leccion4()  throws InterruptedException, ExecutionException, TimeoutException{
		Callable<Callable<?>> r = () -> (null);
		var _$ = Executors.newSingleThreadScheduledExecutor();
		//Scheduled solo admite Runnable en el método schedule(Callable, time, TimeUnit)
		var v = _$.scheduleAtFixedRate(r, 2, 3, TimeUnit.HOURS);
		_$.shutdown();
	}
	
	//Correcto:  Lo mas probable es que nada
	//Como las tareas son lanzadas con un delay de 1 segundo, es prácticamente imposible que veamos algo 
	//por consola. Probad a poner Thread.sleep(1000); en la línea 6.
	public static void Leccion5() throws InterruptedException {
		var _$ = Executors.newScheduledThreadPool(Byte.MAX_VALUE);
		IntStream.range(0, Byte.MAX_VALUE).forEach(aaa -> _$.scheduleAtFixedRate(()-> 
		{ System.out.println(aaa); }, 1, 1, TimeUnit.SECONDS));
		_$.shutdown();
	}
	
	//static AtomicString s = "-";
	public static void Leccion6() {
		var _$ = Executors.newFixedThreadPool(1);
		IntStream.range(0, 5).forEach(aaa -> _$.submit(() -> { s +="+";}));
		Thread.sleep(1000);
		System.out.println(s);
		_$.shutdown();
	}
	
	//Correcto: Me da mi que no
	//El método comoMolo() tiene un bloque synchronized sobre una instancia distinta de Cuentame. Por lo que aunque 
	//contador es estática y hay una única representación en memoria, su accesor, es decir Cuentame tiene varias
	//representaciones y no accedemos a las bloqueadas.
	public static void Leccion7() {
		var xxx = Executors.newFixedThreadPool(3);
		xxx.execute(Leccion::comoMolo);
		xxx.execute(Leccion::comoMolo);
		xxx.execute(Leccion::comoMolo);
		System.out.println(Cuentame.contador);
		xxx.shutdown();
	}
	
	public static void comoMolo() {
		Cuentame c = new Cuentame();
		synchronized (c) {
			c.contador++;
		}
	}
	
	//CyclicBarrier necesita tener el control de lo que ocurre en los hilos en el método que es invokado con await(). 
	public static void Leccion8() throws InterruptedException, BrokenBarrierException {
		int operarios = 2;
		//allow fex threads to wait each other
		CyclicBarrier cb = new CyclicBarrier(operarios);
		var ex = Executors.newFixedThreadPool(operarios);
		for(int i = 0; i< operarios; i++) {
			ex.submit(() -> Leccion.trabajar(cb));
		}
		trabajar(cb);
		System.out.println("podemos trabajar sin peligro a mutilarnos las extremidades");
		ex.shutdown();
	}
	
	private static int trabajar(CyclicBarrier cb) throws InterruptedException, BrokenBarrierException {
		apagarRadial();
		cb.await();
		cambiarDisco();
		cb.await();
		return 1;
	}
	
	public static void apagarRadial() {
		System.out.println("apagar la radial");
	}
	
	public static void cambiarDisco() {
		System.out.println("cambio disco");
	}
}

