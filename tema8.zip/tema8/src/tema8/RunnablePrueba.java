package tema8;

class Proceso extends Thread{
	@Override
	public void run() {
		System.out.println("ahora soy yo!");
	}
}

public class RunnablePrueba {
	public static void main(String[] args) throws InterruptedException{
		Runnable r = () -> System.out.println("hola");
		new Thread(r).start();
		Thread.sleep(1000);
		r.run();
		new Proceso().start();
		throw new RuntimeException("adios");
	}

}
