package tema8;

import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.stream.IntStream;

public class ExamenCompilan {

	private Lock bloqueador = new ReentrantLock();
	private int total = 0;
	
	public void transaccion(int cantidad) {
		try {
			bloqueador.tryLock();
			total += cantidad;
		}finally {
			bloqueador.unlock();
		}
	}
	
	//Devuelve exception o 45
	public static void Ejercicio2Examen() {
		var banco = new ExamenCompilan();
		IntStream.range(1, 10).parallel().forEach(s-> banco.transaccion(s));
		System.out.println(banco.total);
	}
	
	public static void main(String[] args) throws InterruptedException {
		//Ejercicio1Examen();
		Ejercicio2Examen();
	}
	

}
