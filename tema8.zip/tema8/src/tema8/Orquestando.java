package tema8;

import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CyclicBarrier;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Orquestando {
	
	private void desnudar() {
		System.out.println("Me quito la ropa");
	}
	
	private void duchar() {
		System.out.println("Me ducho");
	}
	
	private void vestir() {
		System.out.println("Me visto");
	}
	
	private void salir() {
		System.out.println("Voy al trabajo");
	}
	
	public void performTask(CyclicBarrier cb) {
		try {
			desnudar();
			cb.await();
			duchar();
			cb.await();
			vestir();
			cb.await();
			salir();
		}catch (InterruptedException | BrokenBarrierException e){
			System.out.println("upss algo fue mal");
		}
	}
	
	public static void main(String[] args) {
		ExecutorService service = null;
		try {
			service = Executors.newFixedThreadPool(5);
			var manager = new Orquestando();
			//dos parametros de CyclicBarrier: numeros de hilos, y función cuando eso ocurra
			var cb = new CyclicBarrier(5, () -> System.out.println("tarea realizada"));
			for(int i = 0; i<5; i++)
				service.submit(() -> manager.performTask(cb));
		}finally {
			if (service != null)
				service.shutdown();
		}
	}
}
