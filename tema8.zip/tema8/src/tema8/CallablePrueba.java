package tema8;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
public class CallablePrueba {
	public static void main(String[] args) throws InterruptedException, ExecutionException{
		Callable<String> c = () -> "amigos";
		//Crear un hilo a aparte
		//Executors.newSingleThreadExecutor().submit(c);
		//No termina el proceso, el SingleThreadExecutor
		//Future<String> f = Executors.newSingleThreadExecutor().submit(c);
		//System.out.println("hola "+f.get());
		
		ExecutorService es = Executors.newSingleThreadExecutor();
		Future<String> f = es.submit(c);
		System.out.println("hola "+f.get());
		//si termina el proceso
		es.shutdown();
		Schedule();
	}
	
	public static void Schedule() throws InterruptedException, ExecutionException {
		
		Callable<String> c = () -> "amigos";
		ScheduledExecutorService es = Executors.newSingleThreadScheduledExecutor();
		Future<String> f = es.schedule(c, 10, TimeUnit.SECONDS);
		System.out.println("ei, "+f.get());
		es.shutdown();
	}
}
