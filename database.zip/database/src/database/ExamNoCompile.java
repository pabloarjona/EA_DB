package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ExamNoCompile {
		//P: ¿Qué sale por consola? (imaginemos que todo lo relacionado con la base de datos, cadena de conexión etc es correcto)
		//R: Error de ejecución falta -> r.next()
		public void Ejercicio4(Connection c, String concatQuery, String columnLabel) throws SQLException {
			try (var x= c.createStatement(concatQuery);
					var r = x.executeQuery()){
				System.out.println(r.getDouble("gon"));			
			}
		}
		
		//P: Nuestro output será (supongamos que la conexión es correcta)
		//R: Error de ejeución-> prepareStatement tiene parámetro/necesita una query
		public void Ejercicio5() throws SQLException{
			String url = "jdbc:derby:correctness";
			try (var conn = DriverManager.getConnection(url);
					var ps = conn.prepareStatement();
					var rs = ps.executeQuery("SELECT * FROM persona")) {
				while(rs.next()) {
					System.out.println(rs.getInteger(1));
				}
			}
		}
}
