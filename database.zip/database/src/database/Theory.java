package database;

import java.sql.DriverManager;
import java.sql.SQLException;

public class Theory {
	public static void main(String[] args) throws SQLException, ClassNotFoundException {
		//ponemos try para evitar conexiones abiertas//protocolo:bandor:url		
		/*
		try(var con = DriverManager.getConnection("jdbc:derby://localhost:1527/java11;user=user"); 
				var s = con.createStatement();      //objeto abierto para realizar consultas
				var rs = s.executeQuery("select * from persona");){
			rs.next();
			rs.next();
			System.out.println(rs.getInt(3));
		}
		
		try(var con = DriverManager.getConnection("jdbc:derby://localhost:1527/java11;user=user"); 
				var s = con.prepareStatement("select * from persona where id=2");      
				var rs = s.executeQuery()){
			rs.next();
			
			System.out.println(rs.getInt(3));
		}
		
		try(var con = DriverManager.getConnection("jdbc:derby://localhost:1527/java11;user=user"); 
				var s = con.prepareStatement("UPDATE persona SET nombre= 'Curso Java 11' WHERE id=1");){
			var rs = s.executeUpdate();
			
		}*/
		//CON PARÁMETROS
		try(var con = DriverManager.getConnection("jdbc:derby://localhost:1527/java11;user=user"); 
				var s = con.prepareStatement("UPDATE persona SET nombre= ? WHERE id=?");){
			s.setString(1, "Curso Java XXX");
			s.setInt(2, 1);
			var rs = s.executeUpdate();	
		}
	}

}
