package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Exam {
	final static String CONN = "jdbc:derby://localhost:1527/java11;create=false;user=user;password=pass";

	public static void main(String[] args) throws SQLException {
		Ejercicio2( DriverManager.getConnection(CONN));
	}
	//P: ¿Qué cadena de conexión es correcta
	//R: A
	public void Ejercicio1() {
		String url = null;
		url = "jdbc:sybase:localhost:1234/db"; //A
		url = "jdbc::sybase::localhost::/db"; //B
		url = "jdbc::sybase:localhost::1234/db"; //C
		url = "oracle:localhost:1234/db"; //D
	}
	//P: ¿Esto es correcto? 
	//R: Da error de ejeucicón 100%
	public static void Ejercicio2(Connection conn) throws SQLException{
		var sql = "UPDATE habitat WHERE enviroment = ?";
		try (var ps = conn.prepareStatement(sql)){
			ps.setString(0, "snoq"); //ERROR: Los parámetros empiezan en 1
			ps.executeUpdate();
		}
	}
	
	//P: ¿Qué sale por consola?
	//R: 33True
	public static void Ejercicio3() throws SQLException {
		final String DATABASE_URL = "jdbc:derby://localhost:1527/java11;create=false;user=user;password=pass";
		try (Connection conn = DriverManager.getConnection(DATABASE_URL);
				PreparedStatement p = conn.prepareStatement("select count(*) from persona")){
			ResultSet rs = p.executeQuery();
			while(rs.next()) {
				System.out.println(rs.getBigDecimal(1));
				System.out.println(rs.getString(1));
				System.out.println(rs.getBoolean(1));
			}
			rs.close();
		}
	}
	
	
	
		
}
