package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class CreateDB {

	private static final String DATABASE_URL = "jdbc:derby://localhost:1527/java11;create=true;user=user;password=pass";
	
	public static void main(String... args) throws ClassNotFoundException, SQLException {
		
		try (Connection conn = DriverManager.getConnection(DATABASE_URL); Statement s = conn.createStatement()) {
			s.execute("CREATE TABLE persona(id int, nombre varchar(50), edad int, peso int)");
			s.execute("INSERT INTO persona VALUES (1, 'Paco Perez', 28, 75)");
			s.execute("INSERT INTO persona VALUES (2, 'Pili Sanchez', 22, 66)");
			s.execute("INSERT INTO persona VALUES (3, 'Pedro Zapatero', 43, 29)");
		}
		
	}

}
