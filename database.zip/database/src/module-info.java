/**
 * 
 */
/**
 * @author parjrui
 *
 */
module database {
	requires java.sql;
}